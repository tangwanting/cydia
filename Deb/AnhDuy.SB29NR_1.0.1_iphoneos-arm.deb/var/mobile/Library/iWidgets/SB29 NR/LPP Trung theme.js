/* Created by LockPlus Pro by JunesiPhone http://twitter.com/junesiphone This is for personal use only. You cannot sell this widget. If you want to sell a widget code your own. */ var savedElements = {"placedElements":{"boxOne":{"width":"75px","height":"35px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"47px","left":"23px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"18px","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 4px rgb(163, 177, 198), inset -2px -2px 4px rgb(255, 255, 255)"},

"boxTwo":{"width":"122px","height":"90px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":109,"left":22,"font-family":"helvetica","font-size":"30px","color":"white","border-radius":"20px","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"10px 10px 20px rgb(163, 177, 198), -10px -10px 20px rgb(255, 255, 255), inset 3px 3px 6px rgb(255, 255, 255), inset -3px -3px 6px rgb(163, 177, 198)"},


"boxThree":{"width":"122px","height":"90px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":109,"left":175,"font-family":"helvetica","font-size":"30px","color":"white","border-radius":"20px","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"10px 10px 20px rgb(163, 177, 198), -10px -10px 20px rgb(255, 255, 255), inset 3px 3px 6px rgb(255, 255, 255), inset -3px -3px 6px rgb(163, 177, 198)"},



"boxFour":{"width":"38px","height":"38px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"473px","left":"212px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"12px","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"2px 2px 4px rgb(163, 177, 198), -2px -2px 4px rgb(255, 255, 255)"},


"boxFive":{"width":"38px","height":"38px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"473px","left":"259px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"12px","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"2px 2px 4px rgb(163, 177, 198), -2px -2px 4px rgb(255, 255, 255)"},


"boxEight":{"width":"87px","height":"40px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":282,"left":210,"font-family":"helvetica","font-size":"30px","color":"white","border-radius":"17px","box-shadow":"10px 10px 20px rgb(163, 177, 198), -10px -10px 20px rgb(255, 255, 255)","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxNine":{"width":"87px","height":"40px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"354px","left":"210px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"17px","box-shadow":"10px 10px 20px rgb(163, 177, 198), -10px -10px 20px rgb(255, 255, 255)","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxTen":{"width":"132px","height":"38px","background-color":"transparent","z-index":"2","border-color":"rgb(163, 163, 163 ,0.1)","border-style":"solid","border-width":"2px","position":"absolute","top":"544px","left":"164px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"16px","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 4px rgb(163, 177, 198), inset -2px -2px 4px rgb(255, 255, 255)"},



"boxSix":{"width":"340px","height":"690px","background-color":"transparent","z-index":1,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"0px","left":"0px","font-family":"helvetica","font-size":"40px","color":"rgba(0, 0, 0, 0.58)","background":"linear-gradient(to bottom, rgb(224, 230, 236) 0%, rgb(224, 230, 236) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},

"boxCircleOne":{"width":"37px","height":"37px","background-color":"transparent","z-index":2,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"548px","left":"20px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"5px 5px 9px rgb(163, 177, 198), -5px -5px 4px rgb(255, 255, 255)","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxCircleTwo":{"width":"27px","height":"27px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"553px","left":"25px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 2px 2px 4px rgb(163, 177, 198), inset -2px -2px 4px rgb(255, 255, 255)","background":"linear-gradient(to bottom, rgb(224, 230, 236) 0%, rgb(224, 230, 236) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},



"textOne":{"position":"absolute","z-index":"2","top":"52px","left":"138px","font-family":"HelveticaNeue","font-size":"17px","color":"#ff0000","innerHTML":"HELLO ANH DUY", "letter-spacing": "0px", "font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},


"boxCircleThree":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"565px","left":"86px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #008888 0%, #008888 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"boxCircleFour":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"563px","left":"99px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #008888 0%, #008888 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"boxCircleFive":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"567px","left":"112px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #ff0000 0%, #ff0000 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)"},


"boxCircleSix":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"565px","left":"126px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #ff0000 0%, #ff0000 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent" ,"box-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)"},


"text5":{"position":"absolute","z-index":"2","top":"555px","left":"30px","font-family":"mat2","font-size":"19","color":"#ff0000","innerHTML":"z","height":"24px","width":"25px","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.6)" },


"boxSeven":{"width":"27px","height":"27px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"360px","left":"260px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"30px","background":"linear-gradient(to left, #ececec 0%, #ececec 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 4px rgb(163, 167, 198), inset -2px -2px 4px rgb(255, 255, 255,0.6)","is-battery":"false"},


"boxEleven":{"width":"2px","height":"32px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"287px","left":"253px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 1px 1px 2px rgb(163, 177, 198), inset -1px -1px 2px rgb(255, 255, 255)","background":"linear-gradient(to bottom, rgb(224, 230, 236) 0%, rgb(224, 230, 236) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"coloricon":{"position":"absolute","z-index":"2","top":"286px","left":"260px","font-family":"helvetica","font-size":"30px","color":"#ff0000","width":"23px","height":"23px", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"tempdeg":{"position":"absolute","z-index":"2","top":"293px","left":"222px","font-family":"HelveticaNeue","font-size":"16px","color":"#008888","font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"boxCircleSeven":{"width":"22px","height":"22px","background-color":"transparent","z-index":"2","border-color":"rgb(224, 230, 236)","border-style":"solid","border-width":"2px","position":"absolute","top":"123px","left":"190px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"6px 6px 10px rgb(163, 177, 198), -6px -6px 10px rgb(255, 255, 255), inset 2px 2px 4px rgb(163, 177, 198), inset -2px -2px 4px rgb(255, 255, 255)"},


"boxCircleEight":{"width":"22px","height":"22px","background-color":"transparent","z-index":"2","border-color":"rgb(224, 230, 236)","border-style":"solid","border-width":"2px","position":"absolute","top":"162px","left":"255.5px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"6px 6px 10px rgb(163, 177, 198), -6px -6px 10px rgb(255, 255, 255), inset 2px 2px 4px rgb(163, 177, 198), inset -2px -2px 4px rgb(255, 255, 255)"},




"textThree":{"position":"absolute","z-index":"2","top":"166px","left":209,"font-family":"HelveticaNeue","font-size":"12px","color":"#ff0000","width":"47px","innerHTML":"WiFi","height":"19px","font-weight":"bold", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)"  },


"textFour":{"position":"absolute","z-index":"2","top":"128px","left":"233px","font-family":"HelveticaNeue","font-size":"11px","color":"#008888","innerHTML":"di động ","height":"20px","width":"39px","letter-spacing": "-0.5px", "font-weight":"bold","text-transform":"uppercase","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"boxCircleNine":{"width":"22px","height":"22px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"122.5px","left":"36.5px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 2px 3px 4px rgb(163, 163, 163,0.8), inset -2px -2px 4px rgb(255, 255, 255,0.5)","background":"linear-gradient(to bottom, #ececec 0%, #ececec 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"text6":{"font-family":"mat5","position":"absolute","z-index":"2","top":"126.5px","left":"41.8px","font-size":"13px","innerHTML":"X", "color":"#008888", "font-weight":"bold", "background-color":"rgba(0, 0, 0, 0)", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"zclock":{"position":"absolute","z-index":"2","top":"54px","left":"41px","font-family":"HelveticaNeue","font-weight":"bold", "font-size":"16px","color":"#008888","font-weight":"bold", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)"},


"sday":{"position":"absolute","z-index":"2","top":"168px","left":"35px","font-family":"HelveticaNeue","font-size":"15px","color":"#ff0000","letter-spacing": "-0.5px","font-weight":"bold", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"datepad":{"position":"absolute","z-index":"2","top":"129px","left":"90px","font-family":"HelveticaNeue","font-size":"30px","color":"#ff0000","font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},


"smonth":{"position":"absolute","z-index":"2","top":"168px","left":"74px","font-family":"HelveticaNeue","font-size":"15px","color":"008888", "letter-spacing": "-0.5px","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)", "font-weight":"bold"},


"text2":{"font-family":"mat2","position":"absolute","z-index":"2","top":"480px","left":"221px","font-size":"20px","innerHTML":"R","color":"#008888","font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"text1":{"position":"absolute","z-index":"2","top":"481px","left":"269px","font-family":"mat2","font-size":"19","color":"#ff0000","innerHTML":"D","height":"24px","width":"25px","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.6)" },


"textFive":{"position":"absolute","z-index":"2","top":"365px","left":"218px","font-family":"HelveticaNeue","font-size":"12px","color":"#008888","width":"59px","innerHTML":"Mức Pin","height":"25px","letter-spacing": "-0.5px", "font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"textSix":{"position":"absolute","z-index":"2","top":"558px","left":"186px","font-family":"HelveticaNeue","font-size":"12px","color":"#008888","innerHTML":"Các ứng dụng","width":"83px","height":"27px","letter-spacing":"0px", "font-weight":"bold","text-transform":"uppercase", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)"},


"wifi":{"position":"absolute","z-index":"2","top":"170px","left":"271.5px","font-family":"HelveticaNeue","font-size":"10px","color":"ff0000 ","font-weight":"bold", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.5)"  },


"signal":{"position":"absolute","z-index":"2","top":"126px","left":"197.2px","font-family":"HelveticaNeue","font-size":"9px","color":"#008888","height":"20px","font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.5)" },


"text4":{"font-family":"mat5","position":"absolute","z-index":"2","top":"129.5px","left":"196.4px","font-size":"13px","innerHTML":"i","color":"#ff0000","width":"25px","height":"21px", "font-weight":"bold", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.5)" },


"text3":{"font-family":"mat2","position":"absolute","z-index":"2","top":"165px","left":"260px","font-size":"13px","innerHTML":"g","color":"#008888","width":"22px","height":"20px","font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.4)" },


"bundle123":{"name":"Chrome","bundleID":"com.google.chrome.ios","position":"absolute","z-index":"2","top":"539px","left":"22px","font-family":"helvetica","font-size":"7px","color":"rgba(255, 255, 255, 0)","width":"32px","height":"32px"},


"bundle113":{"name":"‎google Maps","bundleID":"com.google.Maps","position":"absolute","z-index":"2","top":"467px","left":"219px","font-family":"sanfranbold","font-size":"5px","color":"rgba(180, 4, 4, 0)","height":"25px","width":"35px"},



"bundle133":{"name":"‎Zing MP3","bundleID":"vng.com.vn.zingmp3-lite","position":"absolute","z-index":"2","top":"467px","left":"266px","font-family":"anhduy","font-size":"5px","color":"rgba(255, 255, 255, 0)","width":"25px","height":"25px"},



"batterypie":{"position":"absolute","z-index":"2","top":"364px","left":"264px","font-family":"helvetica","font-size":"30px","color":"white","circle-width":"20px","circle-stroke-dasharray":"4px","circle-stroke-value":"13px","inner-color":"#008888","outer-color":"#ff0000"}},


"iconName":"reddock"}