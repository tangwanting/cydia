/* Created by LockPlus Pro by JunesiPhone http://twitter.com/junesiphone This is for personal use only. You cannot sell this widget. If you want to sell a widget code your own. */ var savedElements = {"placedElements":{"box1":{"width":"75px","height":"35px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"49px","left":"20px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"18px","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 4px rgb(0, 0, 0, 0.5), inset -2px -2px 4px rgb(255, 255, 255, 0.05)"},


"box2":{"width":"122px","height":"90px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"112px","left":"22px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"20px","box-shadow":"10px 10px 20px rgb(0, 0, 0, 0.4), -20px -20px 60px rgb(64, 66, 76, 0.3), inset 5px 5px 8px #333333, inset -4px -4px 8px rgb(32, 33, 36)","background":"linear-gradient(to bottom left, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"box3":{"width":"122px","height":"90px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":112,"left":175,"font-family":"helvetica","font-size":"30px","color":"white","border-radius":"20px","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"10px 10px 20px rgb(0, 0, 0, 0.4), -20px -20px 60px rgb(64, 66, 76, 0.3), inset 6px 6px 8px rgb(64, 66, 76, 0.3), inset -4px -4px 8px rgb(32, 33, 36)"},


"box4":{"width":"38px","height":"38px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"470px","left":"212px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"12px","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"2px 2px 4px rgb(0, 0, 0, 0.4), -2px -2px 4px rgb(44, 45, 48)"},


"box5":{"width":"38px","height":"38px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"470px","left":"259px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"12px","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"2px 2px 4px rgb(0, 0, 0, 0.4), -2px -2px 4px rgb(44, 45, 48)"},


"box6":{"width":"87px","height":"40px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":278,"left":210,"font-family":"helvetica","font-size":"30px","color":"white","border-radius":"17px","box-shadow":"10px 10px 20px rgb(0, 0, 0, 0.4), -10px -10px 16px rgb(44, 45, 48)","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"box7":{"width":"87px","height":"40px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"358px","left":"210px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"17px","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"10px 10px 20px rgb(0, 0, 0, 0.4), -10px -10px 16px rgb(44, 45, 48)"},


"box8":{"width":"132px","height":"38px","background-color":"transparent","z-index":"2","border-color":"rgb(38, 39, 42)","border-style":"solid","border-width":"2px","position":"absolute","top":"541px","left":"167px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"16px","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 4px rgb(0, 0, 0, 0.4), inset -2px -2px 4px rgb(255, 255, 255, 0.05)"},



"box9":{"width":"320px","height":"690px","background-color":"transparent","z-index":1,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":0,"left":0,"font-family":"helvetica","font-size":"30px","color":"rgba(255, 255, 255, 0)","background":"linear-gradient(to bottom, rgb(38, 39, 42) 0%, rgb(38, 39, 42) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"box10":{"width":"37px","height":"37px","background-color":"transparent","z-index":2,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"545px","left":"20px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"5px 5px 9px rgb(0, 0, 0, 0.4), -5px -5px 4px rgb(44, 45, 48)","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"box11":{"width":"27px","height":"27px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"550px","left":"25px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 2px 2px 4px rgb(0, 0, 0, 0.4), inset -2px -2px 4px rgb(255, 255, 255, 0.08)","background":"linear-gradient(to bottom, rgb(38, 39, 42) 0%, rgb(38, 39, 42) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"box12":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"562px","left":"86px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, rgb(130, 130, 133) 0%,rgb(130, 130, 133) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"box13":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"560px","left":"99px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #c52520 0%, #c52520 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"box14":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"564px","left":"112px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, rgb(130, 130, 133) 0%, rgb(130, 130, 133) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"box15":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"562px","left":"126px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #c52520 0%, #c52520 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},



"box16":{"width":"28px","height":"28px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"364px","left":"260px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"30px","background":"linear-gradient(to left, rgb(38, 39, 42) 0%, rgb(38, 39, 42) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 3px rgb(14, 14, 14, 0.5), inset -2px -2px 3px rgb(255, 255, 255, 0.07)","is-battery":"false"},


"box17":{"width":"2px","height":"32px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"283px","left":"253px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 1px 1px 2px rgb(14, 14, 14, 0.8), inset -1px -1px 1px 2px rgb(44, 45, 48)","background":"linear-gradient(to bottom, rgb(38, 39, 42) 0%, rgb(38, 39, 42) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},



"box18":{"width":"22px","height":"22px","background-color":"transparent","z-index":"2","border-color":"rgb(38, 39, 42)","border-style":"solid","border-width":"2px","position":"absolute","top":"165px","left":"256px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 4px rgb(0, 0, 0, 0.36), inset -2px -2px 4px rgb(255, 255, 255, 0.08), 3px 3px 7px rgb(0, 0, 0, 0.4), -3px -3px 7px rgb(44, 45, 48)"},


"box19":{"width":"22px","height":"22px","background-color":"transparent","z-index":"2","border-color":"rgb(38, 39, 42)","border-style":"solid","border-width":"2px","position":"absolute","top":"123px","left":"188px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 4px rgb(0, 0, 0, 0.36), inset -2px -2px 4px rgb(255, 255, 255, 0.08), 3px 3px 7px rgb(0, 0, 0, 0.4), -3px -3px 7px rgb(44, 45, 48)"},

"box20":{"width":"23px","height":"23px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"124px","left":"36px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 2px 2px 4px rgb(0, 0, 0, 0.4), inset -2px -2px 4px rgb(255, 255, 255, 0.2)","background":"linear-gradient(to bottom, rgb(38, 39, 42) 0%, rgb(38, 39, 42) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},



"text0":{"position":"absolute","z-index":"2","top":"371px","left":"217px","font-family":"anhduy","font-size":"10px","color":"rgb(130, 130, 133)","width":"59px","innerHTML":"Mức pin","height":"25px","letter-spacing": "-1px", "font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)" },



"text1":{"position":"absolute","z-index":"2","top":"557px","left":"188px","font-family":"anhduy","font-size":"11px","color":"rgb(130, 130, 133)","innerHTML":"các ứng dụng","width":"83px","height":"27px","letter-spacing":"0px","font-weight":"bold","text-transform":"uppercase","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},



"text2":{"position":"absolute","z-index":"2","top":"60px","left":"142px","font-family":"anhduy","font-weight":"bold", "font-size":"16px","color":"#c52520","text-align":"center","innerHTML":"Hello Anh Duy","text-transform":"uppercase","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},



"text3":{"position":"absolute","z-index":"2","top":"172px","left":209,"font-family":"anhduy","font-size":"12px","color":"#c52520","width":"47px","innerHTML":"WiFi","height":"19px","font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},


"text4":{"position":"absolute","z-index":"2","top":"131px","left":"232px","font-family":"anhduy","font-size":"12px","color":"rgb(130, 130, 133)","innerHTML":"di động ","height":"20px","width":"39px","letter-spacing": "-1px", "font-weight":"bold","text-transform":"capitalize", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)" },



"text5":{"font-family":"mat5","position":"absolute","z-index":"2","top":"128px","left":"41px","font-size":"13px","innerHTML":"X","color":"rgb(130, 130, 133)","background-color":"rgba(0, 0, 0, 0)"},


"text6":{"position":"absolute","font-family":"mat2","z-index":"2","top":"479px","font-weight":"bold","left":"221px","font-size":"20px","innerHTML":"R", "color":"rgb(130, 130, 133)", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},


"text7":{"position":"absolute","font-family":"mat2","z-index":"2","top":"479px","font-weight":"bold","left":"268px","font-size":"20px","innerHTML":"D","color":"#c52520","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)" },


"text8":{"font-family":"mat5","position":"absolute","z-index":"2","top":"130px","left":"197px","font-weight":"bold","font-size":"12px","innerHTML":"i","color":"#c52520","width":"25px","height":"21px"},


"text9":{"font-family":"mat2","position":"absolute","z-index":"2","top":"169px","left":"261px","font-size":"12px","innerHTML":"g", "font-weight":"bold","color":"rgb(130, 130, 133)","width":"22px","height":"20px"},


"text10":{"position":"absolute","z-index":"2","top":"554px","left":"30px","font-family":"mat2","font-size":"19px","color":"#c52520","innerHTML":"z","height":"24px","width":"25px","text-shadow":"1px 1px 1px rgba(0, 0, 0, 0.9)"},



"zclock":{"position":"absolute","z-index":"2","top":"59px","left":"37px","font-family":"anhduy", "font-weight":"bold","font-size":"17px","color":"rgb(130, 130, 133)", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 3)"},


"datepad":{"position":"absolute","z-index":"2","top":"131px","left":"83px","font-family":"anhduy", "font-weight":"bold", "font-size":"35px","color":"#c52520","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},


"sday":{"position":"absolute","z-index":"2","top":"175px","left":"36.5px","font-family":"anhduy",  "font-weight":"bold", "font-size":"13px","color":"#c52520","letter-spacing": "-1px","font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},


"smonth":{"position":"absolute","z-index":"2","top":"175px","left":"74.5px","font-family":"anhduy","font-size":"13px","color":"rgb(130, 130, 133)","letter-spacing": "-1px",  "font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)" },

"batterypie":{"position":"absolute","z-index":"2","top":"368px","left":"264px","font-family":"helvetica","font-size":"30px","color":"white","circle-width":"20px","circle-stroke-dasharray":"4px","circle-stroke-value":"13px","inner-color":"rgba(122, 122, 122, 0.33)","outer-color":"#c52520"},


"wifi":{"position":"absolute","z-index":"2","top":"175px","left":"272px","font-family":"anhduy","font-size":"9px","color":"#c52520","font-weight":"bold"},


"signal":{"position":"absolute","z-index":"2","top":"128px","left":"196px","font-family":"anhduy","font-size":"9px","color":"rgb(130, 130, 133)","height":"20px","font-weight":"bold"},


"tempdeg":{"position":"absolute","z-index":"2","top":"291px","left":"222px","font-family":"anhduy","font-size":"16px","color":"rgb(130, 130, 133)","font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},



"bundle133":{"name":"‎Zing MP3","bundleID":"vng.com.vn.zingmp3-lite","position":"absolute","z-index":"2","top":"467px","left":"266px","font-family":"HelveticaNeue","font-size":"5px","color":"rgba(180, 4, 4, 0)","width":"25px","height":"25px"},


"bundle113":{"name":"‎google Maps","bundleID":"com.google.Maps","position":"absolute","z-index":"2","top":"467px","left":"219px","font-family":"HelveticaNeue","font-size":"5px","color":"rgba(180, 4, 4, 0)","height":"25px","width":"25px"},


"bundle123":{"name":"Chrome","bundleID":"com.google.chrome.ios","position":"absolute","z-index":"2","top":"549px","left":"22px","font-family":"HelveticaNeue","font-size":"7px","color":"rgba(255, 255, 255, 0)","width":"32px","height":"32px"},



"coloricon":{"position":"absolute","z-index":"2","top":"286px","left":"264px","font-family":"helvetica","font-size":"24px","color":"#c52520"}},


"iconName":"reddock"}