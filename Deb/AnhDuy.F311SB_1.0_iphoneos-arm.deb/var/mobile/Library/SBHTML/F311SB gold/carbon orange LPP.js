var savedElements = {"placedElements":{"daydatesmonth":{"position":"absolute","z-index":3,"top":"204px","left":"6px","font-family":"Wider","font-size":"12px","color":"rgba(236, 143, 74, 1.00)","width":"202px","text-align":"left","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.97)","letter-spacing":"initial","text-transform":"","padding-left":"4px"},


"zclock":{"position":"absolute","z-index":3,"top":"147px","left":"6px","font-family":"Wider","font-size":"16px","color":"rgba(236, 143, 74, 1.00)","width":"70px","text-align":"left","height":"19px","padding-left":"4px","text-shadow":"0px 1px 1px rgb(0, 0, 0)"},



"boxOne":{"width":"320px","height":"86px","background-color":"transparent","z-index":1,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"139px","left":"0px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"0px 2px 3px rgb(0,0,0)","data-image":"images/wall.png","background-size":"cover","background-repeat":"no-repeat"},



"boxTwo":{"width":"161px","height":"3px","background-color":"transparent","z-index":3,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"139px","left":"-1px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to left, rgba(236, 143, 74, 1.00), rgb(27, 27, 27) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":""},



"boxThree":{"width":"161px","height":"3px","background-color":"transparent","z-index":3,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"139px","left":"160px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to right, rgba(236, 143, 74, 1.00), rgb(27, 27, 27) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":""},



"boxFour":{"width":"161px","height":"3px","background-color":"transparent","z-index":3,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"222px","left":"-1px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to left, rgba(236, 143, 74, 1.00), rgb(27, 27, 27) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":""},



"boxFive":{"width":"161px","height":"3px","background-color":"transparent","z-index":3,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"222px","left":"160px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to right, rgba(236, 143, 74, 1.00), rgb(27, 27, 27) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":""},



"highdashlowdeg":{"position":"absolute","z-index":"2","top":"187px","left":"235px","font-family":"Wider","font-size":"12px","color":"rgba(236, 143, 74, 1.00)","width":"73px","text-align":"right","padding-right":"1px","text-shadow":"0px 1px 1px rgb(0, 0, 0)"},



"boxSix":{"width":"325px","height":"3px","background-color":"rgb(0, 0, 0)","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"139px","left":"-2px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"0px 2px 3px rgb(0,0,0)"},



"boxSeven":{"width":"327px","height":"3px","background-color":"rgb(0, 0, 0)","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"222px","left":"-4px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"0px -2px 3px rgb(0,0,0)"},



"boxEight":{"width":"324px","height":"3px","background-color":"rgb(0, 0, 0)","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"139px","left":"-2px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"0px 2px 2px rgb(0,0,0)"},



"boxNine":{"width":"327px","height":"3px","background-color":"rgb(0, 0, 0)","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"222px","left":"-3px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"0px -2px 2px rgb(0,0,0)"},




"boxTen":{"width":"1px","height":"84px","background-color":"rgb(0, 0, 0)","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"140px","left":"0px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"1px 0px 3px rgb(0,0,0)"},



"boxEleven":{"width":"1px","height":"84px","background-color":"rgb(0, 0, 0)","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"140px","left":"319px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"-1px 0px 3px rgb(0,0,0)"},




"tempdegplus":{"position":"absolute","z-index":"2","top":"147px","left":"249px","font-family":"Wider","font-size":"16px","color":"rgba(236, 143, 74, 1.00)","width":"59px","text-align":"right","text-shadow":"0px 1px 1px rgb(0,0,0)"},



"condition":{"position":"absolute","z-index":"2","top":"204px","left":"158px", "text-transform":"","font-family":"Wider","font-size":"12px","color":"rgba(236, 143, 74, 1.00)","width":"149px","text-align":"right","text-shadow":"0px 1px 1px rgb(0,0,0)"},


"coloricon":{"position":"absolute","z-index":"2","top":"162px","left":"287px","font-family":"helvetica","font-size":"18px","color":"rgba(236, 143, 74, 1.00)","width":"22px","text-align":"center","text-shadow":"0px 1px 1px rgb(0,0,0)","height":"20px"},



"year":{"position":"absolute","z-index":"2","top":"178px","left":"6px","font-family":"Wider","font-size":"12px","color":"rgba(236, 143, 74, 1.00)","width":"54px","padding-left":"5px","text-shadow":"0px 1px 1px rgb(0,0,0)"}},

"iconName":"realicons"}