var Scale = "1.1"; // chỉnh kích cỡ ví dụ : 0.8
var Clock = "12h"; // chọn kiểu giờ : 12h hoặc 24h
var Lang = "vi"; // chọn ngôn ngữ : vi   en  ...
var refreshrate = 10; // cập nhật khoảng thời gian tính bằng phút
var WeatherIcon = 1; // chọn biểu tượng thời tiết: 1 = trắng, 2 = đen
var TextColor1 = "white"; // màu chữ 1 : silver
var TextColor2 = "white"; // màu chữ 2 : azaru
var BlurBackground = false; // bật nền mờ
var HideBackground = false; // ẩn nền chính
var BackgroundColor = "#333343"; // màu nền chính : #333343   azure
