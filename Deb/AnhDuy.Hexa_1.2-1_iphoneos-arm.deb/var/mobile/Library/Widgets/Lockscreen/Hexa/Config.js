var Scale = "1.1"; // chỉnh kích cỡ ví dụ : 1.1
var Clock = "12h"; // chọn kiểu giờ : 12h hoặc 24h
var Lang = "vi"; // chọn ngôn ngữ : vi   en ...
var refreshrate = 5; // cập nhật khoảng thời gian trong vài phút
var IconWeather = "1"; // chọn biểu tượng thời tiết: 1 = Trắng, 2 = Đen
var HourColor = "white"; // màu giờ : brown
var MinuteColor = "white"; // màu phút : gold
var TextColor = "white"; // màu chữ : azure
var BackgroundColor = "#333343"; // màu nền chính : #333343
var BlurBackground = false; // bật nền mờ
var HideBackground = true; // ẩn nền chính
var HexagonColor = "white,white"; // Trộn màu hình bên trái : brown   gold   (phải có hai màu)
var HexagonShadowColor = "white"; // màu hình bên phải : gold
var BlendMode = false; // Trộn màu văn bản trong Hình lục giác
