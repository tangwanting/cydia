var twentyfourhour = true; // bật 24 giờ
var pad = true; // bật để thêm số 0 trước giờ
