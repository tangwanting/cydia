var dialLines = document.getElementsByClassName('diallines');

for (var i = 1; i < 60; i++) {
   dialLines[i] = $(dialLines[i-1]).clone()
                                   .insertAfter($(dialLines[i-1]));
   $(dialLines[i]).css('transform', 'rotate(' + 6 * i + 'deg)');
}

function tick() {
   var date = new Date();
   var seconds = date.getSeconds();
   var minutes = date.getMinutes();
   var hours = date.getHours();
   var day = date.getDate();
   
	var weekdays = new Array(7);
	weekdays[0] = "CN";
	weekdays[1] = "thứ 2";
	weekdays[2] = "thứ 3";
	weekdays[3] = "thứ 4";
	weekdays[4] = "thứ 5";
	weekdays[5] = "thứ 6";
	weekdays[6] = "thứ 7";
	//var current_date = new Date();

	weekday_value = date.getDay();
	var first_three = weekdays[weekday_value];
   var today_is = first_three.substring(0,9);
   
   var secAngle = seconds * 6;
   var minAngle = minutes * 6 + seconds * (360/3600);
   var hourAngle = hours * 30 + minutes * (360/720);
   
   $('.sec-hand').css('transform', 'rotate(' + secAngle + 'deg)');
   $('.min-hand').css('transform', 'rotate(' + minAngle + 'deg)');
   $('.hour-hand').css('transform', 'rotate(' + hourAngle + 'deg)');
   $('.date').text(day + ' ' + today_is);
   
   
   
   
}

setInterval(tick, 100);