/* Created by LockPlus Pro by JunesiPhone http://twitter.com/junesiphone This is for personal use only. You cannot sell this widget. If you want to sell a widget code your own. */ var savedElements = {"overlay":"","placedElements":{"boxOne":{"left":107,"border-color":"red","border-width":"0px","position":"absolute","-webkit-text-fill-color":"transparent","width":"105px","font-family":"helvetica","font-size":"30px","-webkit-background-clip":"initial","color":"white","background":"linear-gradient(to left, rgba(255, 0, 0, 1.00)","-webkit-transform":"rotate(45deg)","box-shadow":"1px 1px 5px rgb(0,0,0)","height":"105px","background-color":"transparent","z-index":"2","border-style":"solid","top":199},



"boxTwo":{"left":84,"border-color":"rgb(255, 255, 255)","border-width":"1px","position":"absolute","width":"150px","font-family":"helvetica","font-size":"30px","-webkit-transform":"rotate(45deg)","color":"white","height":"150px","background-color":"rgba(255, 0, 0, 0)","z-index":"2","border-style":"solid","top":176},



"clockline":{"position":"absolute","font-family":"anhduy1","color":"white","text-align":"center","width":"320px","z-index":"2","top":200,"left":0,"font-size":"16px","opacity":"1"},



"day":{"left":0,"text-align":"center","position":"absolute","letter-spacing": "3.5px","border-radius":"156px","font-family":"anhduy","font-size":"30px","width":"320px","color":"white","opacity":"1","height":"34px","z-index":"2","top":228},



"boxCircleOne":{"left":37,"border-color":"rgb(255, 255, 255)","border-width":"1px","position":"absolute","border-radius":"999px","-webkit-text-fill-color":"transparent","width":"35px","font-family":"helvetica","font-size":"30px","-webkit-background-clip":"initial","color":"white","background":"linear-gradient(to bottom, white, transparent","-webkit-transform":"rotate(90deg)","height":"35px","background-color":"transparent","z-index":"2","border-style":"solid","top":233},



"monthnumslashdatepad":{"position":"absolute","font-family":"anhduy1","color":"white","text-align":"center","width":"320px","z-index":"2","top":287,"left":0,"font-size":"16px","opacity":"1"},




"boxCircleTwo":{"left":246,"border-color":"rgb(255, 255, 255)","border-width":"1px","position":"absolute","border-radius":"999px","-webkit-text-fill-color":"transparent","width":"35px","font-family":"helvetica","font-size":"30px","-webkit-background-clip":"initial","color":"white","background":"linear-gradient(to bottom, transparent, white","-webkit-transform":"rotate(90deg)","height":"35px","background-color":"transparent","z-index":"2","border-style":"solid","top":233},



"boxCircleThree":{"left":142,"border-color":"rgb(255, 255, 255)","border-width":"1px","position":"absolute","border-radius":"999px","-webkit-text-fill-color":"transparent","width":"35px","font-family":"helvetica","font-size":"30px","-webkit-background-clip":"initial","color":"white","background":"linear-gradient(to bottom, transparent, white","-webkit-transform":"rotate(180deg)","height":"35px","background-color":"transparent","z-index":"2","border-style":"solid","top":338},



"boxCircleFour":{"left":142,"border-color":"rgb(255, 255, 255)","border-width":"1px","position":"absolute","border-radius":"999px","-webkit-text-fill-color":"transparent","width":"35px","font-family":"helvetica","font-size":"30px","-webkit-background-clip":"initial","color":"white","background":"linear-gradient(to bottom, white, transparent","-webkit-transform":"rotate(180deg)","box-shadow":"","height":"35px","background-color":"transparent","z-index":"2","border-style":"solid","top":128}},"iconName":"simply"}