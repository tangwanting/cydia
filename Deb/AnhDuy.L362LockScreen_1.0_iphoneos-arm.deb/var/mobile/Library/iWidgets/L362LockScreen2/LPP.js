var savedElements = {"placedElements":{"boxCircleOne":{"width":"179px","height":"179px","background-color":"rgba(213, 213, 213, 0)","z-index":"2","border-color":"rgb(213, 213, 213)","border-style":"solid","border-width":"0px","position":"absolute","top":"61px","left":"68px","border-radius":"999px","font-family":"anhduy","font-size":"30px","color":"white","-webkit-backdrop-filter":"blur(5px)","box-shadow":""},



"icon":{"position":"absolute","z-index":3,"top":"198px","left":"87px","font-family":"anhduy","font-size":"30px","color":"white","width":"145px","height":"92px"},



"boxCircleTwo":{"width":"139px","height":"139px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"-210px","left":"89px","border-radius":"999px","font-family":"anhduy","font-size":"30px","color":"white","background":"linear-gradient(to bottom, rgba(255, 255, 255, 0.58) 0%, rgba(255, 255, 255, 0) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},



"tempdegplus":{"position":"absolute","z-index":"2","top":"277px","left":"115px","font-family":"anhduy5","font-size":"62px","color":"white","width":"89px","text-align":"center","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.42)"},



"zhour":{"position":"absolute","z-index":3,"top":"85px","left":"116px","font-family":"anhduy1","font-size":"40px","letter-spacing":"7px","color":"rgb(255, 255, 255)","width":"92px","height":"45px","lineHeight":"52px","text-align":"center","background":"linear-gradient(to bottom, rgb(255, 255, 255) 0%, rgba(255, 255, 255, 0) 90%)","-webkit-background-clip":"text","-webkit-text-fill-color":"transparent"},



"minute":{"position":"absolute","z-index":3,"top":"113px","left":"116px","letter-spacing":"9px",
"font-family":"anhduy1","font-size":"44px","color":"white","width":"92px","height":"46px","lineHeight":"52px","text-align":"center","background":"linear-gradient(to bottom, white 0%, rgba(255, 255, 255, 0) 90%)","-webkit-background-clip":"text","-webkit-text-fill-color":"transparent"},



"dayabdatemonth":{"position":"absolute","z-index":3,"top":"161px","left":"87px","font-family":"anhduy3","font-size":"25px","color":"white","width":"144px","text-align":"center","height":"42px","letter-spacing":"-2.5px","text-transform":"","text-shadow":"","font-weight":"normal","text-decoration":"none","font-style":"initial","data-prefix":"","-webkit-box-reflect":"below -28px linear-gradient(rgba(255, 255, 255, 0) 27%, rgba(255, 255, 255, 0.61))","lineHeight":"47px"},



"highdashlowdeg":{"position":"absolute","z-index":"2","top":"338px","left":"102px","font-family":"anhduy4","font-size":"18px","color":"white","width":"116px","text-align":"center","height":"30px","lineHeight":"30px"},



"boxCircleFour":{"width":"199px","height":"192px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"52px","left":"58px","border-radius":"999px","font-family":"anhduy","font-size":"30px","color":"white","data-image":"https://i.imgur.com/VQfoRyE.png","background-size":"cover","background-repeat":"no-repeat"}},"iconName":"wth"}