(function(window, doc) {

    var clockShown = true;

    function removeClock() {
        clockShown = false;
    }

    function CountdownTracker(value, style) {
        var el = document.createElement('span');
        el.className = 'flip-clock__piece';
        el.innerHTML = '<b class="flip-clock__card card"><b class="card__top"></b><b class="card__bottom"></b><b class="card__back"><b class="card__bottom"></b></b></b>';
        this.el = el;

        var top = el.querySelector('.card__top'),
            bottom = el.querySelector('.card__bottom'),
            back = el.querySelector('.card__back'),
            backBottom = el.querySelector('.card__back .card__bottom');

            if(style === 'whitebg'){
                addStyleString('  .card__top,.card__bottom,.card__back::before,.card__back::after {color:#222; background:#ccc;}', 'flipcolors1');
                addStyleString('.card__bottom{color:black; background:white;}', 'flipcolors2');
            }else{
                var c = document.getElementById('flipcolors1');
                var c2 = document.getElementById('flipcolors2');
                if(c){
                    c.parentElement.removeChild(c);
                }
                if(c2){
                    c2.parentElement.removeChild(c2);
                }
            }

        this.update = function(val) {
            val = ('0' + val).slice(-2);
            if (val !== this.currentValue) {

                if (this.currentValue >= 0) {
                    back.setAttribute('data-value', this.currentValue);
                    bottom.setAttribute('data-value', this.currentValue);
                }
                this.currentValue = val;
                top.innerText = this.currentValue;
                backBottom.setAttribute('data-value', this.currentValue);

                this.el.classList.remove('flip');
                void this.el.offsetWidth;
                this.el.classList.add('flip');
            }
        }
        this.update(value);
    }

    function getTime() {
        var t = new Date();
        return {
            'Total': t,
            'Hours': (t.getHours() % 12 === 0) ? 12 : t.getHours() % 12,
            'Minutes': t.getMinutes(),
            'Seconds': t.getSeconds()
        };
    }

    function Clock(div, showSeconds, style) {
        var flipClock = doc.getElementById('flipClock');
        if(flipClock){
          flipClock.parentElement.removeChild(flipClock);
        }
        this.el = document.createElement('div');
        this.el.id = 'flipClock';
        this.el.className = 'flip-clock';

        div.appendChild(this.el);

        var trackers = {},
            t = getTime(),
            key, timeinterval;

        for (key in t) {
            if (key === 'Total') {
                continue;
            }
            if (!showSeconds && key === 'Seconds') {
                continue;
            }
            trackers[key] = new CountdownTracker(t[key], style);
            this.el.appendChild(trackers[key].el);
        }

        var i = 0;

        function updateClock() {
            if (clockShown) {
                timeinterval = requestAnimationFrame(updateClock);
                // throttle so it's not constantly updating the time.
                if (i++ % 10) {
                    return;
                }
                var t = getTime();
                for (key in trackers) {
                    trackers[key].update(t[key]);
                }
            }
        }
        setTimeout(updateClock, 500);
    }

    function initExternalMethods() {
        var externalMethods = {};
        externalMethods.create = function(div) {
            var seconds = false;
            var style = 'blackbg';
            if(typeof div.style['coloroptions'] != 'undefined'){
                if(div.style['coloroptions'] === 'whitebg'){
                    style = 'whitebg';
                }
            }
            if(typeof div.style['flipclockseconds'] != 'undefined'){
                if(div.style['flipclockseconds']){
                    seconds = false;
                }else{
                    seconds = true;
                }
            }
            return new Clock(div, seconds, style);
        };
        externalMethods.remove = function() {
            removeClock();
        };
        return externalMethods;
    }
    window.flipClock = initExternalMethods();
}(window, document));
