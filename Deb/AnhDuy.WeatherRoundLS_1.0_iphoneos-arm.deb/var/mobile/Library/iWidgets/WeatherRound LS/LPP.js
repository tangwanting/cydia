/* Created by LockPlus Pro by JunesiPhone http://twitter.com/junesiphone This is for personal use only. You cannot sell this widget. If you want to sell a widget code your own. */ var savedElements = {"overlay":"","placedElements":{

"box":{"left":18,"border-color":"#ffffff","border-width":"1px","position":"absolute","border-radius":"999px","width":"285px","font-family":"helvetica","font-size":"30px","color":"white","height":"285px","background-color":"transparent","z-index":"30","border-style":"solid","top":112.2},


"box3":{"left":18,"border-color":"#ffffff","border-width":"1.5px","position":"absolute","border-radius":"999px","width":"285px","font-family":"helvetica","font-size":"30px","color":"white","height":"285px","background-color":"transparent","z-index":"30","border-style":"solid","top":112.2},



"box1":{"left":38,"border-color":"#ffffff","border-width":"1px","position":"absolute","border-radius":"999px","width":"245px","font-family":"helvetica","font-size":"30px","color":"white","height":"245px","background-color":"transparent","z-index":"30","border-style":"solid","top":133},


"box4":{"left":37,"border-color":"#ffffff","border-width":"1.5px","position":"absolute","border-radius":"999px","width":"245.9px","font-family":"helvetica","font-size":"30px","color":"white","height":"245.9px","background-color":"transparent","z-index":"30","border-style":"solid","top":132.2},


"box2":{"left":19,"border-color":"rgb(142, 134, 109)","border-width":"20px","position":"absolute","border-radius":"999px","width":"245px","font-family":"helvetica","font-size":"30px","color":"white","height":"245px","background-color":"transparent","z-index":"20","border-style":"solid","top":113.6,"display":"none "},



"icon":{"height":"245.00px","position":"absolute","font-family":"helvetica","color":"white","font-size":"30px","width":"245.00px","background-color":"rgba(0, 0, 0, 0)","z-index":0,"top":"133.5px","left":"38.8px","border-top-right-radius":"0.00px"},


"day1icon":{"height":"30px","position":"absolute","font-family":"helvetica","color":"white","width":"30px","z-index":40,"top":"110px","left":"145.5px","font-size":"30px"},


"day2icon":{"height":"30px","position":"absolute","font-family":"helvetica","color":"white","width":"30px","z-index":40,"top":"203px","left":"272px","font-size":"30px"},


"day3icon":{"height":"30px","position":"absolute","font-family":"helvetica","color":"white","width":"30px","z-index":40,"top":"347px","left":"226px","font-size":"30px"},


"day4icon":{"height":"30px","position":"absolute","font-family":"helvetica","color":"white","width":"30px","z-index":40,"top":"349px","left":"71px","font-size":"30px"},


"day5icon":{"height":"30px","position":"absolute","font-family":"helvetica","color":"white","width":"30px","z-index":40,"top":"203px","left":"21px","font-size":"30px"},


"dayabdatemonth":{"left":"0px","position":"absolute","z-index":47,"top":"37px","font-family":"anhduy2","word-spacing":"-1px","text-transform":"uppercase","font-size":"30px","color":"#ffffff","width":"320px","height":"50.00px","word-spacing":"-1px","lineHeight":"36px","-webkit-transform":"rotate(0.00deg)","white-space":"normal","text-align":"center","text-shadow":"1px -1px 2px rgb(11, 23, 16)"},


"phonename2":{"left":"0px","position":"absolute","z-index":5000,"top":"69px","font-family":"anhduy","font-size":"15.00px","color":"#ffffff","width":"320px","height":"31.00px","lineHeight":"31.00px","white-space":"normal","text-align":"center","word-spacing":"0px","text-shadow":"0px 1px 0px rgb(0,0,0)"},


"ttext":{"left":"0px","position":"absolute","z-index":47,"top":"418px","font-family":"anhduy2","font-size":"30px","word-spacing":"-3px","text-transform":"uppercase","color":"#ffffff","width":"320px","height":"50px","lineHeight":"36px","-webkit-transform":"rotate(0.00deg)","white-space":"normal","text-align":"center","text-shadow":"1px -1px 2px rgb(11, 23, 16)"},


"lngwstring":{"left":"5px","position":"absolute","word-spacing":"0px","z-index":5000,"top":"452px","word-spacing":"-1px","font-family":"anhduy","font-size":"15.00px","color":"#ffffff", "-webkit-text-stroke-width":"0.1px","-webkit-text-stroke-color":"#ffffff","width":"320px","height":"31px","lineHeight":"25px","white-space":"normal","text-align":"center","text-shadow":"0px 1px 0px rgb(0,0,0)"}},

"iconName":"custover","1iconName":"custover" }