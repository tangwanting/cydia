var twentyfourhour = true;
var pad = true;
var IconSet = "Stardock";
window.requestAnimFrame = (function () {
    return window.requestAnimationFrame || window.webkitRequestAnimationFrame;
}());
function clock(options) {
    var getTimes = function () {
        var d = new Date(),
            funcs = {
                hour: function () {
                    var hour = (options.twentyfour === true) ? d.getHours() : (d.getHours() + 11) % 12 + 1;
                    hour = (options.padzero === true) ? (hour < 10 ? "0" + hour : "" + hour) : hour;
                    return hour;
                },
               rawhour: function () {
                    return d.getHours();
                },
                minute: function () {
                    return (d.getMinutes() < 10) ? "0" + d.getMinutes() : d.getMinutes();
                },
                rawminute: function () {
                    return d.getMinutes();
                },
                date: function () {
                    return d.getDate();
                },
                 datepadded: function () {
                        return (d.getDate() < 10) ? "0" + d.getDate() : d.getDate();
                    },
                day: function () {
                    return d.getDay();
                },
                month: function () {
                    return d.getMonth();
                },
               hourtext: function () {
                    var hourtxt = (options.twentyfour === true) ? ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen", "Twenty", "Twenty One", "Twenty Two", "Twenty Three", "Twenty Four"] : ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve"];
                    return hourtxt[this.rawhour()];
                },
                minuteonetext: function () {
                    var minuteone = [];
                    if (minuteone[this.rawminute()] !== undefined) {
                        return minuteone[this.rawminute()];
                    }
                    return "";
                },
                smonthtext: function () {
                    return textmonth[this.month()];
                },
                nth: function (d) {
                    if (d > 3 && d < 21) {
                        return '';
                    }
                    switch (d % 10) {
                    case 1:
                        return "";
                    case 2:
                        return "";
                    case 3:
                        return "";
                    default:
                        return "";
                }
                },
                dateplus: function () {
                    return this.date() + this.nth(Number(this.date()));
                }
            };
        options.success(funcs);
        setTimeout(function () {
            window.requestAnimFrame(getTimes);
        }, options.refresh);
    };
    getTimes();
}
var current = (window.navigator.language.length >= 2) ? window.navigator.language.split('-')[0] : 'vi',
    $$ = function (el) {
        return document.getElementById(el);},      
    translate = {vi: {sday: [],
            smonth: ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"],
           condition: []}      
    };
if (!translate[current]) {
    current = 'vi';}