var Scale = "0.9"; // kích thước widget
var Clock = "24h"; // chọn giữa 12h hoặc 24h
var refreshrate = 10; // thời gian cập nhật thời tiết tính bằng phút
var PlayerColor = ""; // màu nhạc
var TextColor = ""; // màu chữ
var LineColor = "azure"; // màu khung giờ phút và ngày : azure
var DotColor = "coral"; // màu dấu chấm : coral
var IndicatorBattColor = "tomato"; // màu % pin : tomato
var WeatherIcon = 1; // chọn gói biểu tượng thời tiết: 1 = trắng, 2 = đen, 3 = màu
var DarkMode = false; // chế độ tối
var HidePlayer = true; // ẩn trình phát nhạc
var HideBattery = false; // ẩn pin
var CustomText = "hello Boss"; 
