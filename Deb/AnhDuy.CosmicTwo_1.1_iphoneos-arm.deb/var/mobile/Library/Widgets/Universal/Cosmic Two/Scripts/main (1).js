window.addEventListener("load", function() { 
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);

function updateClock() { 
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
var currentMonth = currentTime.getMonth() + 1;
var currentDate1 = currentTime.getDate() - 1;
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

if (Clock == "24h"){
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
}
if (Clock == "12h"){
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentHours = ( currentHours == 0 ) ? "12" : currentHours;
	currentHours = ( currentHours == 13 ) ? "01" : currentHours;
	currentHours = ( currentHours == 14 ) ? "02" : currentHours;
	currentHours = ( currentHours == 15 ) ? "03" : currentHours;
	currentHours = ( currentHours == 16 ) ? "04" : currentHours;
	currentHours = ( currentHours == 17 ) ? "05" : currentHours;
	currentHours = ( currentHours == 18 ) ? "06" : currentHours;
	currentHours = ( currentHours == 19 ) ? "07" : currentHours;
	currentHours = ( currentHours == 20 ) ? "08" : currentHours;
	currentHours = ( currentHours == 21 ) ? "09" : currentHours;
	currentHours = ( currentHours == 22 ) ? "10" : currentHours;
	currentHours = ( currentHours == 23 ) ? "11" : currentHours;
	currentHours = ( currentHours == 24 ) ? "12" : currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
}

document.getElementById("bue").innerHTML = hoy[currentTime.getHours()] + "&nbsp;" + hoys[currentTime.getHours()];
document.getElementById("efm").innerHTML = days[currentTime.getDay()].slice(0,9) + "&nbsp;" + currentDate + "&nbsp;" + months[currentTime.getMonth()].slice(0,9);
document.getElementById("hm").innerHTML = currentHours + ":" + currentMinutes;
document.getElementById("ap").innerHTML = timeOfDay;
document.getElementById("neu").innerHTML = proto;
}

function checkWeather(newData){

document.getElementById('pue').innerHTML = newData.metadata.address.city + ".";
document.getElementById("pai").innerHTML = newData.metadata.address.countryISOCode;
document.getElementById('cli').innerHTML = newData.now.temperature.current + "&deg;" + newData.units.temperature + "&nbsp;" + WeatherDesc[newData.now.condition.code];
   }

	api.weather.observeData(function (newData) {
	  	checkWeather(newData);
	});

function checkBattery(newData){

document.getElementById('pila').innerHTML = newData.battery.percentage + "%";

   if (newData.battery.state === 1) {

document.getElementById('neu').style.display = 'block';
        } else {

document.getElementById('neu').style.display = 'none';
        }
}

	api.resources.observeData(function (newData) {
		checkBattery(newData);
	});

function checkMusic(newData){
         if (newData.isPlaying) {

with (document) {
    getElementById('foto').style.display = 'block';
    getElementById('pue').style.display = 'none';
    getElementById('pai').style.display = 'none';
    getElementById('cli').style.display = 'none';
    getElementById('mus').style.display = 'block';
    getElementById('tup').style.display = 'block';
  }
        } else {

with (document) {
    getElementById('foto').style.display = 'none';
    getElementById('mus').style.display = 'none';
    getElementById('tup').style.display = 'none';
    getElementById('pue').style.display = 'block';
    getElementById('pai').style.display = 'block';
    getElementById('cli').style.display = 'block';
  }
}

document.getElementById('foto').src = newData.nowPlaying.artwork.length > 0 ? newData.nowPlaying.artwork : 'xui://resource/default/media/no-artwork.svg';
document.getElementById('mus').innerHTML = newData.nowPlaying.title;
document.getElementById('tup').innerHTML = newData.nowPlaying.artist;
        }

api.media.observeData(function (newData) {
		checkMusic(newData);
	});

function saltaApp(app){
	api.apps.launchApplication(app);
}

	api.media.observeData(function (newData) {
		ahoRepro = newData.nowPlayingApplication.identifier;
		checkMusic(newData);
	});

function init(){
updateClock();
setInterval("updateClock();", 1000);

var sheet = document.createElement('style')
sheet.innerHTML = ".mtn{color: "+ RegardsColor +";} .hora{color: "+ ClockColor +";} .cal{color: "+ CalendarColor +";} .mtn{color: "+ RegardsColor +";} .ciu{color: "+ CityColor +";} .calo{color: "+ WeatherColor +";} .bate{color: "+ BatteryColor +";} .lin{color: "+ StrokeColor +";} .fon{display: "+ Background +";} .dos{background: "+ BackgroundColor +";}";
document.body.appendChild(sheet);

(function(){
    'use strict';
document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=' + Scale/1.0 + ', maximum-scale=' + Scale/1.0 + ', user-scalable=0');
   }());
}