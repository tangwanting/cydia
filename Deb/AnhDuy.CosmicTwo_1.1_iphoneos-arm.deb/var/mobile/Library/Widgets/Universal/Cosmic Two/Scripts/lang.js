//Translation for major components. Originally by Junesiphone, modified by Evelyn (@ev_ynw) and (@luis9_49)//

if (Lang == "vi") {
    var dates = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"];
    var hoy = ["chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào"];
    var hoys = ["buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi chiều", "buổi chiều", "buổi chiều", "buổi chiều", "buổi chiều", "buổi chiều", "buổi chiều", "buổi tối", "buổi tối", "buổi tối", "buổi tối", "buổi tối", "buổi tối"];
    var days = ["CN", "thứ 2", "thứ 3", "thứ 4", "thứ 5", "thứ 6", "thứ 7"];
    var months = ["tháng 01", "tháng 02", "tháng 03", "tháng 04", "tháng 05", "tháng 06", "tháng 07", "tháng 08", "tháng 09", "tháng 10", "tháng 11", "tháng 12"];
    var son = ["Nó là"];
    var bater = ["pin"];
    var proto = ["đang sạc"];
}
