var Scale = "1.0"; // chỉnh kích thước ví dụ : 0.8
var ScaleFix = "100"; // để thay đổi thang đo cố định (Ví dụ cho Thiết bị Plus thay đổi thành 90)
var Clock = "24h"; // chọn giữa 12h hoặc 24h
var Lang = "vi"; // chọn ngôn ngữ: vi   en ...
var refreshrate = 10; // cập nhật khoảng thời gian trong vài phút
var IconWeather = "2"; // 1 = Trắng, 2 = Đen
var BlurBackground = false; // nền mờ (phải ẩn nền phía dưới mới có tác dụng)
var HideBackground = true; // ẩn nền
var BackgroundColor = "azure"; // màu nền chính : azure   grey   Cyan   Red   Black ...
var TextColor = "black"; // màu chữ
var TriangleColor = "coral"; // màu nền pin, thứ và hai tam giác : coral ...
