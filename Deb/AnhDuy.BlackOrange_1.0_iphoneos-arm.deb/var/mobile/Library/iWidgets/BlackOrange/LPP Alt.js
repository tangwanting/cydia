/* Created by LockPlus Pro by JunesiPhone http://twitter.com/junesiphone This is for personal use only. You cannot sell this widget. If you want to sell a widget code your own. */ var savedElements = {"placedElements":{"year":{"position":"absolute","z-index":3,"top":214,"left":20,"font-family":"fortuna","font-size":"100px","color":"#909090","height":"130px","width":"292px"},


"boxOne":{"width":"25px","height":"90px","background-color":"rgba(255, 255, 255, 0)","z-index":4,"border-color":"rgb(255, 255, 255)","border-style":"solid","border-width":"1px","position":"absolute","top":"212px","left":"145px"},


"boxTwo":{"width":"25px","height":"90px","background-color":"rgba(255, 0, 0, 0)","z-index":5,"border-color":"rgb(255, 255, 255)","border-style":"solid","border-width":"1px","position":"absolute","top":"248px","left":"60px"},


"clock":{"position":"absolute","z-index":7,"top":"223px","left":"102px","font-family":"gido","font-size":"24px","letter-spacing": "5px", "color":"white","width":"113px","-webkit-transform":"rotate(-90deg)"},


"day":{"position":"absolute","z-index":7,"top":"259.5px","left":"16px","font-family":"gido","font-size":"24px","color":"white","width":"113px","-webkit-transform":"rotate(-90deg)"},


"boxThree":{"width":"25px","height":"90px","background-color":"rgba(255, 0, 0, 0)","z-index":8,"border-color":"rgb(255, 255, 255)","border-style":"solid","border-width":"1px","position":"absolute","top":"248px","left":"228px"},


"month":{"position":"absolute","z-index":9,"top":"266px","left":"188px","font-family":"gido","font-size":"23px","color":"white","width":"106px","-webkit-transform":"rotate(-90deg)"}}}