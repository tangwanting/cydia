/* Created by LockPlus Pro by JunesiPhone http://twitter.com/junesiphone This is for personal use only. You cannot sell this widget. If you want to sell a widget code your own. */ var savedElements = {"placedElements":{"year":{"position":"absolute","z-index":3,"top":214,"left":22.5,"font-family":"fortuna","font-size":"100px","color":"white","height":"130px","width":"292px","background":"linear-gradient(to bottom, rgb(88, 88, 88) 54%, rgb(235, 64, 52) 90%)","-webkit-background-clip":"text","-webkit-text-fill-color":"transparent"},


"boxOne":{"width":"25px","height":"90px","background-color":"rgba(255, 255, 255, 0)","z-index":4,"border-color":"rgb(255, 255, 255)","border-style":"solid","border-width":"1px","position":"absolute","top":"212px","left":"145px"},


"boxTwo":{"width":"25px","height":"90px","background-color":"rgba(255, 0, 0, 0)","z-index":5,"border-color":"rgb(255, 255, 255)","border-style":"solid","border-width":"1px","position":"absolute","top":"248px","left":"60px"},


"zclock":{"position":"absolute","z-index":7,"top":"225px","left":"102px","font-family":"gido","font-size":"24px","letter-spacing": "5px", "color":"#17A7FB","width":"113px","-webkit-transform":"rotate(-90deg)"},


"day":{"position":"absolute","z-index":7,"top":"259.5px","left":"16px","font-family":"gido","font-size":"24px","color":"#56F371","width":"113px","-webkit-transform":"rotate(-90deg)"},


"boxThree":{"width":"25px","height":"90px","background-color":"rgba(255, 0, 0, 0)","z-index":8,"border-color":"rgb(255, 255, 255)","border-style":"solid","border-width":"1px","position":"absolute","top":"248px","left":"228px"},


"month":{"position":"absolute","z-index":9,"top":"266px","left":"188px","font-family":"gido","font-size":"23px","color":"#56F371","width":"106px","-webkit-transform":"rotate(-90deg)"}}}