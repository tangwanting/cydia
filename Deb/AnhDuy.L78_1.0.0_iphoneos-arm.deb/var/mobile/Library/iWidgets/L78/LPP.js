/* Created by LockPlus Pro by JunesiPhone http://twitter.com/junesiphone This is for personal use only. You cannot sell this widget. If you want to sell a widget code your own. */ var savedElements = {"overlay":"","placedElements":{"zhour":{"position":"absolute","font-family":"bebasbold","color":"white","z-index":"9999","top":109,"left":"62px","font-size":"30px"},


"textEight":{"position":"absolute","font-family":"anhduy1","color":"white","width":"18px","innerHTML":"phút","z-index":"9999","top":174,"left":"108px","font-size":"12px"},


"textTwo":{"height":"11px","position":"absolute","font-family":"anhduy1","color":"white","width":"26px","innerHTML":"thứ","z-index":"2","top":84,"left":"152px","font-size":"12px"},


"sday":{"position":"absolute","font-family":"bebasbold","color":"white","z-index":"9999","top":"109px","left":"149px","font-size":"29px"},



"datepad":{"position":"absolute","font-family":"bebasbold","color":"white","z-index":"9999","top":"136px","left":"191px","font-size":"30px"},


"textNine":{"position":"absolute","font-family":"anhduy1","color":"white","width":"18px","innerHTML":"tháng","z-index":"9999","top":84,"left":"234px","font-size":"12px"},


"monthDPadded":{"position":"absolute","font-family":"bebasbold","color":"white","z-index":"9999","top":109,"left":"234px","font-size":"30px"},


"textOne":{"position":"absolute","font-family":"anhduy1","color":"white","width":"18px","innerHTML":"giờ","z-index":"9999","top":"84px","left":"68px","font-size":"12px"},


"textSeven":{"position":"absolute","font-family":"ESRIGeometricSymbols","color":"rgb(236, 236, 236)","innerHTML":"i","left":"91px","top":"101px","z-index":"9999","font-size":"77px","background-color":"rgba(0, 0, 0, 0)"},



"phonename3":{"position":"absolute","font-family":"anhduy","color":"white","left":"84px","z-index":"2","top":"61px","text-align":"center","font-size":"16px"},


"textThree":{"position":"absolute","font-family":"ESRIGeometricSymbols","color":"rgb(236, 236, 236)","innerHTML":"i","left":"48px","z-index":"9999","top":73,"font-size":"77px","background-color":"rgba(0, 0, 0, 0)"},



"textFive":{"position":"absolute","font-family":"ESRIGeometricSymbols","color":"rgb(236, 236, 236)","innerHTML":"i","left":"177px","top":101,"z-index":"9999","font-size":"77px","background-color":"rgba(0, 0, 0, 0)"},


"textTen":{"position":"absolute","font-family":"anhduy1","color":"white","width":"18px","innerHTML":"ngày","z-index":"9999","top":174,"left":"193px","font-size":"12px"},



"textSix":{"position":"absolute","font-family":"ESRIGeometricSymbols","color":"rgb(236, 236, 236)","innerHTML":"i","left":134,"top":73,"z-index":"9999","font-size":"77px","background-color":"rgba(0, 0, 0, 0)"},


"minute":{"position":"absolute","font-family":"bebasbold","color":"white","z-index":"9999","top":136,"left":"105px","font-size":"30px"},


"textFour":{"position":"absolute","font-family":"ESRIGeometricSymbols","color":"rgb(236, 236, 236)","innerHTML":"i","left":"220px","top":73,"z-index":"9999","font-size":"77px","background-color":"rgba(0, 0, 0, 0)"}},"iconName":"primusweather"}