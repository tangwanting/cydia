/* Created by LockPlus Pro by JunesiPhone http://twitter.com/junesiphone This is for personal use only. You cannot sell this widget. If you want to sell a widget code your own. */ var savedElements = {"placedElements":{"lngwstring3":{"position":"absolute","font-family":"bariolbold","color":"white","width":"283px","left":14,"z-index":"2","top":639,"font-size":"10px","height":"31px","background":"linear-gradient(to bottom, rgb(140, 135, 134) 0%, rgb(39, 38, 38) 90%)","-webkit-background-clip":"text","-webkit-text-fill-color":"transparent"},


"textOne":{"-webkit-background-clip":"text","position":"absolute","font-family":"HelveticaNeue","color":"white","innerHTML":"chào","-webkit-text-fill-color":"transparent","z-index":"2","top":531,"left":26,"font-size":"25px","background":"linear-gradient(to bottom, rgb(255, 255, 255) 0%, rgb(39, 38, 38) 90%)"},


"tod":{"-webkit-background-clip":"text","position":"absolute","font-family":"HelveticaNeue","color":"white","-webkit-text-fill-color":"transparent","z-index":"2","top":552,"left":"63px","font-size":"23px","background":"linear-gradient(to bottom, rgb(255, 255, 255) 0%, rgb(39, 38, 38) 90%)"},


"sy45":{"position":"absolute","font-family":"helvetica","color":"white","z-index":"2","top":541,"left":"46px","font-size":"30px","-webkit-transform":"rotate(49deg)","background":"linear-gradient(to bottom, rgb(255, 255, 255) 0%, rgb(39, 38, 38) 90%)","-webkit-background-clip":"text","-webkit-text-fill-color":"transparent"},


"zclock":{"position":"absolute","z-index":3,"top":"579px","left":30,"font-family":"bebasbold","font-size":"40px","color":"white","background":"linear-gradient(to bottom, rgb(156, 156, 156) 0%, rgb(39, 38, 38) 90%)","-webkit-background-clip":"text","-webkit-text-fill-color":"transparent","width":"86px","height":"50px"},


"icon":{"position":"absolute","z-index":6,"top":"546px","left":"229px","font-family":"helvetica","font-size":"30px","color":"white","width":"92px","height":"92px"},



"dayabdatemonth":{"left":"14px","position":"absolute","z-index":7,"top":"614.5px","font-family":"HelveticaNeue","font-size":"17px","color":"white","background":"linear-gradient(to bottom, rgb(218, 218, 218) 0%, black 90%)","-webkit-background-clip":"text","-webkit-text-fill-color":"transparent","height":"25px"},


"textTwo":{"position":"absolute","z-index":8,"top":"-5px","left":"75px","font-family":"HelveticaNeue","font-size":"75px","color":"white","innerHTML":"Hello","background":"linear-gradient(to bottom, rgb(153, 153, 153) 0%, black 90%)","-webkit-background-clip":"text","-webkit-text-fill-color":"transparent","width":"168px","height":"133px"},




"boxOne":{"width":"109px","height":"4px","background-color":"transparent","z-index":9,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"596px","left":"113px","background":"linear-gradient(to bottom, rgb(140, 135, 134) 0%, black 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"}},


"iconName":"mauri","overlay":""}