var savedElements = {"placedElements":{"boxOne":{"width":"320px","height":"592px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"12px","left":"0px","font-family":"helvetica","font-size":"30px","color":"white","data-image":"https://i.imgur.com/I2WxqH1.png","background-size":"cover","background-repeat":"no-repeat"},



"boxTwo":{"width":"290px","height":"515px","background-color":"rgba(255, 255, 255, 0)","z-index":0,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"58px","left":"15px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"30px","-webkit-backdrop-filter":"blur(5px)"},




"icon":{"position":"absolute","z-index":"2","top":"517px","left":"139px","font-family":"helvetica","font-size":"30px","color":"white","width":"42px","height":"42px"},



"zclock":{"position":"absolute","z-index":"2","top":"42px","left":"120px","font-family":"DeadmanItalic-axVnJ","font-size":"20px","color":"rgb(243, 173, 60)","width":"82px","text-align":"center","text-shadow":"1px 2px 1px rgb(0,0,0)","height":"17px","letter-spacing":"2px"},




"dayabdatemonth":{"position":"absolute","z-index":"2","top":"64px","left":"60px","font-family":"anhduy2", "letter-spacing":"0px",  "font-size":"15px","color":"rgb(243, 173, 60)","width":"200px","text-align":"center","height":"28px","text-shadow":"1px 1px 1px rgb(0,0,0)","lineHeight":"25px","background":"inherit","-webkit-background-clip":"inherit","-webkit-text-fill-color":"initial","text-transform":"uppercase"},


"condition":{"position":"absolute","z-index":"2","top":"572px","left":"60px","font-family":"anhduy5", "letter-spacing":"3px", "font-size":"10px","color":"rgb(243, 173, 60)","width":"200px","height":"16px","lineHeight":"14px","text-align":"center","text-shadow":"0px 1px 1px rgb(0,0,0)"},




"tempdegplus":{"position":"absolute","z-index":"2","top":"539px","left":"65px","font-family":"DeadmanItalic-axVnJ","font-size":"14px","color":"rgb(243, 173, 60)","width":"64px","height":"24px","text-align":"center","lineHeight":"22px","text-shadow":"1px 1px 1px rgb(0,0,0)","letter-spacing":"2px"},




"highdashlowdeg":{"position":"absolute","z-index":"2","top":"543px","left":"191px","font-family":"DeadmanItalic-axVnJ","font-size":"14px","color":"rgb(243, 173, 60)","width":"66px","text-align":"center","text-shadow":"1px 1px 1px rgb(0,0,0)","height":"18px"}},"iconName":"custover"}