//Translation for major components. Originally by Junesiphone, modified by Evelyn (@ev_ynw) and (@luis9_49)//

if (Lang == "en") {
    var date = ["1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th", "9th", "10th", "11th", "12th", "13th", "14th", "15th", "16th", "17th", "18th", "19th", "20th", "21st", "22nd", "23rd", "24th", "25th", "26th", "27th", "28th", "29th", "30th", "31st"];
    var today = ["chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào"];
    var todays = ["Buổi sáng", "Buổi sáng", "Buổi sáng", "Buổi sáng", "Buổi sáng", "Buổi sáng", "Buổi sáng", "Buổi sáng", "Buổi sáng", "Buổi sáng", "Buổi sáng", "Buổi sáng", "Buổi chiều", "Buổi chiều", "Buổi chiều", "Buổi chiều", "Buổi chiều", "Buổi chiều", "Buổi chiều", "buổi tối", "buổi tối", "buổi tối", "buổi tối", "buổi tối", "buổi tối"];
    var days = ["chủ nhật", "Monday", "Tuesday", "Wednesday", "Thursday", "Thứ sáu", "Saturday"];
    var dun = ["", "", "", "", "", "", ""];
    var dos = ["chủ nhật", "thứ hai", "thứ ba", "Thứ tư", "Thứ năm", "thứ sáu", "thứ bẩy"];
    var shortdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "thứ sáu", "Sat"];
    var months = ["tháng 1", "tháng 2", "tháng 3", "Tháng 4", "tháng 5", "tháng 6", "tháng 7", "tháng 8", "tháng 9", "tháng 10", "tháng 11", "tháng 12"];
    var shortmonths = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Tháng 11", "Dec"];
    var proton = ["Charging..."];
}
if (Lang == "es") {
    var days = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
    var dun = ["D", "L", "M", "M", "J", "V", "S"];
    var dos = ["omingo", "unes", "artes", "iércoles", "ueves", "iernes", "ábado"];
    var months = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
    var shortmonths = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
    var shortdays = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
    var today = ["Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas"];
    var todays = ["Dias", "Dias", "Dias", "Dias", "Dias", "Dias", "Dias", "Dias", "Dias", "Dias", "Dias", "Dias", "Tardes", "Tardes", "Tardes", "Tardes", "Tardes", "Tardes", "Tardes", "Noches", "Noches", "Noches", "Noches", "Noches", "Noches"];
    var proton = ["Cargando..."];
}
if (Lang == "it") {
    var today = ["buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buon", "buon", "buon", "buon", "buon", "buon", "buon", "buona", "buona", "buona", "buona", "buona", "buona"];
    var todays = ["", "", "", "", "", "", "", "", "", "", "", "", "pomeriggio", "pomeriggio", "pomeriggio", "pomeriggio", "pomeriggio", "pomeriggio", "pomeriggio", "notte", "notte", "notte", "notte", "notte", "notte"];
    var days = ["Domenica", "Lunedi", "Martedì", "Mercoledì", "Giovedi", "Venerdì", "Sabato"];
    var dun = ["D", "L", "M", "M", "G", "V", "S"];
    var dos = ["omenica", "unedi", "artedì", "ercoledì", "iovedi", "enerdì", "abato"];
    var months = ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"];
    var shortmonths = ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"];
    var shortdays = ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
    var proton = ["Charging..."];
}
if (Lang == "de") {
    var today = ["Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten"];
    var todays = ["morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "nachmittag", "nachmittag", "nachmittag", "nachmittag", "nachmittag", "nachmittag", "nachmittag", "nacht", "nacht", "nacht", "nacht", "nacht", "nacht"];
    var days = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
    var dun = ["S", "M", "D", "M", "D", "F", "S"];
    var dos = ["onntag", "ontag", "ienstag", "ittwoch", "onnerstag", "reitag", "amstag"];
    var months = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];
    var shortmonths = ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];
    var shortdays = ["Son", "Mon", "Die", "Mit", "Don", "Fre", "Sam"];
    var proton = ["Charging..."];
}
if (Lang == "fr") {
    var today = ["Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonjour", "Bonne", "Bonne", "Bonne", "Bonne", "Bonne", "Bonne", "Bonne", "Bonsoir", "Bonsoir", "Bonsoir", "Bonsoir", "Bonsoir", "Bonsoir"];
    var todays = ["", "", "", "", "", "", "", "", "", "", "", "", "après-midi", "après-midi", "après-midi", "après-midi", "après-midi", "après-midi", "après-midi", "", "", "", "", "", ""];
    var days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
    var dun = ["D", "L", "M", "M", "J", "V", "S"];
    var dos = ["imanche", "undi", "ardi", "ercredi", "eudi", "endredi", "amedi"];
    var months = ["Janvie", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
    var shortmonths = ["Jan", "Fév", "Mar", "Avr", "Mai", "Jui", "Jui", "Aoû", "Sep", "Oct", "Nov", "Déc"];
    var shortdays = ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"];
    var proton = ["Charging..."];
}
if (Lang == "pt") {
    var today = ["bom", "bom", "bom", "bom", "bom", "bom", "bom", "bom", "bom", "bom", "bom", "bom", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa"];
    var todays = ["Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "tarde", "tarde", "tarde", "tarde", "tarde", "tarde", "tarde", "noite", "noite", "noite", "noite", "noite", "noite"];
    var days = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sabado"];
    var dun = ["D", "S", "T", "Q", "Q", "S", "S"];
    var dos = ["omingo", "egunda", "erça", "uarta", "uinta", "exta", "abado"];
    var shortdays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"];
    var months = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
    var shortmonths = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
    var proton = ["Charging..."];
}