window.addEventListener("load", function() { 
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);

function updateClock() { 
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
var currentMonth = currentTime.getMonth() + 1;
var currentDate1 = currentTime.getDate() - 1;
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

if (Clock == "24h"){
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
}
if (Clock == "12h"){
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentHours = ( currentHours == 0 ) ? "12" : currentHours;
	currentHours = ( currentHours == 13 ) ? "01" : currentHours;
	currentHours = ( currentHours == 14 ) ? "02" : currentHours;
	currentHours = ( currentHours == 15 ) ? "03" : currentHours;
	currentHours = ( currentHours == 16 ) ? "04" : currentHours;
	currentHours = ( currentHours == 17 ) ? "05" : currentHours;
	currentHours = ( currentHours == 18 ) ? "06" : currentHours;
	currentHours = ( currentHours == 19 ) ? "07" : currentHours;
	currentHours = ( currentHours == 20 ) ? "08" : currentHours;
	currentHours = ( currentHours == 21 ) ? "09" : currentHours;
	currentHours = ( currentHours == 22 ) ? "10" : currentHours;
	currentHours = ( currentHours == 23 ) ? "11" : currentHours;
	currentHours = ( currentHours == 24 ) ? "12" : currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
}

document.getElementById("hma").innerHTML = currentHours + ":" + currentMinutes;
document.getElementById("ap").innerHTML = timeOfDay;
document.getElementById("lmm").innerHTML = dun[currentTime.getDay()];
document.getElementById("jvs").innerHTML = dos[currentTime.getDay()];
document.getElementById("efm").innerHTML = shortmonths[currentTime.getMonth()] + "&nbsp;" + currentDate;
document.getElementById("bue").innerHTML = today[currentTime.getHours()] + "&nbsp;" + todays[currentTime.getHours()];
document.getElementById("yo").innerHTML = Name;
}

function checkMusic(newData){
         if (newData.isPlaying) {

var milli = new Date().getMilliseconds(), url = "/var/mobile/Documents/Artwork.jpg?" + milli;

document.getElementById('fo').style.backgroundImage = "url('" + url + "')";

document.getElementById('fo').style.display = 'block';

document.getElementById('su').style.display = 'block';

document.getElementById('lo').style.display = 'block';

document.getElementById('hh').style.color = CircleColor;

document.getElementById('hh').style.textShadow = "#000 1px 1px 1px";

document.getElementById('cc').style.color = CircleColor;

document.getElementById('cc').style.textShadow = "#000 1px 1px 1px";
        } else {

document.getElementById('fo').style.backgroundImage = "url('ArtworkDefault.jpg')";

document.getElementById('fo').style.display = 'none';

document.getElementById('su').style.display = 'none';

document.getElementById('lo').style.display = 'none';

document.getElementById('hh').style.color = ClockColor;

document.getElementById('hh').style.textShadow = "none";

document.getElementById('cc').style.color = CalendarColor;

document.getElementById('cc').style.textShadow = "none";
            }
	
	        if (newData.isStopped) {

document.getElementById('su').innerHTML = '';

document.getElementById('lo').innerHTML = '';
	}else{

document.getElementById('su').innerHTML = newData.nowPlaying.title;

document.getElementById('lo').innerHTML = newData.nowPlaying.artist;
    }
}

api.media.observeData(function (newData) {
		checkMusic(newData);
	});

function init(){
updateClock();
setInterval("updateClock();", 1000);

var sheet = document.createElement('style')
sheet.innerHTML = ".hmp{color:" + ClockColor + ";} .dias{color:" + WeekdayColor + ";} .cal{color:" + CalendarColor + ";} .temp{color:" + TemperatureColor + ";} .niv{color:" + BatteryColor + ";} .hey{color:" + RegardsColor + ";} #yo{color:" + NameColor + ";} .bo{color:" + CircleColor + ";} #su{color:" + SongColor + ";} #lo{color:" + ArtistColor + ";}";
document.body.appendChild(sheet);

(function(){
    'use strict';
document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=' + Scale/1.0 + ', maximum-scale=' + Scale/1.0 + ', user-scalable=0');
   }());
}