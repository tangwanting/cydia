var lang = "vi"; // Chọn ngôn ngữ: vi Việt nam, en tiếng Anh
var twentyfourhour = true; // bật 24 giờ
var pad = true; // bật để thêm số 0 trước giờ (số giờ nhỏ hơn 10)
var iconSet = "skt"; // Không sửa đổi
