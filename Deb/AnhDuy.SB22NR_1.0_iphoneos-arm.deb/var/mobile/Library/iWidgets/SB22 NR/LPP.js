/* Created by LockPlus Pro by JunesiPhone http://twitter.com/junesiphone This is for personal use only. You cannot sell this widget. If you want to sell a widget code your own. */ var savedElements = {"placedElements":{"boxOne":{"width":"255px","height":"175px","background-color":"transparent","z-index":"2","border-color":"rgb(94, 115, 76)","border-style":"solid","border-width":"0px","position":"absolute","top":"426px","left":"31px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, rgb(94, 115, 76) 0%, rgb(94, 115, 76) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","border-radius":"30px","box-shadow":"9px 10px 16px rgb(0, 0, 0,0.7), -9px -9px 16px rgb(0, 0, 0,0.7)","-webkit-transform":"rotate(0deg)"},


"boxTwo":{"width":"40px","height":"35px","background-color":"transparent","z-index":"2","border-color":"rgb(255, 0, 0)","border-style":"solid","border-width":"0px","position":"absolute","top":448,"left":257,"font-family":"helvetica","font-size":"30px","color":"white","border-radius":"11px","background":"linear-gradient(to top left, rgb(150, 106, 26) 0%, rgb(177, 125, 31) 90%, rgb(177, 125, 31) 0%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"1px 2px 2px rgba(0, 0, 0, 0.5), -1px -2px 2px rgba(0, 0, 0, 0.5)"},


"boxThree":{"width":"40px","height":"34px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"489px","left":"257px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"11px","background":"linear-gradient(to top left, rgb(150, 106, 26) 0%, rgb(177, 125, 31) 90%, rgb(177, 125, 31) 0%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"1px 2px 2px rgba(0, 0, 0, 0.15), -1px -2px 2px rgba(0, 0, 0, 0.5)"},


"textOne":{"position":"absolute","z-index":"2","top":"441px","left":"51px","font-family":"HelveticaNeue","font-size":"9px","color":"#000000","innerHTML":"chào ","width":"79px","height":"30px","text-transform":"capitalize","font-weight":"bold"},


"tod":{"position":"absolute","z-index":"2","top":"441px","left":"80px","font-family":"HelveticaNeue","font-size":"9px","color":"#000000","width":"98px","text-transform":"lowercase","font-weight":"bold"},


"textTwo":{"position":"absolute","z-index":"2","top":"456px","left":"51px","font-family":"HelveticaNeue","font-size":"15px","color":"#EBB15E","innerHTML":"Chúc một ngày tốt lành"},


"zhour":{"position":"absolute","text-align":"center","z-index":"2","top":"454px","left":"266px","font-family":"HelveticaNeue","font-size":"18px","color":"#000000","height":"27px","width":"31px"},


"minute":{"position":"absolute","text-align":"center","z-index":"2","top":"495px","left":"266px","font-family":"HelveticaNeue","font-size":"18px","color":"#000000"},



"dayabdatemonth":{"position":"absolute","z-index":"2","top":"504px","left":"51px","font-family":"HelveticaNeue","font-size":"12px","color":"#FE8501","width":"85px","height":"27px"},


"tempdeg":{"position":"absolute","z-index":"2","top":"546px","left":"51px","font-family":"HelveticaNeue","font-size":"20px","color":"#000000"},


"condition":{"position":"absolute","z-index":"2","top":"550px","left":"93px","font-family":"HelveticaNeue","font-size":"14px","color":"#000000","font-weight":"bold"},


"coloricon":{"position":"absolute","z-index":"2","top":"497px","left":"179px","font-family":"helvetica","font-size":"59px","color":"rgb(177, 125, 31)","background":"linear-gradient(to bottom right, rgb(150, 106, 26) 0%, rgb(177, 125, 31) 90%)","-webkit-background-clip":"text","-webkit-text-fill-color":"transparent","width":"80px","height":"74px"},


"textThree":{"position":"absolute","z-index":"2","top":"574px","left":"51px","font-family":"HelveticaNeue","font-size":"8px","color":"#EBB15E","innerHTML":"Độ ẩm :"},


"humidity":{"position":"absolute","z-index":"2","top":"575px","left":"81px","font-family":"HelveticaNeue","font-size":"8px","color":"#EBB15E"},


"textFour":{"position":"absolute","z-index":"2","top":"574px","left":"115px","font-family":"HelveticaNeue","font-size":"8px","color":"#EBB15E","innerHTML":"Tốc độ gió :","width":"48px","height":"18px"},


"wind":{"position":"absolute","z-index":"2","top":"575px","left":"159px","font-family":"HelveticaNeue","font-size":"8px","color":"#EBB15E","width":"49px","height":"16px"},



"batterypie":{"position":"absolute","z-index":"2","top":"559px","left":"238px","font-family":"helvetica","font-size":"30px","color":"Black","circle-width":"24px","circle-stroke-dasharray":"4px","inner-color":"#FE8501","outer-color":"#000000","circle-stroke-value":"14px","circle-stroke":"10px"},


"textFive":{"position":"absolute","z-index":"2","top":"455px","left":"164px","font-family":"helvetica","font-size":"15px","color":"rgba(202, 202, 203, 0.41)","innerHTML":"  ","font-weight":"bold"}}}