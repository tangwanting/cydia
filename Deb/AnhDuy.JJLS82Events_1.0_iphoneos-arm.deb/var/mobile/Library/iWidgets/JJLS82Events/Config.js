var lang = "vi"; // để trống hoặc chọn ngôn ngữ ở dây : en English, fr French, de German, it Italian, es Spanish, nl Dutch, fi Finland, no Norweigan, tr Turkish, el Greek, ru Russian, zh Chinese, hr Croatian, vi Vietnamese, id Indonesian, he Hebrew, am for US date format.
var twentyfourh = false; // chọn giữa "12h" hoặc "24h".
var pad = true; // thêm số 0 trước giờ nhỏ hơn 10
var calendarDate = false; // bật để hiển thị ngày / tháng thay vì chỉ ngày cho các sự kiện lịch
var monthDate = false; // bật sẽ hiển thị tháng trước ngày
var useDewWithHumidity = false; // giải pháp cho tập lệnh dịch uniaw
