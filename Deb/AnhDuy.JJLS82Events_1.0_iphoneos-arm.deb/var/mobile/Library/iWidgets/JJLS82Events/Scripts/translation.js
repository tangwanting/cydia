// UniAW original from Ian Nicoll & Dacal

// TRANSLATION FOR MAIN ELEMENTS, BASED ON UNIAW 6.3
// EXPANDED by NewD & am80ma for UniAW_X,2018,8,2020 & XH2
// EXPANDED by NewD, am80ma(de), Morkino(it,hr), Kristatos(es), Kerenza(vi), Tito12(he) & Jazz(id) for UniAW_XH2_V2
// SPECIAL THANKS! to Matchstic (@MattClarke) for the auto language detection from Phone Settings!

///////////////////////////////////////
//AUTO LANGUAGE DETECTION CODE

// A list of ISO-639-1 language codes that are supported by UniAW
const supportedLanguages = ["de", "es", "fr", "it", "no", "nl", "fi", "ru", "el", "hr", "tr", "zh", "vi", "id", "he", "ar", "en"];
//en English, fr French, de German, it Italian, es Spanish, nl Dutch, fi Finland, no Norweigan, tr Turkish, el Greek, ru Russian, zh Chinese, hr Croatian, vi Vietnamese, id Indonesian, he Hebrew
let chosenLanguage = "";

if (!lang || lang === "") { /* check against config.js - if not set, use phone language */
	const langcode = navigator.language.slice(0,2); // from phone language, get first two characters of language code - ignores region
    if (supportedLanguages.includes(langcode)) { /* check if we support it from array above */
        chosenLanguage = langcode;
    } else { 
        chosenLanguage = "en"; // fallback to 'en' (English)
    }
} else { /* use from Config.js */ 
    chosenLanguage = lang;
}

var lang = chosenLanguage; // Now, 'lang' is set to the 2-letter code in Config.js, or if that's blank, to the phone settings language

///////////////////////////////////////

switch (lang) {
	case "no": 
		var days = ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"];
		var months = ["Januar", "Februar", "Mars", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember"];
		var hightext = "Høy ";
		var lowtext = "Lav ";
		var sunrisetext ="Soloppgang";
		var sunsettext = "Solnedgang";
		var moonrisetext ="Måneoppgang";
		var moonsettext = "Månenedgang";		
		var feelsliketext = "Føles som ";
		var pressuretext = "Lufttrykk ";
		var lastupdatetext = "Oppdatert ";
		var xmlupdatetext = "Oppdatert kl ";
		var visibilitytext = "Sikt";
		var humiditytext = "Luftfuktighet ";
		var windtext = "Vind ";
		var UVIndextext = "UV ";
		var preciptext = "Precip ";
		var Dewpointtext = "Duggpunkt ";
        var forecasttext = "Varsel";
		var moontext = "Måne";
		var nowindtext = "Vindstille";
		var voltextimp = " in";
		var voltextmet = " mm";
		var disttextimp = "mile";
		var disttextmet = "km";
		var wsutextimp = "m/t";
		var wsutextmet = "km/t";
		var cloudtext = "Cloud Cover: ";
		var gusttext = "Vindkast";
		var datatext = "Datakilde";
		var nighttext = " kveld";
		var freeRAMtxt = "Free RAM:  ";
		var usedRAMtxt = "Used RAM:  ";
		var totalRAMtxt = "Tot.Usab.RAM:  ";
		var totalRAMPhystxt = "Tot.Phys.RAM:  ";
		var storagetxt = "MB";
		var batterytxt = "Battery: ";
		var unpluggedtxt = "Unplugged";
		var chargingtxt = "Charging";
		var fullchargetxt = "Fully Charged";
		var nexthourtext = "Next Hour: ";
		var christmastxt = "Merry Christmas";
		var newyeartxt = "Happy New Year";
		var fromtext = "From ";
		var WeatherDesc = [
			"Tornado",
			"Tropisk storm",
			"Orkan",
			"Kraftige tordenbyger",
			"Tordenbyger",
			"Blandet Regn og snø",
			"Blandet regn og sludd",
			"Blandet snø og sludd",
			"Underkjølt duskregn",
			"Duskregn",
			"Underkjølt regn",
			"Regnbyger",
			"Regn",
			"Snøbyger",
			"Lette snøbyger",
			"Snøfokk",
			"Snø",
			"Hagl",
			"Sludd",
			"Støv",
			"Tåke",
			"Dis",
			"Røykfylt",
			"Mye Vind",
			"Vindkuler",
			"Frost",
			"Skyet ",
			"Muligheter for regn",
			"Muligheter for regn",
			"Delvis skyet",
			"Delvis skyet",
			"Klart",
			"Solskinn",
			"Det meste klart",
			"For det meste sol",
			"Blandet regn og hagl",
			"Varmt",
			"Isolerte tordenbyger",
			"Spredte tordenbyger",
			"Spredte tordenbyger",
			"Spredte regnbyger",
			"Kraftig snøfall",
			"Spredte snøbyger",
			"Kraftig snøfall",
			"Delvis skyet",
			"Regn og torden",
			"Snøbyger",
			"Isolerte regn og torden",
			"ikke mottak"];
	break;
	case "fr":
		var days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
		var months = ["Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Decembre"];
		var hightext = "Max ";
		var lowtext = "Min ";
		var sunrisetext = "Lever";
		var sunsettext = "Coucher";
		var moonrisetext ="Lev. (lune)";
		var moonsettext = "Couc. (lune)";
		var feelsliketext = "Ressentie ";
		var lastupdatetext = "Vérifié à ";
		var xmlupdatetext = "Mis à jour à ";
		var humiditytext = "Humidité ";	
		var visibilitytext = "Visibilité ";	
		var pressuretext = "Pression ";
		var windtext = "Vent ";
		var UVIndextext = "Indice UV ";
		var preciptext = "Précip ";
		var Dewpointtext = "Point de rosée ";
        var forecasttext = "Prévision de";
		var moontext = "Lune";
		var nowindtext = "Pas de vent";
		var voltextimp = " in";
		var voltextmet = " mm";
		var disttextimp = "mile";
		var disttextmet = "km";
		var wsutextimp = "mi/h";
		var wsutextmet = "km/h";
		var cloudtext = "Cloud Cover: ";
		var gusttext = "Rafales";
		var datatext = "Source de données";
		var nighttext = " soir";
		var freeRAMtxt = "Free RAM:  ";
		var usedRAMtxt = "Used RAM:  ";
		var totalRAMtxt = "Tot.Usab.RAM:  ";
		var totalRAMPhystxt = "Tot.Phys.RAM:  ";
		var storagetxt = "MB";
		var batterytxt = "Batterie: ";
		var unpluggedtxt = "Débranché";
		var chargingtxt = "Charge";
		var fullchargetxt = "Chargée";
		var nexthourtext = "L'Heure Suivante: ";
		var christmastxt = "Joyeux Noël";
		var newyeartxt = "Bonne Année";
		var fromtext = "De ";
		var WeatherDesc = [
			"Tornade",
			"Orage tropical",
			"Ouragan",
			"Orages violents",
			"Orages",
			"Pluie et neige mélées",
			"Pluie et grêle mélées",
			"Neige et grêle mélées",
			"Bruine verglaçante",
			"Bruine",
			"Pluie verglaçante",
			"Averses",
			"Pluie",
			"Quelques flocons",
			"Faibles chutes de neige",
			"Rafales de neige",
			"Neige",
			"Grêle",
			"Neige fondue",
			"Poussiéreux",
			"Brouillard",
			"Brume",
			"Brumeux",
			"Tempête",
			"Vent",
			"Temps froid",
			"Temps nuageux ",
			"Très nuageux",
			"Très nuageux",
			"Partiellement nuageux",
			"Partiellement nuageux",
			"Ciel dégagé",
			"Ensoleillé",
			"Beau temps",
			"Beau temps",
			"Pluie et grêles mélées",
			"Temps chaud",
			"Orages isolés",
			"Orages éparses",
			"Orages éparses",
			"Averses éparses",
			"Fortes chutes de neige",
			"Chutes de neige éparses",
			"Fortes chutes de neige",
			"Partiellement nuageux",
			"Orages",
			"Chute de neige",
			"Orages isolés",
			"Non disponible"];
    break;
	case "de":
		var days = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
		var months = ["Januar", "Februar", "Maerz", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];
		var hightext = "Hoch ";
		var lowtext = "Tief ";
		var sunrisetext = "Morgen";
		var sunsettext = "Abend";
		var moonrisetext ="Mondaufgang";
		var moonsettext = "Monduntergang";
		var feelsliketext = "Gefühlte ";
		var lastupdatetext = "Geprüft ";
		var xmlupdatetext = "Aktualisiert ";
		var visibilitytext = "Sichtweite ";
		var humiditytext = "Luftfeuchte ";
		var pressuretext = "Luftdruck ";
		var windtext = "Wind ";
		var UVIndextext = "UV-index ";
		var preciptext = "Niederschlag ";
		var Dewpointtext = "Taupunkt ";
		var forecasttext = "Prognose";
		var moontext = "Mond";
		var nowindtext = "Kein wind";
		var voltextimp = " zoll";
		var voltextmet = " mm";
		var disttextimp = "mei";
		var disttextmet = "km";
		var wsutextimp = "mph";
		var wsutextmet = "km/h";
		var cloudtext = "Bewölkung: ";
		var gusttext = "Böen";
		var datatext = "Datenquelle";
		var nighttext = " nacht";
		var freeRAMtxt = "RAM Frei:  ";
		var usedRAMtxt = "RAM Belegt:  ";
		var totalRAMtxt = "RAM Nutzung:  ";
		var totalRAMPhystxt = "RAM Physisch:  ";
		var storagetxt = "MB";
		var batterytxt = "Batterie: ";
		var unpluggedtxt = "Getrennt";
		var chargingtxt = "Lädt";
		var fullchargetxt = "Voll Geladen";
		var nexthourtext = "Nächste Stunde: ";
		var christmastxt = "Frohe Weihnachten";
		var newyeartxt = "Frohes neues Jahr";
		var fromtext = "Von ";
		var WeatherDesc = [
			"Tornado",
			"Tropischer sturm",
			"Wirbelsturm",
			"Schwere gewitter",
			"Gewitter",
			"Regen und schnee",
			"Graupelschauer",
			"Schneeregen",
			"Gefrierender nieselregen",
			"Nieselregen",
			"Gefrierender regen",
			"Schauer",
			"Regen",
			"Schneegestuöber",
			"Leichte schneeschauer",
			"Schneetreiben",
			"Schnee",
			"Hagel",
			"Schneeregen",
			"Staubig",
			"Nebelig",
			"Dunstschleier",
			"Dunstig",
			"Stürmisch",
			"Windig",
			"Kalt",
			"Bewölkt ",
			"Meist bewölkt",
			"Meist bewölkt",
			"Teilweise bewölkt",
			"Teilweise bewölkt",
			"Klar",
			"Sonnig",
			"Heiter",
			"Meist sonnig",
			"Regen und hagel",
			"Heiss",
			"Örtliche gewitter",
			"Vereinzelte gewitte",
			"Vereinzelte gewitte",
			"Vereinzelte schauer",
			"Starker schneefall",
			"Vereinzelte schneeschauer",
			"Starker schneefall",
			"Teilweise bewölkt",
			"Gewitter",
			"Scheeschauer",
			"Örtliche gewitterschauer",
			"Nicht verfuegbar"];
	break;
	case "nl":
		var days = ["Zondag", "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag"];
		var months = ["Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December"];
		var hightext = "Hoog ";
		var lowtext = "Laag ";
		var sunrisetext ="Ochtend";
		var sunsettext = "Nacht";
		var moonrisetext ="Moonrise";
		var moonsettext = "Moonset";
		var feelsliketext = "Gevoelstemp. ";
		var lastupdatetext = "Gecontroleerd ";
		var xmlupdatetext = "Bijgewerkt ";
		var humiditytext = "Vochtigheid ";
		var visibilitytext = "Zichtbaarheid";	
		var pressuretext = "Druk ";
		var windtext = "Wind ";
		var UVIndextext = "UV-index ";
		var preciptext = "Neerslag ";
		var Dewpointtext = "Dauwpunt ";
        var forecasttext = "Forecast";
		var moontext = "Maan";
		var nowindtext = "Geen wind";
		var voltextimp = " in";
		var voltextmet = " mm";
		var disttextimp = "mile";
		var disttextmet = "km";
		var wsutextimp = "mpu";
		var wsutextmet = "km/u";
		var cloudtext = "Cloud Cover: ";
		var gusttext = "Windvlagen";
		var datatext = "Gegevensbron";
		var nighttext = " nacht";
		var freeRAMtxt = "Vrij RAM:  ";
		var usedRAMtxt = "Gebruikt RAM:  ";
		var totalRAMtxt = "Beschikbaar RAM:  ";
		var totalRAMPhystxt = "Totaal RAM:  ";
		var storagetxt = "MB";
		var batterytxt = "Batterij: ";
		var unpluggedtxt = "Besnoeiing";
		var chargingtxt = "Ladingen";
		var fullchargetxt = "Opgeladen";
		var nexthourtext = "Volgende Uur: ";
		var christmastxt = "Vrolijk Kerstfeest";
		var newyeartxt = "Gelukkig Nieuwjaar";
		var fromtext = "Van ";
		var WeatherDesc = [
			"Tornado",
			"Tropische storm",
			"Wervelwind",
			"Zware onweersbuien",
			"Onweersbuien",
			"Regen en sneeuw",
			"Regen en ijzel",
			"Sneeuw en ijzel",
			"Bevriezende motregen",
			"Motregen",
			"Ijzel",
			"Buien",
			"Regen",
			"Sneeuwvlagen",
			"Lichte sneeuwbuien",
			"Sneeuw drift",
			"Sneeuw",
			"Hagel",
			"Ijzel",
			"Stoffig",
			"Mistig",
			"Wazig",
			"Wazig",
			"Stormachtig",
			"Winderig",
			"Koud",
			"Bewolkt ",
			"Algemeen bewolkt",
			"Algemeen bewolkt",
			"Gedeeltelijk bewolkt",
			"Gedeeltelijk bewolkt",
			"Helder",
			"Zonnig",
			"Veelal helder",
			"Overwegend zonnig",
			"Regen en hagel",
			"Heet",
			"Geisoleerde onweersbuien",
			"Verspreide onweersbuien",
			"Verspreide onweersbuien",
			"Verspreide buien",
			"Zware sneeuw",
			"Verspreide sneeuwbuien",
			"Zware sneeuw",
			"Gedeeltelijk bewolkt",
			"Onweersbuien",
			"Sneeuwbuien",
			"Geisoleerde onweersbuien",
			"Niet beschikbaar"];
	break;
	case "fi":
		var days = ["Sunnuntai", "Maanantai", "Tiistai", "Keskiviikko", "Torstai", "Perjantai", "Lauantai"];
		var months = ["Tammikuu", "Helmikuu", "Maaliskuu", "Huhtikuu", "Toukokuu", "Kesäkuu", "Heinäkuu", "Elokuu", "Syyskuu", "Lokakuu", "Marraskuu", "Joulukuu"];
		var hightext = "Korkein ";
		var lowtext = "Alin ";
		var sunrisetext = "Aamu";
		var sunsettext = "Yö";
		var moonrisetext ="kuun nousu";
		var moonsettext = "Moon asetettu";
		var feelsliketext = "Tuntuu ";
		var pressuretext = "Paine ";	
		var lastupdatetext = "Tarkastetaan ";
		var xmlupdatetext = "päivitetty ";
		var visibilitytext = "Näkyvyys";
		var humiditytext = "Ilmankosteus ";
		var windtext = "Tuuli ";
		var UVIndextext = "UV-indeksi ";
		var preciptext = "Precip ";
		var Dewpointtext = "Kastepiste ";
        var forecasttext = "Ennuste";
		var moontext = "Kuu";
		var nowindtext = "Ei tuulta";
		var voltextimp = " in";
		var voltextmet = " mm";
		var disttextimp = "mile";
		var disttextmet = "km";
		var wsutextimp = "mph";
		var wsutextmet = "km/h";
		var cloudtext = "Cloud Cover: ";
		var gusttext = "Puuskat";
		var datatext = "Tietolähde";
		var nighttext = "-iltana";
		var freeRAMtxt = "Free RAM:  ";
		var usedRAMtxt = "Used RAM:  ";
		var totalRAMtxt = "Tot.Usab.RAM:  ";
		var totalRAMPhystxt = "Tot.Phys.RAM:  ";
		var storagetxt = "MB";
		var batterytxt = "Battery: ";
		var unpluggedtxt = "Unplugged";
		var chargingtxt = "Charging";
		var fullchargetxt = "Fully Charged";
		var nexthourtext = "Next Hour: ";
		var christmastxt = "Merry Christmas";
		var newyeartxt = "Happy New Year";
		var fromtext = "From ";
		var WeatherDesc = [
			"Tornaado",
			"Trooppinen myrsky",
			"Wervelwind",
			"Rankkoja ukkoskuuroja",
			"Ukkosmyrskyjä",
			"Vesisadetta ja räntää",
			"Vesi ja räntäsadetta",
			"Lumi ja räntäsadetta",
			"Jäätävää tihkusadetta",
			"Tihkusadetta",
			"Jäätävää sadetta",
			"Sadekuuroja",
			"Sade",
			"Lumisadetta",
			"Heikkoja lumikuuroja",
			"Lumituisku",
			"Lumisadetta",
			"Rakeita",
			"Räntää",
			"Pölyistä",
			"Sumuista",
			"Utuista",
			"Utuista",
			"Ei tietoja",
			"Tuulista",
			"kylmää",
			"Pilvistä",
			"Enimmäkseen pilvistä",
			"Enimmäkseen pilvistä",
			"Puolipilvistä",
			"Puolipilvistä",
			"Selkeää",
			"Aurinkoista",
			"Selkeää",
			"Selkeää",
			"Vesisadetta ja raekuuroja",
			"Hellettä",
			"Paikallisia ukkoskuuroja",
			"Hajanaisia ukkoskuuroja",
			"Hajanaisia ukkoskuuroja",
			"Hajanaisia sadekuuroja",
			"Rankkaa lumisadetta",
			"Hajanaisia lumikuuroja",
			"Rankkaa lumisadetta",
			"Puolipilvistä",
			"Ukkoskuuroja",
			"Lumikuuroja",
			"Paikallisia ukkoskuuroja",
			"Ei tietoja"];
    break; 
	case "es":
		var days = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
		var months = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
		var hightext = "Máx ";
		var lowtext = "Mín ";
		var sunrisetext ="Amanecer";
		var sunsettext = "Anochecer";
		var moonrisetext ="Salida/Luna";
		var moonsettext = "Puesta/Luna";
		var feelsliketext = "Más como ";
		var lastupdatetext = "Comprob. ";
		var xmlupdatetext = "Actualizado ";
		var humiditytext = "Humedad ";
		var visibilitytext = "Visibilidad";
		var pressuretext = "Presión ";
		var windtext = "Viento ";
		var UVIndextext = "Índice UV ";
		var preciptext = "Precip ";
		var Dewpointtext = "Punto de rocío ";
        var forecasttext = "Pronóstico";
		var moontext = "Luna";
		var nowindtext = "No hay viento";
		var voltextimp = " in";
		var voltextmet = " mm";
		var disttextimp = "mile";
		var disttextmet = "km";
		var wsutextimp = "milla/h";
		var wsutextmet = "kilo/h";
		var cloudtext = "Cloud Cover: ";
		var gusttext = "Ráfagas";
		var datatext = "Fuente de datos";
		var nighttext = " por la Noche";
		var freeRAMtxt = "RAM Libre:  ";
		var usedRAMtxt = "RAM Ocupado:  ";
		var totalRAMtxt = "RAM Dispon.:  ";
		var totalRAMPhystxt = "RAM Fisical:  ";
		var batterytxt = "Batería: ";
		var storagetxt = "MB";
		var unpluggedtxt = "Desenchufado";
		var chargingtxt = "Cargando";
		var fullchargetxt = "Cargado";
		var nexthourtext = "Próxima Hora: ";
		var christmastxt = "Feliz Navidad";
		var newyeartxt = "Prospero Año Nuevo";
		var fromtext = "De ";
		var WeatherDesc = [
			"Tornado",
			"Tormenta Tropical",
			"Huracan",
			"Tormentas electricas Severas",
			"Tormentas electricas",
			"Mezcla de lluvia y nieve",
			"Mezcla de lluvia y aguanieve",
			"Mezcla de nieve y aguaniev",
			"Llovizna helada",
			"Llovizna",
			"Lluvia bajo cero",
			"Chubascos",
			"Lluvia",
			"Rafagas de nieve",
			"Ligeras precipitaciones de nieve",
			"Viento y nieve",
			"Nieve",
			"Granizo",
			"Aguanieve",
			"Polvareda",
			"Neblina",
			"Bruma",
			"Humeado",
			"Tempestuoso",
			"Vientoso",
			"Frio",
			"Nublado ",
			"Mayormente nublado",
			"Mayormente nublado",
			"Parcialmente despejado",
			"Parcialmente despejado",
			"Despejado",
			"Soleado",
			"Mayormente despejado",
			"Mayormente soleado",
			"Mezcla de lluvia y granizo",
			"Caluroso",
			"Tormentas electricas aisladas",
			"Tormentas electricas dispersas",
			"Tormentas electricas dispersas",
			"Chubascos dispersos",
			"Nieve fuerte",
			"Precipitaciones de nieve dispersas",
			"Nieve fuerte",
			"Parcialmente despejado",
			"Lluvia con truenos y relampagos",
			"Precipitaciones de nieve",
			"Tormentas aisladas",
			"No disponible"];
    break;
	case "it":
		var days = ["Domenica", "Lunedi ", "Martedi", "Mercoledi", "Giovedi", "Venerdi", "Sabato"];
		var months = ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"];
		var hightext = "Max ";
		var lowtext = "Min ";
		var sunrisetext ="Alba";
		var sunsettext = "Tramonto";
		var moonrisetext ="Luna sorge";
		var moonsettext = "Luna cala";
		var feelsliketext = "Percepita ";
		var lastupdatetext = "Controllato alle ";
		var xmlupdatetext = "Aggiornato alle ";
		var humiditytext = "Umidita ";
		var visibilitytext = "Visibilita ";
		var pressuretext = "Pressione ";
		var windtext = "Vento ";
		var UVIndextext = "Indice UV ";
		var preciptext = "Precipitazioni ";
		var Dewpointtext = "Punto di rugiada ";
		var forecasttext = "Previsione";
		var moontext = "Luna";
		var nowindtext = "Senza Vento";
		var voltextimp = " in";
		var voltextmet = " mm";
		var disttextimp = "mile";
		var disttextmet = "km";
		var wsutextimp = "mph"; //miglia all'ora
		var wsutextmet = "km/h"; //chilometri all'ora
		var cloudtext = "Cloud Cover: ";
		var gusttext = "Raffiche";
		var datatext = "Sorgente dati";
		var nighttext = " notte";
		var freeRAMtxt = "RAM Libera:  ";
		var usedRAMtxt = "RAM Usata:  ";
		var totalRAMtxt = "RAM Disponible:  ";
		var totalRAMPhystxt = "RAM Fisica:  ";
		var storagetxt = "MB";
		var batterytxt = "Batteria: ";
		var unpluggedtxt = "Scollegato";
		var chargingtxt = "In Carica";
		var fullchargetxt = "Carica";
		var nexthourtext = "Prossima Ora: ";
		var christmastxt = "Buon Natale";
		var newyeartxt = "Felice Anno Nuovo";
		var fromtext = "Da ";
		var WeatherDesc = [
			"Tornado",
			"Tempesta tropicale",
			"Uragano",
			"Tuoni e fulmini",
			"Fulmini",
			"Pioggia e neve",
			"Pioggia e nevischio",
			"Neve e nevischio",
			"Grandine",
			"Pioviggine",
			"Pioggia gelata",
			"Pioggia a tratti",
			"Pioggia",
			"Raffiche di neve",
			"Neve a tratti",
			"Vento e neve",
			"Neve",
			"Grandine",
			"Nevischio",
			"Pulviscolo",
			"Nebbia",
			"Foschia",
			"Umido",
			"Tempesta",
			"Ventoso",
			"Freddo",
			"Nuvoloso",
			"Prevalentemente nuvoloso",
			"Prevalentemente nuvoloso",
			"Parzialmente nuvoloso",
			"Parzialmente nuvoloso",
			"Sereno",
			"Soleggiato",
			"Prevalentemente sereno",
			"Prevalentemente sereno",
			"Neve e grandine",
			"Caldo",
			"Fulmini isolati",
			"Temporale",
			"Temporale",
			"Acquazzoni sparsi",
			"Forti nevicate",
			"Neve sparsa",
			"Forti nevicate",
			"Parzialmente nuvoloso",
			"Rovesci e temporali",
			"Precipitazioni nevose",
			"Temporali isolati",
			"Non disponibile"];
	break;
	case "ru":
		var days = ["Воскресенье","Понедельник","Вторник","Среда","Четверг","Пятница","Суббота"];
		var months = ['Января','Февраля','Марта','Апреля','Мая','Июня','Июля','Августа','Сентября','Октября','Ноября','Декабря'];
		var hightext = "привет ";
		var lowtext = "вот ";
		var sunrisetext ="утро";
		var sunsettext = "закат";
		var moonrisetext ="Луна восход";
		var moonsettext = "Луна";
		var feelsliketext = "чувство ";
		var lastupdatetext = "проверено ";
		var xmlupdatetext = "обновленный ";
		var humiditytext = "Влажность ";
		var visibilitytext = "видимость";
		var pressuretext = "давление ";
		var windtext = "Bетер ";
		var UVIndextext = "УФ-индекс ";
		var preciptext = "Precip ";
		var Dewpointtext = "Точка росы ";
        var forecasttext = "Прогноз";
		var moontext = "Луна";
		var nowindtext = "Нет ветра";
		var voltextimp = " in";
		var voltextmet = " mm";
		var disttextimp = "mile";
		var disttextmet = "km";
		var wsutextimp = "<span style='font-size:92%'>миль/ч</span>";
		var wsutextmet = "<span style='font-size:92%'>км/ч</span>";
		var cloudtext = "Cloud Cover: ";
		var gusttext = "<span style='font-size:92%'>Порывы Bетра</span>";
		var datatext = "Источник данных"
		var nighttext = " вторника";
		var freeRAMtxt = "Free RAM:  ";
		var usedRAMtxt = "Used RAM:  ";
		var totalRAMtxt = "Tot.Usab.RAM:  ";
		var totalRAMPhystxt = "Tot.Phys.RAM:  ";
		var storagetxt = "MB";
		var batterytxt = "Battery: ";
		var unpluggedtxt = "Unplugged";
		var chargingtxt = "Charging";
		var fullchargetxt = "Fully Charged";
		var nexthourtext = "Next Hour: ";
		var christmastxt = "Merry Christmas";
		var newyeartxt = "Happy New Year";
		var fromtext = "From ";
		var WeatherDesc = [
			"Торнадо",
			"Горячая буря",
			"Ураган",
			"Гроза",
			"Бури",
			"Дождь со снегом",
			"Дождь и мокрый снег",
			"Снег и мокрый снег",
			"Изморозь",
			"Изморось",
			"Ледяной дождь",
			"Дождь",
			"Дождь",
			"Снег с порывами",
			"Небольшой снег с дождем",
			"Снежные заряды",
			"Снег",
			"Град",
			"Дождь со снегом",
			"Пыль",
			"Туман",
			"Туман",
			"Туман",
			"Бурный",
			"Ветер",
			"Холодный",
			"Облачно ",
			"Небольшая облачность",
			"Небольшая облачность",
			"Переменная облачность",
			"Переменная облачность",
			"Ясно",
			"Солнечно",
			"Переменная облачность",
			"Кратковременные дожди",
			"Дождь и град",
			"Горячий",
			"Изолированные грозы",
			"Рассеянные грозы",
			"Рассеянные грозы",
			"Рассеянный дождь",
			"Сильный снег",
			"Рассеянный снег с дождем",
			"Сильный снег",
			"Переменная облачность",
			"Изолированные грозы с дождем",
			"Дождь со снегом",
			"Изолированные грозы с дождем",
			"Недоступно"];
	break;
	case "zh":
		var days = ["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
		var months = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
		var hightext = "最高 ";
		var lowtext = "最低 ";
		var sunrisetext = "日出";
		var moonrisetext ="月亮升起";
		var moonsettext = "月球集";
		var sunsettext = "日落";
		var feelsliketext = "感覺像";
		var pressuretext = "最高";	
		var lastupdatetext = "檢查 ";
		var xmlupdatetext = "更新 ";
		var visibilitytext = "能见度";
		var humiditytext = "湿度 ";
		var windtext = "风向 ";
		var UVIndextext = "紫外線指數 ";
		var preciptext = "沉淀 ";
		var Dewpointtext = "露点 ";
        var forecasttext = "预测";
		var moontext = "月亮";
		var nowindtext = "无风";
		var voltextimp = " in";
		var voltextmet = " mm";
		var disttextimp = "mile";
		var disttextmet = "km";
		var wsutextimp = "mph";
		var wsutextmet = "km/h";
		var cloudtext = "Cloud Cover: ";
		var gusttext = "阵风";
		var datatext = "数据源";
		var nighttext = "晚上";
		var freeRAMtxt = "Free RAM:  ";
		var usedRAMtxt = "Used RAM:  ";
		var totalRAMtxt = "Tot.Usab.RAM:  ";
		var totalRAMPhystxt = "Tot.Phys.RAM:  ";
		var storagetxt = "MB";
		var batterytxt = "Battery: ";
		var unpluggedtxt = "Unplugged";
		var chargingtxt = "Charging";
		var fullchargetxt = "Fully Charged";
		var nexthourtext = "Next Hour: ";
		var christmastxt = "Merry Christmas";
		var newyeartxt = "Happy New Year";
		var fromtext = "From ";
		var WeatherDesc = ["风卷残云", "热带风暴", "狂风暴雨", "电闪雷鸣", "电闪雷鸣", "雨雪霏霏", "雨雪霏霏", "雨雪纷纷", "寒风冷雨", "蒙蒙细雨", "凄风冷雨", "疾风骤雨", "雨", "俄而雪骤", "流风回雪", "狂风暴雪", "大雪纷飞", "天降冰雹", "雨雪霏霏", "飞沙走石", "云迷雾锁", "十面霾伏", "烟雾弥漫", "风起云涌", "风和日丽", "天寒地冻", "乌云蔽日", "浮云蔽日", "浮云蔽日", "云淡风轻", "云淡风轻", "晴空万里", "阳光明媚", "大部晴朗", "晴时多云", "冰雹带雨", "骄阳似火", "霹雳列缺", "电闪雷鸣", "电闪雷鸣", "急风骤雨", "大雪纷飞", "骤雪初歇", "大雪纷飞", "云淡风轻", "雷阵雨", "雨雪霏霏", "霹雳列缺", "自行判断"];
	break;
	case "tr": 
		var days = ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma​​", "Cumartesi"]; 
		var months = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül","Ekim", "Kasım", "Aralık"]; 
		var hightext = "Yüksek "; 
		var lowtext = "Düşük "; 
		var sunrisetext = "Gündoğumu"; 
		var sunsettext = "Gün Batımı"; 
		var moonrisetext = "Ayın doğuşu"; 
		var moonsettext = "Ayın Batışı"; 
		var feelsliketext = "Hissedilen "; 
		var pressuretext = "Basınç "; 
		var lastupdatetext = "Güncellendi "; 
		var xmlupdatetext = "Güncelleme vakti "; 
		var visibilitytext = "Görüş mesafesi"; 
		var humiditytext = "Nem "; 
		var windtext = "Rüzgar "; 
		var UVIndextext = "UV Endeksi ";
		var preciptext = "Precip ";
		var Dewpointtext = "İşbâ ";
		var forecasttext = "Hava durumu"; 
		var nowindtext = "Rüzgar yok";
		var moontext = "Ay";
		var voltextimp = " in";
		var voltextmet = " mm";
		var disttextimp = "mile";
		var disttextmet = "km";
		var wsutextimp = "mil/saat";
		var wsutextmet = "km/saat";
		var cloudtext = "Cloud Cover: ";
		var gusttext = "Bora";
		var datatext = "Veri kaynağı";
		var nighttext = " gecesi";
		var freeRAMtxt = "Free RAM:  ";
		var usedRAMtxt = "Used RAM:  ";
		var totalRAMtxt = "Tot.Usab.RAM:  ";
		var totalRAMPhystxt = "Tot.Phys.RAM:  ";
		var storagetxt = "MB";
		var batterytxt = "Battery: ";
		var unpluggedtxt = "Unplugged";
		var chargingtxt = "Charging";
		var fullchargetxt = "Fully Charged";
		var nexthourtext = "Next Hour: ";
		var christmastxt = "Merry Christmas";
		var newyeartxt = "Happy New Year";
		var fromtext = "From ";
		var WeatherDesc = [
			"Kasırga", 
			"Tropik fırtına", 
			"Fırtına", 
			"Şiddetli fırtına", 
			"Gök gürültülü fırtına",
			"Karışık yağmur ve kar", 
			"Karışık yağmur ve sulusepken", 
			"Karışık kar ve sulusepken", 
			"Çisenti Donma", 
			"Çiseleyen yağmur", 
			"Dondurucu çiseleyen yağmur",
			"Sağanak", 
			"Yağmur", 
			"Hafif kar",
			"Hafif kar sağnağı", 
			"Esen kar", 
			"Kar", 
			"Dolu", 
			"Sulu kar", 
			"Toz", 
			"Sisli",
			"Sis", 
			"Dumanlı", 
			"Yaygaracı", 
			"Rüzgarlı", 
			"Soğuk", 
			"Bulutlu", 
			"Çoğunlukla bulutlu", 
			"Çoğunlukla bulutlu", 
			"Parçalı bulutlu", 
			"Parçalı bulutlu", 
			"Açık", 
			"Güneşli", 
			"Çoğunlukla açık", 
			"Hafif bulutlu", 
			"Karışık yağmur ve dolu", 
			"Sıcak", 
			"İzole gökgürültülü sağanak", 
			"Dağınık gökgürültülü sağanak",
			"Dağınık gökgürültülü sağanak",
			"Dağınık sağanak", 
			"Şiddetli kar", 
			"Dağınık sağanak kar", 
			"Şiddetli kar", 
			"Parçalı bulutlu", 
			"Gökgürültülü yağmur", 
			"Sağanak kar", 
			"Izole gökgürültülü yağmur", 
			"Müsait değil"];
	break;
	case "el":
		var days = ["Κυριακή", "Δευτέρα", "Τρίτη", "Τετάρτη", "Πέμπτη", "Παρασκευή", "Σάββατο"];
		var months = ["Ιανουάριος", "Φεβρουάριος", "Μάρτιος", "Απρίλιος", "Μάιος", "Ιούνιος", "Ιούλιος", "Αύγουστος", "Σεπτέμβριος", "Οκτώβριος", "Νοέμβριος", "Δεκέμβριος"];
		var hightext = "Υψηλή ";
		var lowtext = "Χαμηλή ";
		var sunrisetext = "Ανατολή";
		var sunsettext = "Δύση";
		var moonrisetext ="Ανατολή";
		var moonsettext = "Δύση";
		var feelsliketext = "Αίσθηση ";
		var lastupdatetext = "ελέγχεται ";
		var xmlupdatetext = "Ανανέωση ";
		var humiditytext = "Υγρασία "; 
		var visibilitytext = "Ορατότητα";      
		var pressuretext = "Πίεση ";
		var windtext = "Άνεμος ";
		var UVIndextext = "Επίπεδο UV ";
		var preciptext = "Precip ";
		var Dewpointtext = "σημ.δρόσου ";
		var forecasttext = "Πρόβλεψη";
		var moontext = "Φεγγάρι";
		var nowindtext = "Χωρίς αέρα";
		var voltextimp = " in";
		var voltextmet = " mm";
		var disttextimp = "mile";
		var disttextmet = "km";
		var wsutextimp = "μ.α.ώ";
		var wsutextmet = "χλμ";
		var cloudtext = "Cloud Cover: ";
		var gusttext = "Ριπές";
		var datatext = "Πηγή δεδομένων";
		var nighttext = " το βράδυ";
		var freeRAMtxt = "Free RAM:  ";
		var usedRAMtxt = "Used RAM:  ";
		var totalRAMtxt = "Tot.Usab.RAM:  ";
		var totalRAMPhystxt = "Tot.Phys.RAM:  ";
		var storagetxt = "MB";
		var batterytxt = "Μπαταρία: ";
		var unpluggedtxt = "Αποσυνδεδεμένο";
		var chargingtxt = "Φόρτισης";
		var fullchargetxt = "Φορτίστηκε";
		var nexthourtext = "Επόμενη ώρα: ";
		var christmastxt = "Καλά Χριστούγεννα";
		var newyeartxt = "Καλή Πρωτοχρονιά";
		var fromtext = "Από το ";
		var WeatherDesc = [
			"Ανεμοστρόβιλος",
			"Τροπική Καταιγίδα",
			"Τυφώνας",
			"Ισχυρές Καταιγίδες",
			"Καταιγίδες",
			"Βροχή και Χιόνι",
			"Βροχή και Χιονόνερο",
			"Χιόνι και Χιονόνερο",
			"Παγωμένο Ψιλόβροχο",
			"Ψιλόβροχο",
			"Παγωμένη Βροχή",
			"Καταιγίδες",
			"βροχή",
			"Διαστήματα Χιονιού",
			"Ελαφρές Χιονοπτώσεις",
			"Χιονοθύελλα",
			"Χιονόπτωση",
			"Χαλαζόπτωση",
			"Χιονόνερο",
			"Σκόνη",
			"Ομιχλώδης",
			"Καταχνιά",
			"Ομιχλώδης",
			"Θυελλώδης",
			"Ανεμώδης",
			"Κρύος",
			"Νεφελώδης ",
			"Κυρίως Νεφελώδης",
			"Κυρίως Νεφελώδης",
			"Μερικώς Νεφελώδης",
			"Μερικώς Νεφελώδης",
			"Αίθριος",
			"Ηλιόλουστος",
			"Κυρίως αίθριος",
			"Κυρίως λιακάδα",
			"Βροχή και Χαλάζι",
			"Ζεστός Καιρός",
			"Μεμονωμένες Καταιγίδες",
			"Ασθενείς Καταιγίδες",
			"Ασθενείς Καταιγίδες",
			"Πιθανές Βροχές",
			"Ισχυρή Χιονόπτωση",
			"Πιθανή Χιονόπτωση",
			"Ισχυρή Χιονόπτωση",
			"Μερικώς Νεφελώδης",
			"Καταιγίδες",
			"Χιονόπτωση",
			"Μεμονωμένες Καταιγίδες",
			"Μη Διαθέσιμος"];
	break;	
	case "hr": 
        var days = ["Nedjelja", "Ponedjeljak", "Utorak", "Srijeda", "Cetvrtak", "Petak", "Subota"];
        var months = ["Siječanj", "Veljača", "Ožujak", "Travanj", "Svibanj", "Lipanj", "Srpanj", "Kolovoz", "Rujan", "Listopad", "Studeni", "Prosinac"];
        var hightext = "V: ";
	 	var lowtext = "N: ";
		var storagetxt = "MB";
		var batterytxt = "Baterija: ";
        var sunrisetext ="Svitanje";
        var sunsettext = "Sumrak";
	 	var moonrisetext ="Mjesec iz.";
        var moonsettext = "Mjesec zal.";
        var feelsliketext = "Čini se kao ";
        var lastupdatetext = "Ažurirano: ";
        var humiditytext = "Vlažnost ";
        var visibilitytext = "Vidljivost ";
        var pressuretext = "Tlak ";
        var windtext = "Vjetar ";
		var UVIndextext = "UV index ";
		var Dewpointtext = "Točka rošenja ";
		var forecasttext = "Prognoza ";
		var nowindtext = "Tišina";
		var moontext = "Mjesec";
		var preciptext = "Mog.Oborine";
		var cloudtext = "Količina Oblaka: ";
		var voltextimp = " in";
		var voltextmet = " mm";
		var disttextimp = "mile";
		var disttextmet = "km";
		var wsutextimp = "mph";
		var wsutextmet = "km/h";
		var freeRAMtxt = "Slob. RAM:  ";
		var usedRAMtxt = "Kor. RAM:  ";
		var totalRAMtxt = "Tot.Slob.RAM:  ";
		var totalRAMPhystxt = "Tot.Fiz.RAM:  ";
		var unpluggedtxt = "Iskopčan";
		var chargingtxt = "Puni se";
		var fullchargetxt = "Napunjen";
		var nexthourtext = "Slijedeći sat: ";
		var christmastxt = "Sretan Božić";
		var newyeartxt = "Sretna Nova Godina";
		var fromtext = " ";
		var WeatherDesc = ["Tornado", "Tropska Oluja", "Uragan", "Teške oluje s grmljavinom", "Grmljavinska Oluja", "Kiša i Snijeg", "Kiša i Susnježica", "Snijeg i Susnježica", "Smrznuta Rominjanje", "Rominjanje", "Smrznuta Kiša", "Kiša", "Kiša", "Snježni naleti", "Lagani Naleti Snijega", "Snježna mećava", "Snijeg", "Tuća", "Susnježica", "Prašina", "Magla", "Sumaglica", "Dimljivo", "Jak Vjetar", "Vjetrovito", "Hladno", "Oblačno", "Većinom oblačno", "Većinom oblačno", "Djelomična naoblaka", "Djelomična naoblaka", "Vedro", "Sunčano", "Vedro", "Vedro", "Mješovita kiša i grad", "Vruće", "Izolirana Grmljavinska Oluja", "Slaba oluja s grmljavinom", "Slaba oluja s grmljavinom", "Mjestimični pljuskovi", "Jaki Snijeg", "Slaba kiša snijega", "Jaki Snijeg", "Djelomična naoblaka", "Grmljavinska Oluja", "Kiša Snijega", "Izolirana Grmljavinska Oluja", "Nije Dostupno"];
    break;
	case "vi":
		var days = ["chủ nhật", "thứ hai", "thứ ba", "thứ tư", "thứ năm", "thứ sáu", "thứ bảy"];
		var months = ["tháng một", "tháng hai", "tháng ba", "tháng tư", "tháng năm", "tháng sáu", "tháng bảy", "tháng tám", "tháng chín", "tháng mười", "tháng mười một", "tháng mười hai"];
		var hightext = "Cao ";
		var lowtext = "Thấp ";
		var sunrisetext ="bình Minh";
		var sunsettext = "Hoàng hôn";
		var moonrisetext ="mặt trăng mọc";
		var moonsettext = "mặt trăng lặn";
		var feelsliketext = "Cảm giác như ";
		var lastupdatetext = "Đã kiểm tra ";
		var xmlupdatetext = "Cập nhật tại ";
		var humiditytext = "Độ ẩm ";
		var visibilitytext = "Hiển thị";
		var pressuretext = "S.ép ";
		var windtext = "Gió ";
		var UVIndextext = "Chỉ số UV ";
		var moontext = "Mặt trăng";
		var preciptext = "Mưa ";
		var Dewpointtext = "Điểm sương ";
		var forecasttext = "Dự báo";
		var nowindtext = "Không có gió";
		var voltextimp = " in";
		var voltextmet = " mm";
		var disttextimp = "mile";
		var disttextmet = "km";
		var wsutextimp = "mph";
		var wsutextmet = "km/h";
		var cloudtext = "Cloud Cover: ";
		var gusttext = "Gusts";
		var datatext = "Nguồn dữ liệu";
		var nighttext = " đêm";
		var freeRAMtxt = "RAM còn lại:  ";
		var usedRAMtxt = "Used RAM:  ";
		var totalRAMtxt = "Tot.Usab.RAM:  ";
		var totalRAMPhystxt = "Tot.Phys.RAM:  ";
		var storagetxt = "MB";
		var batterytxt = "pin: ";
		var unpluggedtxt = "Không sạc";
		var chargingtxt = "Đang sạc";
		var fullchargetxt = "Pin đầy";
		var nexthourtext = "Giờ tiếp theo: ";
		var christmastxt = "Giáng sinh vui vẻ";
		var newyeartxt = "Chúc mừng năm mới";
		var fromtext = "Từ ";
		var christmastxt = "Giáng sinh vui vẻ";
		var newyeartxt = "Chúc mừng năm mới";
		var fromtext = "Từ ";
		var WeatherDesc = ["Có bão", "Bão nhiệt đới", "Có bão", "Có dông", "Có dông", "Có tuyết", "Mưa đá", "Mưa đá", "Mưa phùn lạnh", "Mưa phùn", "Mưa lạnh", "Mưa rào", "Có mưa", "Có bão", "Mưa tuyết", "Có tuyết", "Có tuyết", "Mưa đá", "Mưa tuyết", "Gió bụi", "Sương mù dày", "Sương mù", "Sương nhẹ", "Gió mạnh", "Có gió", "Trời lạnh", "Có mây vài nơi", "Trời nhiều mây", "Trời nhiều mây", "Có mây vài nơi", "Có mây vài nơi", "Quang mây", "Có nắng", "Trời quang mây", "Trời nắng", "Mưa đá", "Trời nóng", "Có sấm sét", "Có sấm sét", "Có sấm sét", "Có mưa", "Có tuyết", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Ít mây", "Có dông", "Có tuyết", "Có dông", "blank"];
	break;
	case "id":
		var days = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
		var months = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember "];
		var hightext = "Tinggi ";
		var lowtext = "Dalam ";
		var sunrisetext = "Pagi ";
		var sunsettext = "Malam ";
		var moonrisetext = "Bulan terbit ";
		var moonsettext = "Bulan terbenam ";
		var feelsliketext = "Merasa ";
		var lastupdatetext = "Pem.terkahir ";
		var xmlupdatetext = "Diperbarui ";
		var visibilitytext = "Visibilitas ";
		var humiditytext = "Kelembaban ";
		var pressuretext = "Tekanan udara ";
		var windtext = "Angin ";
		var UVIndextext = "UV-index";
		var moontext = "Bulan";
		var preciptext = "Presip ";
		var Dewpointtext = "Titik Embun ";
		var forecasttext = "Ramalan cuaca ";
		var nowindtext = "Tidak ada angin";
		var voltextimp = " in";
		var voltextmet = " mm";
		var disttextimp = "mile";
		var disttextmet = "km";
		var wsutextimp = "m/jam";
		var wsutextmet = "km/jam";
		var cloudtext = "Cloud Cover: ";
		var gusttext = "Hembusan";
		var datatext = "Data";
		var nighttext = "Malam ";
		var freeRAMtxt = "RAM Bebas: ";
		var usedRAMtxt = "RAM Digunakan: ";
		var totalRAMtxt = "RAM Total: ";
		var totalRAMPhystxt = "RAM Fisik: ";
		var storagetxt = "MB";
		var batterytxt = "Baterai:";
		var unpluggedtxt = "Terputus";
		var chargingtxt = "Mengisi";
		var fullchargetxt = "Terisi Penuh";
		var nexthourtext = "Jam berikutnya: ";
		var christmastxt = "Selamat Natal";
		var newyeartxt = "Selamat Tahun Baru";
		var fromtext = "Dari ";
		var WeatherDesc = [ "Angin topan", "Badai tropis", "Topan", "Badai petir", "Hujan badai", "Hujan dan salju", "Mandi hujan es", "Salju dan hujan es", "Gerimis beku", "Gerimis", "Hujan beku", "Mandi", "Hujan", "Hujan salju", "Hujan salju ringan", "Hembusan salju", "Salju", "Hujan es", "Hujan es", "Berdebu", "Berkabut", "Kabut", "Berasap", "Kencang", "Berangin", "Dingin", "Berawan", "Cerah berawan", "Cerah berawan", "Berawan", "Sebagian cerah", "Bersih", "Cerah", "Terang", "Umumnya cerah", "Hujan dan hujan es", "Panas", "Badai petir lokal", "Petir tersebar", "Petir tersebar", "Pancuran tersebar", "Hujan salju lebat", "Hujan salju sesekali", "Hujan salju lebat", "Berawan", "Hujan badai", "Hujan salju", "Badai petir lokal", "Tidak tersedia"];
	break;
	case "he": 
		var days = ["יום ראשון","יום שני","יום שלישי","יום רביעי","יום חמישִי","יום שישי","יום שבת"];		
		var daysabbrev = ["יום א","יום ב","יום ג","יום ד"," יום ה","יום ו","שבת"];
		var months = ["ינואר", "פברואר", "מרץ", "אפּריל", "מאי", "יוני", "יולי", "אוגוסט", "ספּטמבר", "אוקטובר", "נובמבר", "דצמבר"];
		var hightext = "גבוה ";
		var lowtext = "נמוך ";
		var sunrisetext ="זריחה ";
		var sunsettext = "שקיעה ";
		var moonrisetext ="זריחה ";
		var moonsettext = "שקיעה ";
		var feelsliketext = "מרגיש כמו "; 
		var lastupdatetext = "עודכן ב ";
		var xmlupdatetext = "עודכן ב ";
		var humiditytext = "לחות ";
		var visibilitytext = "ראוּת: ";
		var pressuretext = "לחץ: ";
		var windtext = "רוח ";
		var UVIndextext = "מדד קרינה: ";
		var preciptext = "מִשקעים: ";
		var Dewpointtext = "נקודת הטל ";
		var forecasttext = "תחזית";
		var moontext = "ירח:";
		var nowindtext = "אין רוח";
		var voltextimp = " אינץ";
		var voltextmet = " מ״מ";
		var disttextimp = "מיילס";
		var disttextmet = "קילומטרים";
		var wsutextmet = "קמ״ש ";
		var wsutextimp = "מי״ש ";
		var cloudtext = "עננות: ";
		var gusttext = "משבי רוח";
		var datatext = "מקור מידע";
		var nighttext = " לילה";
		var freeRAMtxt = "זיכרון פנוי: ";
		var usedRAMtxt = "זיכרון בשימוש: ";
		var totalRAMtxt = "זיכרון כללי: ";
		var totalRAMPhystxt = "זיכרון פיזי כולל: ";
		var storagetxt = "מ״ב"
		var batterytxt = "סוללה: ";
		var unpluggedtxt = "לא בטעינה";
		var chargingtxt = "בטעינה";
		var fullchargetxt = "טעינה מלאה";
		var nexthourtext = "בשעה הבאה: ";
		var christmastxt = "קריסמס שמח";
		var newyeartxt = "שנה אזרחית שמחה";
		var fromtext = "מאת ";
		var WeatherDesc = [
"טורנדו",
"סערה טרופית",
"הוריקן",
"סופות רעמים קשות",
"סופות רעמים",
"גשם מעורב בשלג",
"גשם מעורב בקרח",
"שלג מעורב בקרח",
"רסס קופא",
"רסס",
"גשם קופא",
"ממטרים",
"גשם",
"פתיתי שלג",
"ממטרי שלג קלים",
"משבי שלג",
"שלג",
"ברד",
"גשם קרחי",
"אבק",
"ערפילי",
"אובך",
"עשני",
"סוער",
"משבי רוח",
"קר",
"מעונן",
 "מעונן ברובו",
"מעונן ברובו",
"מעונן חלקית",
"מעט שמשי",
"בהיר",
"שמשי",
"בהיר ברובו",
"שמשי לרוב",
"גשם מעורב בברד",
"חם",
"סופות רעמים מקומיות",
"סופות רעמים פזורות",
"סופות רעמים פזורות",
"ממטרים פזורים",
"שלג כבד",
"ממטרי שלג פזורים",
"שלג כבד",
"מעונן חלקית",
"רעמים",
"ממטרי שלג",
"רעמים מקומיים",
"לא נמצא"];
	break;
		case "ar": 
		var days = ["الاحد", "الاثنين", "الثلاثاء ٰ", "الأربعاء ", "الخميس ", "الجمعة ", "السبت "];	
		var daysabbrev = ["الاحد", "الاثنين", "الثلاثاء ٰ", "الأربعاء ", "الخميس ", "الجمعة ", "السبت "]; //Arabic speakers prefer full name
		//var daysabbrev = ["الاح", "الاث", "الت", "الار", "الخم", "الج", "السب"];
		var months = ["كانون ٢", "شباط", "ٱذار", "نيسان", "ٱيار", "حزيران", "تموز", "ٱب", "ٱيلول", "تشرين ١", "تشرين ٢", "كانون ١"];
		var hightext = "عال ";
		var lowtext = "أدنى ";
		var sunrisetext ="الشروق";
		var sunsettext = "الغروب";
		var moonrisetext ="طلوع القمر";
		var moonsettext = "غروب القمر";
		var feelsliketext = "تحس مثل ";
		var lastupdatetext = "فحص ";
		var xmlupdatetext = "تحديث ";
		var humiditytext = "الرطوبة ";
		var visibilitytext = "الرؤية: ";
		var pressuretext = "الظغط: ";
		var windtext = "الرياح ";
		var UVIndextext = "مؤشرUV: ";
		var preciptext = "هطول: ";
		var Dewpointtext = "نقطة ندى ";
		var forecasttext = "توقعات";
		var moontext = "قمر: ";
		var nowindtext = "لا رياح";
		var voltextimp = " بوصة";
		var voltextmet = " ملم";
		var disttextimp = "ميل";
		var disttextmet = "كلمتر";
		var wsutextimp = "ميل/ساعة";
		var wsutextmet = "كلم/ساعة";
		var cloudtext = "غيوم: ";
		var gusttext = "هبات ريح";
		var datatext = "بيانات";
		var nighttext = " الليل";
		var freeRAMtxt = "ذاكرة فارغة:  ";
		var usedRAMtxt = "ذاكرة مستخدمة:  ";
		var totalRAMtxt = "ذاكرة متاحة:  ";
		var totalRAMPhystxt = "مجموع الذاكرة:  ";
		var storagetxt = "ميغابايت";
		var batterytxt = "بطارية: ";
		var unpluggedtxt = "مفصول";
		var chargingtxt = "شحن";
		var fullchargetxt = "مشحون";
		var nexthourtext = "الساعة القادمة: ";
		var christmastxt = "كريسماس";
		var newyeartxt = "سنة سعيدة";
		var fromtext = "من ";
		var WeatherDesc = [
"ٱعصار",
"عاصفة استوائية",
"إعصار مداري",
"عاصفة رعدية شديدة",
"عاصفة رعدية",
"مطر وثلج",
"مطر وثلج",
"مطر وصقيع",
"رذاذ متجمد",
"رذاذ متجمد",
"مطر متجمد",
"مطر كثيف",
"مطر",
"ثلج خفيف",
"ثلج كثيف",
"ثلج غزير",
"ثلج",
"وابل برد",
"جليد",
"غبار",
"ضبابي",
"ضباب كثيف",
"دخان",
"هائج",
"عاصف",
"برد",
"غائم",
 "غائم بكثافة",
"غائم بكثافة",
"غائم جزئي",
"مشمس جزئي",
"صاف",
"مشمس",
"صاف غالبا",
"مشمس غالبا",
"مطر وبرد",
"حار",
"عواصف منعزلة",
"عواصف متفرقة",
"عواصف متفرقة",
"زخات متفرقة",
"ثلج كثيف",
"زخات ثلجية متفرقة",
"ثلج كثيف",
"غائم",
"زخات رعدية",
"زخات ثلجية",
"زخات رعدية متفرقة",
"غير متوف"];
	break;
	default: 
		var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
		var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
		var hightext = "Hi ";
		var lowtext = "Lo ";
		var sunrisetext ="Sunrise";
		var sunsettext = "Sunset";
		var moonrisetext ="Moonrise";
		var moonsettext = "Moonset";
		var feelsliketext = "Feels like ";
		var lastupdatetext = "Checked at ";
		var xmlupdatetext = "Updated at ";
		if (useDewWithHumidity == true) { var humiditytext = "Hum "; } else { var humiditytext = "Humidity "; }
		var visibilitytext = "Visibility";
		var pressuretext = "Pressure ";
		var windtext = "Wind ";
		var UVIndextext = "UV index ";
		var preciptext = "24hrPrecip";
		if (useDewWithHumidity == true) { var Dewpointtext = "Dew "; } else { var Dewpointtext = "Dewpoint "; }
        var forecasttext = "Forecast";
		var moontext = "Moon";
		var nowindtext = "No wind";
		var voltextimp = " in";
		var voltextmet = " mm";
		var disttextimp = "mi";
		var disttextmet = "km";
		var wsutextimp = "mph";
		var wsutextmet = "km/h";
		var cloudtext = "Cloud Cover: ";
		var gusttext = "Gusts";
		var datatext = "Data Source";
		var nighttext = " night";
		var freeRAMtxt = "Free RAM:  ";
		var usedRAMtxt = "Used RAM:  ";
		var totalRAMtxt = "Tot.Usab.RAM:  ";
		var totalRAMPhystxt = "Tot.Phys.RAM:  ";
		var storagetxt = "MB";
		var batterytxt = "Battery: ";
		var unpluggedtxt = "Unplugged";
		var chargingtxt = "Charging";
		var fullchargetxt = "Fully Charged";
		var nexthourtext = "Next Hour: ";
		var christmastxt = "Merry Christmas";
		var newyeartxt = "Happy New Year";
		var fromtext = "From ";
		var WeatherDesc = [
			"Tornado",
			"Tropical storm",
			"Hurricane",
			"Severe thunderstorms",
			"Thunderstorms",
			"Mixed rain and snow",
			"Mixed rain and sleet",
			"Mixed snow and sleet",
			"Freezing drizzle",
			"Drizzle",
			"Freezing rain",
			"Showers",
			"Rain",
			"Snow flurries",
			"Light snow showers",
			"Blowing snow",
			"Snow",
			"Hail",
			"Sleet",
			"Dust",
			"Foggy",
			"Haze",
			"Smoky",
			"Blustery",
			"Windy",
			"Cold",
			"Cloudy",
			"Mostly cloudy",
			"Mostly cloudy",
			"Partly cloudy",
			"Partly sunny",
			"Clear",
			"Sunny",
			"Mostly clear",
			"Mostly sunny",
			"Mixed rain and hail",
			"Hot",
			"Isolated thunderstorms",
			"Scattered thunderstorms",
			"Scattered thunderstorms",
			"Scattered showers",
			"Heavy snow",
			"Scattered snow showers",
			"Heavy snow",
			"Partly cloudy",
			"Thundershowers",
			"Snow showers",
			"Isolated thundershowers",
			"Not available"];
	break;
}

function ForecastDayNames(day) {
switch (day) {
    case "Sun": { return days[0]; }
    case "Mon": { return days[1]; }
    case "Tue": { return days[2]; }
    case "Wed": { return days[3]; }
    case "Thu": { return days[4]; }
    case "Fri": { return days[5]; }
    case "Sat": { return days[6]; }
	}
}

function WindDescription() {
	switch (lang) {
		case "no": 			
			if (windspeed >= 118) { var winddesc = "orkan"; }
			if (windspeed < 118) { var winddesc = "voldelig vind"; }
			if (windspeed < 103){ var winddesc = "sterk vind"; }
			if (windspeed < 89){ var winddesc = "sterk kuling"; }				
			if (windspeed < 75){ var winddesc = "sterk kuling"; }
			if (windspeed < 62) { var winddesc = "stiv kuling"; }
			if (windspeed < 50) { var winddesc = "liten kuling"; }
			if (windspeed < 39) { var winddesc = "frisk bris"; }
			if (windspeed < 29) { var winddesc = "moderat bris"; }	
			if (windspeed < 20) { var winddesc = "laber bris"; }
			if (windspeed < 12) { var winddesc = "lett bris"; }
			if (windspeed < 6) { var winddesc = "svak vind"; }
			if (windspeed < 3) { var winddesc = "flau vind"; }
			if (windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "zh": 			
			if (windspeed >= 118) { var winddesc = "飓风级风力"; }
			if (windspeed < 118) { var winddesc = "猛烈的风"; }
			if (windspeed < 103){ var winddesc = "强风"; }
			if (windspeed < 89){ var winddesc = "八级大风"; }				
			if (windspeed < 75){ var winddesc = "大风"; }
			if (windspeed < 62) { var winddesc = "高风"; }
			if (windspeed < 50) { var winddesc = "强风"; }
			if (windspeed < 39) { var winddesc = "清新的微风"; }
			if (windspeed < 29) { var winddesc = "和风"; }	
			if (windspeed < 20) { var winddesc = "微风"; }
			if (windspeed < 12) { var winddesc = "微风"; }
			if (windspeed < 6) { var winddesc = "光气"; }
			if (windspeed < 3) { var winddesc = "小风"; }
			if (windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "fr":
			if (windspeed >= 118) { var winddesc = "ouragan"; }
			if (windspeed < 118) { var winddesc = "vent violent"; }
			if (windspeed < 103){ var winddesc = "vent soufflant en tempête"; }
			if (windspeed < 89){ var winddesc = "fort coup de vent"; }	
			if (windspeed < 75){ var winddesc = "coup de vent"; }
			if (windspeed < 62) { var winddesc = "vent fort"; }
			if (windspeed < 50) { var winddesc = "forte brise"; }
			if (windspeed < 39) { var winddesc = "bonne brise"; }
			if (windspeed < 29) { var winddesc = "brise modérée"; }	
			if (windspeed < 20) { var winddesc = "douce brise"; }
			if (windspeed < 12) { var winddesc = "légère brise"; }
			if (windspeed < 6) { var winddesc = "un peu d'air"; }
			if (windspeed < 3) { var winddesc = "faible vent"; }
			if (windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "ru":
			if (windspeed >= 118) { var winddesc = "ураган"; }
			if (windspeed < 118) { var winddesc = "сильный ветер"; }
			if (windspeed < 103){ var winddesc = "штурмовой ветер"; }
			if (windspeed < 89){ var winddesc = "сильный порыв ветра"; }	  
			if (windspeed < 75){ var winddesc = "шторм"; }
			if (windspeed < 62) { var winddesc = "сильный ветер"; }
			if (windspeed < 50) { var winddesc = "сильный ветер"; }
			if (windspeed < 39) { var winddesc = "хороший ветер"; }
			if (windspeed < 29) { var winddesc = "умеренный ветер"; }	
			if (windspeed < 20) { var winddesc = "слабый ветер"; }
			if (windspeed < 12) { var winddesc = "спокойный ветер"; }
			if (windspeed < 6) { var winddesc = "легкий ветер"; }
			if (windspeed < 3) { var winddesc = "слабый ветер"; }
			if (windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "fi": 			
			if (windspeed >= 118) { var winddesc = "hirmumyrskyn tuulen"; }
			if (windspeed < 118) { var winddesc = "raju tuulenpuuska"; }
			if (windspeed < 103){ var winddesc = "voimakas tuuli"; }
			if (windspeed < 89){ var winddesc = "voimakas myrsky"; }	
			if (windspeed < 75){ var winddesc = "tuore Gale"; }
			if (windspeed < 62) { var winddesc = "kova tuuli"; }
			if (windspeed < 50) { var winddesc = "voimakas tuuli"; }
			if (windspeed < 39) { var winddesc = "raikkaan"; }
			if (windspeed < 29) { var winddesc = "kova tuuli"; }	
			if (windspeed < 20) { var winddesc = "lempeä tuuli"; }
			if (windspeed < 12) { var winddesc = "Heikkoa tuulta"; }
			if (windspeed < 6) { var winddesc = "vaisto"; }
			if (windspeed < 3) { var winddesc = "vähän tuulta"; }
			if (windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "nl": 			
			if (windspeed >= 118) { var winddesc = "orkaankracht wind"; }
			if (windspeed < 118) { var winddesc = "hevige wind"; }
			if (windspeed < 103){ var winddesc = "sterke wind"; }
			if (windspeed < 89){ var winddesc = "sterke storm"; }				
			if (windspeed < 75){ var winddesc = "verse gale"; }
			if (windspeed < 62) { var winddesc = "harde wind"; }
			if (windspeed < 50) { var winddesc = "sterke wind"; }
			if (windspeed < 39) { var winddesc = "frisse wind"; }
			if (windspeed < 29) { var winddesc = "matige wind"; }	
			if (windspeed < 20) { var winddesc = "zwakke wind"; }
			if (windspeed < 12) { var winddesc = "lichte bries"; }
			if (windspeed < 6) { var winddesc = "zwak"; }
			if (windspeed < 3) { var winddesc = "een beetje wind"; }
			if (windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "de":
			if (windspeed >= 118) { var winddesc = "orkanartigen wind"; }
			if (windspeed < 118) { var winddesc = "heftiger wind"; }
			if (windspeed < 103){ var winddesc = "starker wind"; }
			if (windspeed < 89){ var winddesc = "starken sturm"; }				
			if (windspeed < 75){ var winddesc = "frischen sturm"; }
			if (windspeed < 62) { var winddesc = "hohen wind"; }
			if (windspeed < 50) { var winddesc = "starke brise"; }
			if (windspeed < 39) { var winddesc = "frische brise"; }
			if (windspeed < 29) { var winddesc = "sanfte brise"; }	
			if (windspeed < 20) { var winddesc = "leichte brise"; }
			if (windspeed < 12) { var winddesc = "leichte brise"; }
			if (windspeed < 6) { var winddesc = "licht luft"; }
			if (windspeed < 3) { var winddesc = "wenig wind"; }
			if (windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "es":
			if (windspeed >= 118) { var winddesc = "viento huracanado"; }
			if (windspeed < 118) { var winddesc = "viento violento"; }
			if (windspeed < 103){ var winddesc = "viento fuerte"; }
			if (windspeed < 89){ var winddesc = "ventarron fuerte"; }	
			if (windspeed < 75){ var winddesc = "ventarron fresco"; }
			if (windspeed < 62) { var winddesc = "viento fuerte"; }
			if (windspeed < 50) { var winddesc = "brisa fuerte"; }
			if (windspeed < 39) { var winddesc = "brisa fresca"; }
			if (windspeed < 29) { var winddesc = "brisa moderada"; }	
			if (windspeed < 20) { var winddesc = "brisa normal"; }
			if (windspeed < 12) { var winddesc = "brisa"; }
			if (windspeed < 6) { var winddesc = "viento suave"; }
			if (windspeed < 3) { var winddesc = "viento"; }
			if (windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "it":
			if (windspeed >= 118) { var winddesc = "uragano violento"; }
			if (windspeed < 118) { var winddesc = "uragano"; }
			if (windspeed < 103){ var winddesc = "burrasca"; }
			if (windspeed < 89){ var winddesc = "burrascoso"; }
			if (windspeed < 75){ var winddesc = "vento fortissimo"; }
			if (windspeed < 62) { var winddesc = "vento forte"; }
			if (windspeed < 50) { var winddesc = "vento teso"; }
			if (windspeed < 39) { var winddesc = "vento intenso"; }
			if (windspeed < 29) { var winddesc = "vento moderato"; }
			if (windspeed < 20) { var winddesc = "brezza moderata"; }
			if (windspeed < 12) { var winddesc = "brezza leggera"; }
			if (windspeed < 6) { var winddesc = "dolce brezza"; }
			if (windspeed < 3) { var winddesc = "alito di vento"; }
			if (windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;			
		case "tr": 
			if (windspeed >= 118) { var winddesc = "kasırga"; }
			if (windspeed <118) { var winddesc = "şiddetli rüzgar"; } 
			if (windspeed <103) { var winddesc = "kuvvetli rüzgar"; } 
			if (windspeed <89) { var winddesc = "güçlü fırtına"; } 
			if (windspeed <75) { var winddesc = "güçlü meltem"; } 
			if (windspeed <62) { var winddesc = "yüksek rüzgar"; } 
			if (windspeed <50) { var winddesc = "güçlü esinti"; } 
			if (windspeed <39) { var winddesc = "taze esinti"; } 
			if (windspeed <29) { var winddesc = "ılımlı esinti"; } 
			if (windspeed <20) { var winddesc = "nazik esinti"; } 
			if (windspeed <12) { var winddesc = "hafif esinti"; } 
			if (windspeed <6) { var winddesc = "hafif rüzgar"; } 
			if (windspeed <3) { var winddesc = "az rüzgar"; } 
			if (windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "el":
			if (windspeed >= 118) { var winddesc = "Τύφωνας"; }
			if (windspeed < 118) { var winddesc = "Ισχυροί Άνεμοι"; }
			if (windspeed < 103){ var winddesc = "Ενισχυμένοι Άνεμοι"; }
			if (windspeed < 89){ var winddesc = "Ισχυροι Θυελλώδης Άνεμοι"; }
			if (windspeed < 75){ var winddesc = "Θυελλώδης Άνεμος"; }
			if (windspeed < 62) { var winddesc = "Ισχυρός Άνεμος"; }
			if (windspeed < 50) { var winddesc = "Δυνατός Αέρας"; }
			if (windspeed < 39) { var winddesc = "Πολύς Αέρας"; }
			if (windspeed < 29) { var winddesc = "Αρκετός Αέρας"; }	
			if (windspeed < 20) { var winddesc = "Μετριος Αέρας"; }
			if (windspeed < 12) { var winddesc = "Ήπιος Αέρας"; }
			if (windspeed < 6) { var winddesc = "Ελαφρύς Αέρας"; }
			if (windspeed < 3) { var winddesc = "Λίγος Αέρας"; }
			if (windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "hr": 			
			if (windspeed >= 118) { var winddesc = "orkan."; }
			if (windspeed < 118) { var winddesc = "jak orkanski vjetar."; }
			if (windspeed < 103){ var winddesc = "orkanski vjetar ."; }
			if (windspeed < 89){ var winddesc = "jak olujni vjetar."; }				
			if (windspeed < 75){ var winddesc = "olujni vjetar."; }
			if (windspeed < 62) { var winddesc = "Žestok vjetar."; }
			if (windspeed < 50) { var winddesc = "jak vjetar."; }
			if (windspeed < 39) { var winddesc = "umjereno jak vjetar."; }
			if (windspeed < 29) { var winddesc = "umjeren vjetar."; }	
			if (windspeed < 20) { var winddesc = "slab vjetar."; }
			if (windspeed < 12) { var winddesc = "povjetarac."; }
			if (windspeed < 6) { var winddesc = "lagani povjetarac."; }
			if (windspeed < 3) { var winddesc = "lahor."; }
			if (windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "vi":
			if (windspeed >= 118) {var winddesc = "gió giống như bão"; }
            if (windspeed < 118) {var winddesc = "gió dữ dội"; }
            if (windspeed < 103) {var winddesc = "gió mạnh"; }
            if (windspeed < 89) {var winddesc = "mạnh bão"; }
            if (windspeed < 75) {var winddesc = "mới có bão"; }
            if (windspeed < 62) {var winddesc = "high wind"; }
            if (windspeed < 50) {var winddesc = "gió mạnh"; }
            if (windspeed < 39) {var winddesc = "gió tươi"; }
            if (windspeed < 29) {var winddesc = "gió nhẹ"; }
            if (windspeed < 20) {var winddesc = "gió nhẹ"; }
            if (windspeed < 12) {var winddesc = "gió nhẹ"; }
            if (windspeed < 6) {var winddesc = "không khí nhẹ"; }
            if (windspeed < 3) {var winddesc = "gió nhỏ"; }
            if (windspeed == 0) {var winddesc = ""; }
            return winddesc;
		break;
		case "id":
            if (windspeed >= 118) {var winddesc = "angin seperti badai"; }
            if (windspeed < 118) {var winddesc = "angin kencang"; }
            if (windspeed < 103) {var winddesc = "angin kencang"; }
            if (windspeed < 89) {var winddesc = "badai kuat"; }
            if (windspeed < 75) {var winddesc = "badai segar"; }
            if (windspeed < 62) {var winddesc = "high wind"; }
            if (windspeed < 50) {var winddesc = "angin kencang"; }
            if (windspeed < 39) {var winddesc = "angin segar"; }
            if (windspeed < 29) {var winddesc = "angin sepoi-sepoi"; }
            if (windspeed < 20) {var winddesc = "angin sepoi-sepoi"; }
            if (windspeed < 12) {var winddesc = "angin sepoi-sepoi"; }
            if (windspeed < 6) {var winddesc = "light air"; }
            if (windspeed < 3) {var winddesc = "little wind"; }
            if (windspeed == 0) {var winddesc = ""; }
            return winddesc;
		break;
		case "he":             
		    if (windspeed >= 118) { var winddesc = "רוחות הוריקן."; }
		    if (windspeed < 118) { var winddesc = "רוחות סופה."; }
		    if (windspeed < 103){ var winddesc = "רוח עזה."; }
		    if (windspeed < 89){ var winddesc = "סערה חזקה."; }                
		    if (windspeed < 75){ var winddesc = "סערה."; }
		    if (windspeed < 62) { var winddesc = "רוח חזקה."; }
		    if (windspeed < 50) { var winddesc = "בריזה חזקה."; }
		    if (windspeed < 39) { var winddesc = "בריזה ערה."; }
		    if (windspeed < 29) { var winddesc = "בריזה מתונה."; }    
		    if (windspeed < 20) { var winddesc = "בריזה קלה."; }
		    if (windspeed < 12) { var winddesc = "רוח קלה."; }
		    if (windspeed < 6) { var winddesc = "משב אוויר קל."; }
		    if (windspeed < 3) { var winddesc = "רוח קלילה."; }
		    if (windspeed == 0) { var winddesc = ""; }
		    return winddesc;
		break;
		case "ar":             
		    if (windspeed >= 118) { var winddesc = "إعصار قوي الرياح."; }
		    if (windspeed < 118) { var winddesc = "رياح عنيفة."; }
		    if (windspeed < 103) { var winddesc = "رياح قوية."; }
		    if (windspeed < 89) { var winddesc = "عاصفة قوية."; }                
		    if (windspeed < 75) { var winddesc = "عاصفة جديدة."; }
		    if (windspeed < 62) { var winddesc = "رياح عالية."; }
		    if (windspeed < 50) { var winddesc = "نسيم قوي."; }
		    if (windspeed < 39) { var winddesc = "نسيم رطب."; }
		    if (windspeed < 29) { var winddesc = "نسيم متوسط."; }   
		    if (windspeed < 20) { var winddesc = "نسيم خفيف."; }
		    if (windspeed < 12) { var winddesc = "نسيم خفيف جدا."; }
		    if (windspeed < 6) { var winddesc = "هواء خفيف."; }
		    if (windspeed < 3) { var winddesc = "رياح خفيفة."; }
		    if (windspeed == 0) { var winddesc = ""; }
		    return winddesc;
		break;
		default: 			
			if (windspeed >= 118) { var winddesc = "hurricane-force wind."; }
			if (windspeed < 118) { var winddesc = "violent wind."; }
			if (windspeed < 103){ var winddesc = "strong wind."; }
			if (windspeed < 89){ var winddesc = "strong gale."; }				
			if (windspeed < 75){ var winddesc = "fresh gale."; }
			if (windspeed < 62) { var winddesc = "high wind."; }
			if (windspeed < 50) { var winddesc = "strong breeze."; }
			if (windspeed < 39) { var winddesc = "fresh breeze."; }
			if (windspeed < 29) { var winddesc = "moderate breeze."; }	
			if (windspeed < 20) { var winddesc = "gentle breeze."; }
			if (windspeed < 12) { var winddesc = "light breeze."; }
			if (windspeed < 6) { var winddesc = "light air."; }
			if (windspeed < 3) { var winddesc = "little wind."; }
			if (windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
	}
}

function translateCardinal() {
	switch (lang) {
		case "no":
			switch (cardinal) { 					
				case 'N': { return "N"; } //NORD
				case 'NNW': { return "NNV"; }		
				case 'NW': { return "NV"; } //NORDVEST	
				case 'WNW': { return "VNV"; }
				case 'W': { return "V"; } //VEST	
				case 'WSW': { return "VSV"; }		
				case 'SW': { return "SV"; } //SØRVEST
				case 'SSW': { return "SSV";	}	
				case 'S': { return "S"; } //SØR	
				case 'SSE': { return "SSØ"; }
				case 'SE': { return "SØ"; } //SØRØST		
				case 'ESE': { return "ØSØ"; }		
				case 'E': { return "Ø"; } //ØST	
				case 'ENE': { return "ØNØ"; }		
				case 'NE': { return "NØ"; } //NORDØST
				case 'NNE': { return "NNØ"; }		
				break;
			}
		break;
		
		case "de": 					
			switch (cardinal) { 					
				case 'N': { return "N"; } //NORDEN
				case 'NNW': { return "NNW"; }		
				case 'NW': { return "NW"; } //NORDENWEST	
				case 'WNW': { return "WNW"; }
				case 'W': { return "W"; } //WEST	
				case 'WSW': { return "WSW"; }		
				case 'SW': { return "SW"; } //SÜDWEST
				case 'SSW': { return "SSW";	}	
				case 'S': { return "S"; } //SÜD	
				case 'SSE': { return "SSO"; }
				case 'SE': { return "SO"; } //SÜDOSTEN		
				case 'ESE': { return "OSO"; }		
				case 'E': { return "O"; } //OSTEN	
				case 'ENE': { return "ONO"; }		
				case 'NE': { return "NO"; } //NORDENOSTEN
				case 'NNE': { return "NNO"; }		
				break;
			}
		break;
				
		case "it":
			switch (cardinal) { 					
				case 'N': { return "N"; } //NORD
				case 'NNW': { return "NNO"; }		
				case 'NW': { return "NO"; } //NORDOVEST	
				case 'WNW': { return "ONO"; }
				case 'W': { return "O"; } //OVEST	
				case 'WSW': { return "OSO"; }		
				case 'SW': { return "SO"; } //SUDOVEST
				case 'SSW': { return "SSO";	}	
				case 'S': { return "S"; } //SUD	
				case 'SSE': { return "SSE"; }
				case 'SE': { return "SE"; } //SUDEST		
				case 'ESE': { return "ESE"; }		
				case 'E': { return "E"; } //EST	
				case 'ENE': { return "ENE"; }		
				case 'NE': { return "NE"; } //NORDEST
				case 'NNE': { return "NNE"; }		
				break;
			}
		break;
		
		case "fi":
			switch (cardinal) { 					
				case 'N': { return "Pohjoinen"; } //POHJOINEN
				case 'NNW': { return "Pohjoinen"; }		
				case 'NW': { return "Koillinen"; } //KOILLINEN
				case 'WNW': { return "Itä"; }
				case 'W': { return "Itä"; } //ITÄ	
				case 'WSW': { return "Itä"; } 	
				case 'SW': { return "Kaakko"; } //KAAKKO
				case 'SSW': { return "Etelä"; }	
				case 'S': { return "Etelä"; } //ETELÄ	
				case 'SSE': { return "Etelä"; }
				case 'SE': { return "Lounas"; } //LOUNAS		
				case 'ESE': { return "Länsi"; }		
				case 'E': { return "Länsi"; } //LÄNSI	
				case 'ENE': { return "Länsi"; }		
				case 'NE': { return "Luode"; } //LUODE
				case 'NNE': { return "Pohjoinen"; }			
				break;
			}
		break;
		
		case "nl":	
			switch (cardinal) { 					
				case 'N': { return "N"; } //NOORDEN
				case 'NNW': { return "NNW"; }		
				case 'NW': { return "NW"; } //NOORDENWEST	
				case 'WNW': { return "WNW"; }
				case 'W': { return "W"; } //WEST	
				case 'WSW': { return "WZW"; }		
				case 'SW': { return "ZW"; } //ZUIDENWEST
				case 'SSW': { return "ZZW";	}	
				case 'S': { return "Z"; } //ZUIDEN	
				case 'SSE': { return "ZZO"; }
				case 'SE': { return "ZO"; } //ZUIDENOOSTEN		
				case 'ESE': { return "OZO"; }		
				case 'E': { return "O"; } //OOSTEN	
				case 'ENE': { return "ONO"; }		
				case 'NE': { return "NO"; } //NOORDENOOSTEN
				case 'NNE': { return "NNO"; }		
				break;
			}	
		break;
		
		case "fr":
			switch (cardinal) { 					
				case 'N': { return "N"; } //NORD
				case 'NNW': { return "NNO"; }		
				case 'NW': { return "NO"; } //NORDOUEST	
				case 'WNW': { return "ONO"; }
				case 'W': { return "O"; } //OUEST	
				case 'WSW': { return "OSO"; }		
				case 'SW': { return "SO"; } //SUDOUEST
				case 'SSW': { return "SSO";	}	
				case 'S': { return "S"; } //SUD	
				case 'SSE': { return "SSE"; }
				case 'SE': { return "SE"; } //SUDEST		
				case 'ESE': { return "ESE"; }		
				case 'E': { return "E"; } //EST	
				case 'ENE': { return "ENE"; }		
				case 'NE': { return "NE"; } //NORDEST
				case 'NNE': { return "NNE"; }		
				break;
			}
		break;
		
		case "es":	
			switch (cardinal) { 					
				case 'N': { return "N"; } //NORTE
				case 'NNW': { return "NNO"; }		
				case 'NW': { return "NO"; } //NORTEOESTE
				case 'WNW': { return "ONO"; }
				case 'W': { return "O"; } //OESTE	
				case 'WSW': { return "OSO"; }		
				case 'SW': { return "SO"; } //SUROESTE
				case 'SSW': { return "SSO";	}	
				case 'S': { return "S"; } //SUR	
				case 'SSE': { return "SSE"; }
				case 'SE': { return "SE"; } //SURESTE		
				case 'ESE': { return "ESE"; }		
				case 'E': { return "E"; } //ESTE	
				case 'ENE': { return "ENE"; }		
				case 'NE': { return "NE"; } //NORTESTE
				case 'NNE': { return "NNE"; }		
				break;
			}
		break;
		
		case "ru": 
		    switch (cardinal) {					
				case 'N': { return "С"; }
				case 'NNW': { return "ССЗ"; }		
				case 'NW': { return "СЗ"; }		
				case 'WNW': { return "ЗСЗ"; }
				case 'W': { return "З"; }		
				case 'WSW': { return "ЗЮЗ"; }		
				case 'SW': { return "ЗЮ"; }
				case 'SSW': { return "ЗЗЮ"; }		
				case 'S': { return "Ю"; }		
				case 'SSE': { return "ЮЮВ"; }
				case 'SE': { return "ЮВ"; }		
				case 'ESE': { return "ВЮВ"; }		
				case 'E': { return "В"; }		
				case 'ENE': { return "ВСВ"; }		
				case 'NE': { return "СВ"; }
				case 'NNE': { return "ССВ"; }		
				break;
			}
		break;
		
		case "el": 					
			switch (cardinal) {					
				case 'N': { return "Β"; }
				case 'NNW': { return "ΒΒΔ"; }		
				case 'NW': { return "ΒΔ"; }		
				case 'WNW': { return "ΔΒΔ"; }
				case 'W': { return "Δ"; }		
				case 'WSW': { return "ΔΝΔ"; }		
				case 'SW': { return "ΝΔ"; }
				case 'SSW': { return "ΝΝΔ"; }		
				case 'S': { return "Ν"; }		
				case 'SSE': { return "ΝΝΑ"; }
				case 'SE': { return "ΝΑ"; }		
				case 'ESE': { return "ΑΝΑ"; }		
				case 'E': { return "Α"; }		
				case 'ENE': { return "ΑΒΑ"; }		
				case 'NE': { return "ΒΑ"; }
				case 'NNE': { return "ΒΒΑ"; }		
				break;
			}
		break;
		case "tr":
			switch (cardinal) { 					
				case 'N': { return "K"; } //NORTH
				case 'NNW': { return "KKB"; }		
				case 'NW': { return "KB"; } //NORTHWEST	
				case 'WNW': { return "BKB"; }
				case 'W': { return "B"; } //WEST	
				case 'WSW': { return "BGB"; }		
				case 'SW': { return "GB"; } //SOUTHWEST
				case 'SSW': { return "GGB";	}	
				case 'S': { return "G"; } //SOUTH	
				case 'SSE': { return "GGD"; }
				case 'SE': { return "GD"; } //SOUTHEAST		
				case 'ESE': { return "DGD"; }		
				case 'E': { return "D"; } //EAST	
				case 'ENE': { return "DKD"; }		
				case 'NE': { return "KD"; } //NORTHEAST
				case 'NNE': { return "KKD"; }		
				break;
			}
		break;
		
		case "zh":
			switch (cardinal) { 					
				case 'N': { return "北"; }
				case 'NNW': { return "北"; }		
				case 'NW': { return "西北"; }	
				case 'WNW': { return "西"; }
				case 'W': { return "西"; }	
				case 'WSW': { return "西"; }		
				case 'SW': { return "西南"; }
				case 'SSW': { return "南";	}	
				case 'S': { return "南"; }	
				case 'SSE': { return "南"; }
				case 'SE': { return "东南"; }		
				case 'ESE': { return "东"; }		
				case 'E': { return "东"; }	
				case 'ENE': { return "东"; }		
				case 'NE': { return "东北"; }
				case 'NNE': { return "北"; }		
				break;
			}
		break;
		case "hr":
			switch (cardinal) { 					
				case 'N': { return "S"; } //SJEVER
				case 'NNW': { return "SSZ"; }		
				case 'NW': { return "SZ"; } //SJEVERZAPAD	
				case 'WNW': { return "ZSZ"; }
				case 'W': { return "Z"; } //ZAPAD	
				case 'WSW': { return "ZJZ"; }		
				case 'SW': { return "JZ"; } //JUGOZAPAD
				case 'SSW': { return "JJZ";	}	
				case 'S': { return "J"; } //JUG	
				case 'SSE': { return "JJI"; }
				case 'SE': { return "JI"; } //JUGOISTOK		
				case 'ESE': { return "IJI"; }		
				case 'E': { return "I"; } //ISTOK	
				case 'ENE': { return "ISI"; }		
				case 'NE': { return "SI"; } //SJEVEROISTOK
				case 'NNE': { return "SSI"; }		
				break;
			}
		break;
		case "he":
			switch (cardinal) {                     
				case 'N': { return "צ"; } //NORTH
				case 'NNW': { return "צ-צ-מז"; }        
				case 'NW': { return "צ-מז"; } //NORTHWEST    
				case 'WNW': { return "מע-צ-מע"; }
				case 'W': { return "מע"; } //WEST    
				case 'WSW': { return "מע-ד-מע"; }        
				case 'SW': { return "ד-מע"; } //SOUTHWEST
				case 'SSW': { return "ד-ד-מע";    }    
				case 'S': { return "ד"; } //SOUTH    
				case 'SSE': { return "ד-ד-מז"; }
				case 'SE': { return "ד-מז"; } //SOUTHEAST        
				case 'ESE': { return "מז-ד-מז"; }        
				case 'E': { return "מז"; } //EAST    
				case 'ENE': { return "מז-צ-מז"; }        
				case 'NE': { return "צ-מז"; } //NORTHEAST
				case 'NNE': { return "צ-צ-מז"; }        
				break;
    		}
		break;
		case "ar":
			switch (cardinal) {
				case 'N': { return "ش"; } //شمال
				case 'NNW': { return "ششغ"; }
				case 'NW': { return "شغ"; } //شمال غربي
				case 'WNW': { return "غشغ"; }
				case 'W': { return "غ"; } //غرب
				case 'WSW': { return "غجغ"; }
				case 'SW': { return "جغ"; } //جنوب غربي 
				case 'SSW': { return "ججغ";}
				case 'S': { return "ج" ;} //جنوب
				case 'SSE': { return "ججش"; }
				case 'SE': { return "جش"; } //جنوب شرقي
				case 'ESE': { return "شجش"; }
				case 'E': { return "ش"; } //شرق
				case 'NNE': { return "ششش"; }
				break;
    		}
		break;
		default:
			switch (cardinal) { 					
				case 'N': { return "N"; } //NORTH
				case 'NNW': { return "NNW"; }		
				case 'NW': { return "NW"; } //NORTHWEST	
				case 'WNW': { return "WNW"; }
				case 'W': { return "W"; } //WEST	
				case 'WSW': { return "WSW"; }		
				case 'SW': { return "SW"; } //SOUTHWEST
				case 'SSW': { return "SSW";	}	
				case 'S': { return "S"; } //SOUTH	
				case 'SSE': { return "SSE"; }
				case 'SE': { return "SE"; } //SOUTHEAST		
				case 'ESE': { return "ESE"; }		
				case 'E': { return "E"; } //EAST	
				case 'ENE': { return "ENE"; }		
				case 'NE': { return "NE"; } //NORTHEAST
				case 'NNE': { return "NNE"; }		
				break;
			}
		break;
		
	}
}

//MOONPHASE ABBREVIATIONS
function abbrev(moonphase) {
	//ENGLISH
	if (lang == 'en' || lang == 'am') {
		switch (moonphase) {
			case 'New Moon': { return 'New Moon'; }
			case 'Waxing Crescent': { return 'Wax.Cres.'; }
			case 'First Quarter': { return '1st Qtr.'; }
			case 'Waxing Gibbous': { return 'Wax.Gibb.'; }
			case 'Full Moon': { return 'Full'; }
			case 'Waning Gibbous': { return 'Wan.Gibb.'; }
			case 'Last Quarter': { return 'Last Qtr.'; }
			case 'Waning Crescent': { return 'Wan.Cres.'; }
		}
	}
	//GERMAN
	if (lang == 'de') {
		switch (moonphase) {
			case 'Neumond': { return 'Neumond'; } //new moon**
			case 'zunehmender Sichelmond': { return 'zun.Sichelmond'; } //increasing crescent**
			case 'erstes Viertel': { return 'erstes Viertel'; } //first quarter**
			case 'zunehmender Halbmond': { return 'zun.Halbmond'; } //increasing half moon**
			case 'Vollmond': { return 'Vollmond'; } //full moon**
			case 'abnehmender Halbmond': { return 'abn.Halbmond'; } //decreasing half moon**
			case 'Last Quarter': /* for testing with emulation.js */
			case 'letztes Viertel': { return 'letztes Viertel'; } //third quarter**
			case 'abnehmender Sichelmond': { return 'abn.Sichelmond'; } //decreasing crescent**
		}
	}
	//FRENCH
	if (lang == 'fr') {
		switch (moonphase) {
			case 'Nouvelle lune': { return 'Nouv. lune'; } //new moon**
	        case 'Premier croissant': { return '1er croiss.'; } //first crescent**
	        case 'Premier quartier': { return '1er quart.'; } //first quarter**
	        case 'Lune gibbeuse (bossue) croissante': { return 'Gib. croiss.'; } //swelling gibbous**
	        case 'Pleine lune': { return 'Pleine'; } //full moon**
	        case 'Lune gibbeuse décroissante': { return 'Gib. décrois.'; } //decreasing gibbous**
			case 'Last Quarter': /* for testing with emulation.js */
	        case 'Dernier quartier': { return 'Der. quart.'; } //last quarter**
	        case 'Dernier croissant': { return 'Der. croiss.'; } //last crescent**
		}
	}
	//SPANISH
	if (lang == 'es') {
		switch (moonphase) {
			case 'Nueva': { return 'Nueva'; } //new moon**
			case 'Nueva visible': { return 'Nueva vis.'; } //newly visible**
			case 'Cuarto creciente': { return 'Cuarto crec.'; } //growing quarter**
			case 'Gibosa creciente': { return 'Gibosa crec.'; } //growing gibbous**
			case 'Llena': { return 'Llena'; } //full moon**
			case 'Gibosa menguante': { return 'Gibosa meng.'; } //waning gibbous**
			case 'Last Quarter': /* for testing with emulation.js */
			case 'Menguante': { return 'Menguante'; } //last quarter**
			case 'Cuarto menguante': { return 'Cuarto meng.'; } //waning**
		}
	}
	//PORTUGUESE
	if (lang == 'pt') {
		switch (moonphase) {
			//case 'Nueva': { return 'Nueva'; } //new moon**
			//case 'Nueva visible': { return 'Nueva vis.'; } //newly visible
			//case 'Cuarto creciente': { return 'Cuarto crec.'; } //growing quarter
			//case 'Gibosa creciente': { return 'Gibosa crec.'; } //growing gibbous
			case 'Lua cheia': { return 'Cheia'; } //full moon**
			case 'Lua minguante gibosa': { return 'Gibosa ming.'; } //waning gibbous**
			//case 'Last Quarter': /* for testing with emulation.js */
			//case 'Menguante': { return 'Menguante'; } //last quarter
			case 'Lua minguante': { return 'Lua minguante'; } //waning
		}
	}
	//ITALIAN
	if (lang == 'it') {
		switch (moonphase) {
			case 'Novilunio': { return 'Nuova'; } //new moon**
			case 'Luna crescente': { return 'Crescente'; } //crescent**
			case 'Primo quarto': { return 'Primo quarto'; } //first quarter**
			case 'Gibbosa crescente': { return 'Gibbosa cresc.'; } //growing gibbous**
			case 'Plenilunio': { return 'Piena'; } //full moon**
			case 'Gibbosa calante': { return 'Gibbosa cal.'; } //waning gibbous**
			case 'Last Quarter': /* for testing with emulation.js */
			case 'Ultimo quarto': { return 'Ult. quarto'; } //last quarter**
			case 'Luna calante': { return 'Calante'; } //waxing crescent
		}
	}
	//GREEK
	if (lang == 'el') {
		switch (moonphase) {
			case 'Νέα Σελήνη': { return 'Νέα'; } //new moon**
			case 'Αύξουσα Ημισέληνος': { return 'Αύξουσα Ημι.'; } //waxing crescent**
			case 'Πρώτο τέταρτο': { return 'Πρώτο τέταρτο'; } //first quarter**
			case 'Αύξουσα Αµφίκυρτος': { return 'Αύξουσα Αµφ.'; } //waxing gibbous**
			case 'Πανσέληνος': { return 'Πανσέληνος'; } //full moon**
			case 'Αύξουσα Κύρτωση': { return 'Αύξουσα Κύρ.'; } //waning gibbous**
			case 'Last Quarter': /* for testing with emulation.js */
			case 'Τελευταίο Τέταρτο': { return 'Τελευταίο Τέταρτο'; } //last quarter**
			case 'Φθίνουσα Ημισέληνος': { return 'Φθίνουσα Ημι.'; } //waning crescent**
		}
	}
	//CROATIAN
	if (lang == 'hr') {
		switch (moonphase) {
			case 'Mlađak (mladi Mjesec)': { return 'Mlađak'; } //new moon**
			case 'Mjesečev srp (večernji)': { return 'Več. Srp'; } //crescent moon(evening)**
			case 'Prva četvrt': { return 'Prva Čet.'; } //first quarter**
			case 'izbočen Mjesec (večernji)': { return 'Več. Izb.'; } //waxing gibbous**
			case 'Uštap (puni Mjesec)': { return 'Uštap'; } //full moon**
			case 'izbočen Mjesec (jutarnji)': { return 'Jut. Izb.'; } //waning gibbous**
			case 'Last Quarter': /* for testing with emulation.js */
			case 'Zadnja četvrt': { return 'Zad. Čet.'; } //last quarter**
			case 'Mjesečev srp (jutarnji)': { return 'Jut. Srp'; } //crescent moon(morning)**
		}
	}
	//DUTCH
	if (lang == 'nl') {
		switch (moonphase) {
			case 'Nieuwe maan': { return 'Nieuwe maan'; } //new moon**
			case 'Jonge maansikkel': { return 'Jonge maans.'; } //waxing crescent**
			case 'Eerste kwartier': { return 'Eerste kwar.'; } //first quarter**
			case 'Wassende maan': { return 'Wassende'; } //waxing gibbous**
			case 'Volle maan': { return 'Volle'; } //full moon**
			case 'Afnemende maan': { return 'Afnemende'; }//waning gibbous**
			case 'Last Quarter': /* for testing with emulation.js */
			case 'Laatste kwartier': { return 'Laatste ktr.'; } //last quarter**
			case 'Asgrauwe maan': { return 'Asgrauwe'; } //waning crescent**
		}
	}
	//NORWEGIAN
	if (lang == 'no') {
		switch (moonphase) {
			case 'Nymåne': { return 'Nymåne'; } //new moon**
			case 'Nymåne': { return 'Nymåne'; } //new moon here too** for waxing cr
			case 'Halvmåne': { return 'Halvmåne'; } //half moon**
			case 'Trekvartmåne': { return 'Trekvart.'; } //three quarters**
			case 'Fullmåne': { return 'Fullmåne'; } //full moon**
			case 'Trekvartmåne': { return 'Trekvart.'; } //three quarters** (same as waxing gibb)
			case 'Last Quarter': /* for testing with emulation.js */
			case 'Ne': { return 'Ne'; } //last quarter**
			case 'Halvmåne': { return 'Halvmåne'; } //waning crescent (half moon??)**
		}
	}
	//FINNISH
	if (lang == 'fi') {
		switch (moonphase) {
			case 'uusi kuu': { return 'uusi kuu'; } //new moon**
			case 'kasvava kuun sirppi': { return 'kasvava kuun sirppi'; } //waxing crescent**
			case 'ensimmäinen neljännes': { return '1. neljännes'; } //first quarter
			case 'kasvava kuu': { return 'kasvava'; } //waxing gibbous**
			case 'täysi kuu': { return 'täysi kuu'; } //full moon**
			case 'vähenevä kuu': { return 'vähenevä'; } //waning gibbous**
			case 'Last Quarter': /* for testing with emulation.js */
			case 'viimeinen neljännes': { return 'vii. neljännes'; } //last quarter**
			case 'vähenevä kuun sirppi': { return 'vähenevä kuun sirppi'; } //waning crescent**
		}
	}
	//CHINESE
	if (lang == 'zh') {
		switch (moonphase) {
			case '新月': { return '新月'; } //new moon**
			case '娥眉月': { return '娥眉月'; } //waxing crescent**
			case '上弦月': { return '上弦月'; } //first quarter**
			case '盈凸月': { return '盈凸月'; } //waxing gibbous**
			case '满月': { return '满月'; } //full moon**
			case '亏凸月': { return '亏凸月'; } //waning gibbous**
			case 'Last Quarter': /* for testing with emulation.js */
			case '下弦月': { return '下弦月'; } //last quarter***
			case '残月': { return '残月'; } //waning crescent**
		}
	}
	//TURKISH
	if (lang == 'tr') {
		switch (moonphase) {
			case 'Yeni Ay': { return 'Yeni Ay'; } //new moon**
			case 'Yeni Hilal': { return 'Yeni Hilal'; } //waxing crescent**
			case 'İlk Dördün': { return 'İlk Dördün'; }//First quarter**
			case 'Yeni Şişkin Ay': { return 'Yeni Şişkin'; } //waxing gibbous**
			case 'Dolunay': { return 'Dolunay'; } //full moon**
			case 'Eski Şişkin Ay': { return 'Eski Şişkin'; } //waning gibbous**
			case 'Last Quarter': /* for testing with emulation.js */
			case 'Son Dördün': { return 'Son Dördün'; } //last quarter**
			case 'Eski Hilal': { return 'Eski Hilal'; } //waning crescent**
		}
	}
	//RUSSIAN
	if (lang == 'ru') {
		switch (moonphase) {
			case 'Новолуние': { return 'Новолуние'; } //new moon**
			case 'Растущий серп': { return 'Растущий серп'; } //waxing crescent**
			case 'Первая четверть': { return 'Первая четверть'; }//first quarter**
			case 'Растущая луна': { return 'Растущая'; } //waxing gibbous**
			case 'Полнолуние': { return 'Полнолуние'; } //full moon**
			case 'Убывающая луна': { return 'Убывающая'; } //waning gibbous**
			case 'Last Quarter': /* for testing with emulation.js */
			case 'Последняя четверть': { return 'Последняя четверть'; }//last quarter**
			case 'Убывающий серп': { return 'Убывающий серп'; } //waning crescent**
		}
	}
	//VIETNAMESE
	if (lang == 'vi') {
		switch (moonphase) {
			case 'Trăng mới': { return 'Trăng mới'; } //new moon**
			case 'Trăng non': { return 'Trăng non'; } //waxing crescent**
			case 'Trăng thượng huyền': { return 'Trăng thượng huyền'; } //first quarter**
			case 'Trăng khuyết đầu tháng': { return 'Trăng khuyết đầu tháng'; } //waxing gibbous**
			case 'Trăng rằm': { return 'Trăng rằm'; } //full moon**
			case 'Trăng khuyết cuối tháng': { return 'Trăng khuyết cuối'; } //waning gibbous**
			case 'Last Quarter': /* for testing with emulation.js */
			case 'Trăng tàn': { return 'Trăng tàn'; } // last quarter**
			case 'Trăng hạ huyền': { return 'Trăng hạ huyền'; } //waning crescent**
		}
	}
	//INDONESIAN
	if (lang == 'id') {
		switch (moonphase) {
			case 'Baru': { return 'Baru'; } //new moon**
			case 'Sabit Awal': { return 'Sabit Awal'; } //waxing crescent**
			case 'Triwulan Pertama': { return 'Triwulan Pertama'; }//first quarter**
			case 'Benjol Awal': { return 'Benjol Awal'; } //waxing gibbous**
			case 'Purnama': { return 'Purnama'; } //full moon**
			case 'Benjol Akhir': { return 'Ben. Akhir'; } //waning gibbous**
			//case 'Last Quarter': /* for testing with emulation.js */
			//case 'Last Quarter': { return 'Last Qtr.'; } //last quarter**
			case 'Sabit Akhir': { return 'Sabit Akhir'; } //waning crescent**
		}
	}
	//HEBREW
	if (lang == 'he') {
		switch (moonphase) {
			case 'מולד הלבנה': { return 'מולד הלבנה'; } //new moon**
			case 'חרמש מתמלא': { return 'חרמש מתמלא'; } //waxing crescent**
			case 'רבע ראשון': { return 'רבע ראשון'; }//first quarter**
			case 'חרמש מתמלא': { return 'חרמש מתמלא'; } //waxing gibbous**
			case 'ירח מלא': { return 'ירח מלא'; } //full moon**
			case 'חרמש נחסר': { return 'חרמש נחסר'; } //waning gibbous**
			case 'Last Quarter': /* for testing with emulation.js */
			case 'רבע אחרון': { return 'רבע אחרון'; } //last quarter**
			case 'חרמש נחסר': { return 'חרמש נחסר'; }//waning crescent**
		}
	}
	//ARABIC
	if (lang == 'ar') {
		switch (moonphase) {
//			case 'New Moon': { return 'هلال'; }
			case 'هلال (أول الشهر)': { return 'متز.هل.'; } //waxing crescent**
			case 'تربيع أول': { return 'تربيع ١.'; }//first quarter**
			case 'أحدب متزايد: واجهة للقمر أو ': { return 'احذب .متز.'; } //waxing gibbous**
			case 'بدر: قرص مضيء بالكامل': { return 'بدر'; } //full moon**
			case 'أحدب متناقص': { return 'متقص.احد.'; } // waning gibbous**
//			case 'Last Quarter': /* for testing with emulation.js */
//			case 'Last Quarter': { return 'ت. اخ.'; } //last quarter
			case 'هلال (آخر الشهر)': { return 'متقص.هل.'; } //waning crescent**
		}
	}
	return moonphase; //any languages we don't have translations for yet
}

//ORDINAL NUMBER SUFFIXES
function Suffix(tmpDate) {
	if (lang == "es") { /* Spanish */ 
		switch (tmpDate) { 
			case 1: 
			case 11:
			case 21:
			case 31:
			case 3:
			case 13:
			case 23:
				return tmpDate + "ro";
			break;
			case 2:
			case 12:
			case 22:
				return tmpDate + "do";
			break;
			case 7:
			case 17:
			case 27:
			case 10:
			case 20:
			case 30:
				return tmpDate + "mo";
			break;
			case 8:
			case 18:
			case 28:
				return tmpDate + "vo";
			break;
			case 9:
			case 19:
			case 29:
				return tmpDate + "no";
			break;
			default:
				return tmpDate + "to";
			break;
		}
	}
	else if (lang == "de" || lang == "fi" || lang == "no" || lang == "tr" || lang == "hr") { /* German, Finnish, Norwegian, Turkish, Croatian */
		switch (tmpDate) {
			default:
				return tmpDate + ".";
			break;
		}
	}
	else if (lang == "it") { /* Italian */
		switch (tmpDate) {
			default:
				return tmpDate + "°";
			break;
		}
	}
	else if (lang == "ru") { /* Russian */
		switch (tmpDate) {
			default:
				return tmpDate + "-й";
			break;
		}
	}
	else if (lang == "el") { /* Greek */
		switch (tmpDate) {
			default:
				return tmpDate + "ο";
			break;
		}
	}
	else if (lang == "fr") { /* French */
		switch (tmpDate) {
			case 1:
			case 11:
			case 21:
			case 31:
				return tmpDate + "er";
			break;
			default:
				return tmpDate + "e";
			break;
		}
	}
	else if (lang == "nl") { /* Dutch */
		switch (tmpDate) {
			case 1:
			case 8:
			case 20:
			case 21:
			case 22:
			case 23:
			case 24:
			case 25:
			case 26:
			case 27:
			case 28:
			case 29:
			case 30:
			case 31:
				return tmpDate + "ste";
			break;
			default:
				return tmpDate + "de";
			break;
		}
	}
	else if (lang == "id" || lang == 'vi'|| lang == 'he' || lang == 'ar') { /* Indonesian & Vietnamese */
		switch (tmpDate) {
			default:
				return tmpDate + "";
			break;
		}
	}
	else { /* English */
		switch (tmpDate) {
			case 1:
			case 21:
			case 31:
				return tmpDate + "st";
			break;
			case 2: 
			case 22:
				return tmpDate + "nd";
			break;
			case 3:
			case 23:
				return tmpDate + "rd";
			break;
			default:
				return tmpDate + "th";
			break;
		}
	}
}



