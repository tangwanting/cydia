// This conversion script by WRUSSELL1989 //

function tConvert(time) {
if (twentyfourh == true) {
  var timecut, timeE, amm, cvtt;
  if (String(time).length > 3) {
    timecut = String(time).slice(0, 2);
    timeE = String(time).slice(2, 4);
  } else {
    timeE = String(time).slice(1, 3);
    timecut = String(time).slice(0, 1);
  }
  cvtt = timecut;
  return cvtt + ' h';
} else {
  var timecut, timeE, amm, cvtt;
  if (String(time).length > 3) {
    timecut = String(time).slice(0, 2);
    timeE = String(time).slice(2, 4);
  } else {
    timeE = String(time).slice(1, 3);
    timecut = String(time).slice(0, 1);
  }
  if (timecut === "00") {
    return '12 am';
  }
  amm = (timecut > 11) ? " pm" : " am";
  cvtt = (timecut > 12) ? timecut - 12 : parseInt(timecut, 10);
  return cvtt + amm;}
};

function dConvert(time) {
if (twentyfourh == true) {
  var timecut, timeE, amm, cvtt;
  if (String(time).length > 3) {
    timecut = String(time).slice(0, 2);
    timeE = String(time).slice(2, 4);
  } else {
    timeE = String(time).slice(1, 3);
    timecut = String(time).slice(0, 2);
  }
  cvtt = timecut;
  return cvtt;
} else {
  var timecut, timeE, amm, cvtt;
  if (String(time).length > 3) {
    timecut = String(time).slice(0, 2);
    timeE = String(time).slice(2, 4);
  } else {
    timeE = String(time).slice(1, 3);
    timecut = String(time).slice(0, 2);
  }
  if (timecut === "00") {
    return '12';
  }
  amm = (timecut > 11) ? " pm" : " am";
  cvtt = (timecut > 12) ? timecut - 12 : parseInt(timecut, 10);
  return cvtt;}
};

function xConvert(time) {
  var timecut, timeE, amm, cvtt, day;
if (twentyfourh == true) {
  if (String(time).length > 3) {
    timecut = String(time).slice(0, 2);
    timeE = String(time).slice(2, 5);
  } else {
    timeE = String(time).slice(0, 2);
    timecut = String(time).slice(0, 2);
  }
   cvtt = (timecut < 12) ? parseInt(timecut, 10) +12 : parseInt(timecut, 10);
  return cvtt;
} else {
  if (String(time).length > 3) {
    timecut = String(time).slice(0, 2);
    timeE = String(time).slice(2, 5);
   day = String(time).slice(5,7);
  } else {
    timeE = String(time).slice(0, 2);
    timecut = String(time).slice(0, 2);
   day = String(time).slice(3,5);
  }
if (day == "PM" && timecut < 12) {
   cvtt = parseInt(timecut, 10) +12;
  } else {
cvtt = parseInt(timecut, 10);}
return cvtt;}
};

function wConvert(time) {
if (twentyfourh == true) {
  var timecut, timeE, amm, cvtt, day;
  if (String(time).length > 3) {
    timecut = String(time).slice(0, 2);
    timeE = String(time).slice(2, 5);
    day = String(time).slice(5,7);
  } else {
    timeE = String(time).slice(1, 3);
    timecut = String(time).slice(0, 1);
    day = String(time).slice(3,5);
  }
 if (day == "PM" && timecut < 12) {
   cvtt = timecut +12;
  } else {
cvtt = timecut;}
zeroAdd = (cvtt < 10) ? "0"+cvtt : cvtt;
  return zeroAdd + timeE;
} else {
  var timecut, timeE, day, amm, cvtt;
  if (String(time).length > 3) {
    timecut = String(time).slice(0, 2);
    timeE = String(time).slice(2, 5);
    day = String(time).slice(5,7);
  } else {
    timeE = String(time).slice(1, 3);
    timecut = String(time).slice(0, 1);
   day = String(time).slice(3, 5);
  }
  if (timecut === "00") {
    return '12';
  }
  right = day.toLowerCase();
  cvtt = parseInt(timecut, 10);
  return cvtt + timeE + " " + right;}
};

function rConvert(time) {
if (twentyfourh == true) {
  var timecut, timeE, amm, cvtt;
  if (String(time).length > 3) {
    timecut = String(time).slice(0, 2);
    timeE = String(time).slice(2, 4);
  } else {
    timeE = String(time).slice(1, 3);
    timecut = String(time).slice(0, 1);
  }
  cvtt = timecut;
  return cvtt + ':' + timeE;
} else {
  var timecut, timeE, amm, cvtt;
  if (String(time).length > 3) {
    timecut = String(time).slice(0, 2);
    timeE = String(time).slice(2, 4);
  } else {
    timeE = String(time).slice(1, 3);
    timecut = String(time).slice(0, 1);
  }
  if (timecut === "0") {
    return '12 am';
  }
  amm = (timecut > 11) ? " pm" : " am";
  cvtt = (timecut > 12) ? timecut - 12 : parseInt(timecut, 10);
  return cvtt + ":" + timeE + " " + amm.toUpperCase();}
};

function timeToDayName(time) {
     
      var today = new Date();
      var tomorrow = new Date(today.getTime() + (24 * 60 * 60 * 1000));
      if (time == today.getDay()) {
            if (lang == "vi") {
            return "Hôm nay";
            } else {
            return "Today";
        }
      } else if (time == tomorrow.getDay()) {
             if (lang == "vi") {
             return "Ngày mai";
             } else {
            return "Tomorrow";
        }
      }
      switch(time) {
          case 0:
            return "Sunday";
          case 1:
            return "Monday";
          case 2:
            return "Tuesday";
          case 3:
            return "Wednesday";
          case 4:
            return "Thursday";
          case 5:
            return "Friday";
          case 6:
            return "Saturday";
          default:
            return "";
        } 
  }
