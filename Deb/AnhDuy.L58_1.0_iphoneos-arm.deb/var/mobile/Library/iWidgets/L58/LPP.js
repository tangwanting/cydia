/* Created by LockPlus Pro by JunesiPhone http://twitter.com/junesiphone This is for personal use only. You cannot sell this widget. If you want to sell a widget code your own. */ var savedElements = {"overlay":"",


"placedElements":{"hrmintx":{"position":"absolute","font-family":"HelveticaNeue","color":"rgb(255, 255, 255)","text-transform":"capitalize","word-spacing": "0px","display":"none", "left":133,"z-index":"9999","top":635,"font-size":"10px"},



"ttext":{"left":"16px","lineHeight":"32px","position":"absolute","text-align":"center","-webkit-text-fill-color":"transparent","text-transform":"capitalize", "letter-spacing":"1px", "font-family":"anhduy4","font-size":"13px","width":"320px","-webkit-background-clip":"text","color":"rgba(222, 202, 157, 1.00)","opacity":"100","background":"linear-gradient(to right, white, white)","height":"37px","z-index":50,"background-color":"rgba(0, 0, 0, 0)","top":"628px"},


"batterypercent":{"height":"17px","position":"absolute","font-family":"HelveticaNeue","color":"rgb(255, 255, 255)","text-transform":"uppercase","width":"24px","z-index":"9999","top":620,"left":38,"font-size":"8px"},



"day":{"position":"absolute","font-family":"anhduy2","color":"rgb(255, 255, 255)","text-transform":"uppercase", "letter-spacing": "10px","word-spacing": "0px",  "z-index":"2","top":598,"left":80,"font-size":"32px"},



"dateplus":{"height":"17px","position":"absolute","font-family":"HelveticaNeue","color":"rgb(255, 255, 255)","text-transform":"uppercase","width":"24px","z-index":"9999","top":584,"left":77,"font-size":"8px"},



"boxCircleOne":{"left":28,"border-color":"rgb(255, 255, 255)","border-width":"1px","position":"absolute","border-radius":"999px","width":"35px","font-family":"helvetica","font-size":"30px","-webkit-backdrop-filter":"blur(5px)","color":"white","height":"35px","border-bottom-right-radius":"320px","background-color":"rgba(52, 52, 52, 0.56)","z-index":"-9999","border-style":"solid","top":570},



"ft59_mashup":{"position":"absolute","font-family":"mashup","color":"white","z-index":"9999","top":629,"left":38,"font-size":"16px"},



"tempdegplus":{"position":"absolute","font-family":"quadrantabold","color":"rgb(255, 255, 255)","left":"40px","z-index":"9999","top":591,"font-size":"9px"},



"boxCircleTwo":{"left":29,"border-color":"rgb(255, 255, 255)","border-width":"1px","position":"absolute","border-radius":"999px","border-top-right-radius":"320px","width":"35px","font-family":"helvetica","font-size":"30px","-webkit-backdrop-filter":"blur(5px)","color":"white","height":"35px","border-bottom-right-radius":"999px","background-color":"rgba(52, 52, 52, 0.56)","z-index":"-9999","border-style":"solid","top":612},



"icon":{"height":"20px","position":"absolute","font-family":"helvetica","color":"white","width":"20px","z-index":"9999","top":573,"left":35,"font-size":"30px"},



"boxCircleThree":{"left":69,"border-color":"rgb(255, 255, 255)","border-width":"1px","position":"absolute","border-radius":"999px","border-bottom-left-radius":"320px","width":"35px","font-family":"helvetica","font-size":"30px","-webkit-backdrop-filter":"blur(5px)","color":"white","height":"35px","border-bottom-right-radius":"999px","background-color":"rgba(52, 52, 52, 0.56)","z-index":"-9999","border-style":"solid","top":571}},

"iconName":"plex"}