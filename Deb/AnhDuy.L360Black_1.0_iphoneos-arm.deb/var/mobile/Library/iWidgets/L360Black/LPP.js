var savedElements = {"placedElements":{"boxOne":{"width":"355px","height":"232px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"468px","left":"-18px","font-family":"helvetica","font-size":"30px","color":"white","data-image":"https://i.imgur.com/ZV2Re4V.png","background-size":"cover","background-repeat":"no-repeat"},


"daydatesmonth":{"position":"absolute","z-index":"2","top":"550.5px","left":"25px","font-family":"anhduy7","text-transform":"uppercase", "font-size":"22px","color":"rgba(165, 165, 165, 1.00)","width":"267px","text-transform":"original","text-align":"center","height":"40px","lineHeight":"39px","text-shadow":"1px 2px 2px rgb(0, 0, 0)","letter-spacing":"1"},



"zclock":{"position":"absolute","z-index":"2","top":"487px","left":"63px","font-family":"anhduy1","font-size":"30px","color":"rgba(165, 165, 165, 1.00)","height":"41px","width":"190px","text-align":"center","lineHeight":"38px","text-shadow":"1px 1px 2px rgb(0, 0, 0)"},



"tempdegplus":{"position":"absolute","z-index":3,"top":"60px","left":"29px","font-family":"anhduy7","font-size":"18px","color":"rgba(165, 165, 165, 1.00)","height":"26px","width":"49px","lineHeight":"26px","padding-left":"4px","text-shadow":"0px 1px 1px rgb(0, 0, 0)","text-align":"left"},



"boxTwo":{"width":"355px","height":"135px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"28px","left":"-18px","font-family":"helvetica","font-size":"30px","color":"white","data-image":"https://i.imgur.com/PXvQaK2.png","background-size":"cover","background-repeat":"no-repeat"},




"batterypercent":{"position":"absolute","z-index":"2","top":"63px","left":"167px","font-family":"anhduy7","font-size":"11px","color":"rgba(165, 165, 165, 1.00)","width":"46px","text-align":"center","text-shadow":"0px 1px 1px rgb(0, 0, 0)","padding-left":"2px"},



"boxCircleOne":{"width":"38px","height":"5px","background-color":"rgba(255, 0, 0, 0)","z-index":"2","border-color":"rgb(255, 255, 255)","border-style":"solid","border-width":"1px","position":"absolute","top":"66px","left":"241px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white"},



"boxCircleTwo":{"width":"36px","height":"3px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"68px","left":"243px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","is-wifi":"false","is-signal":"false","is-battery":"true","background":"linear-gradient(to bottom, rgb(192, 192, 192) 0%, rgb(113, 113, 113) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},



"boxCircleThree":{"width":"38px","height":"5px","background-color":"rgba(255, 0, 0, 0)","z-index":"2","border-color":"rgb(255, 255, 255)","border-style":"solid","border-width":"1px","position":"absolute","top":"89px","left":"241px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white"},



"boxCircleFour":{"width":"38px","height":"5px","background-color":"rgba(255, 0, 0, 0)","z-index":"2","border-color":"rgb(255, 255, 255)","border-style":"solid","border-width":"1px","position":"absolute","top":"112px","left":"241px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white"},



"boxCircleFive":{"width":"36px","height":"3px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"91px","left":"243px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, rgb(192, 192, 192) 0%, rgb(113, 113, 113) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","is-battery":"false","is-signal":"false","is-wifi":"true"},



"textOne":{"position":"absolute","z-index":"2","top":"85px","left":"168px","font-family":"anhduy7","font-size":"11px","color":"rgba(165, 165, 165, 1.00)","innerHTML":"Wifi","width":"46px","letter-spacing":"2px","padding-left":"3px","text-shadow":"0px 1px 1px rgb(0, 0, 0)","text-align":"center"},



"boxCircleSix":{"width":"36px","height":"3px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"114px","left":"243px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, rgb(192, 192, 192) 0%, rgb(113, 113, 113) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","is-battery":"false","is-wifi":"false","is-signal":"true"},



"textTwo":{"position":"absolute","z-index":"2","top":"108px","left":"167px","font-family":"anhduy7","font-size":"11px","color":"rgba(165, 165, 165, 1.00)","innerHTML":"Sóng","letter-spacing":"2px","width":"46px","padding-left":"3px","text-shadow":"0px 1px 1px rgb(0, 0, 0)","text-align":"center"},



"day2icon":{"position":"absolute","z-index":"2","top":"93px","left":"78px","font-family":"anhduy","font-size":"30px","color":"rgba(165, 165, 165, 1.00)","width":"22px","height":"22px"},



"day2day":{"position":"absolute","z-index":"2","top":"116px","left":"74px","font-family":"anhduy7","font-size":"9px","color":"rgba(165, 165, 165, 1.00)","width":"30px","text-align":"center","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.6)","letter-spacing":"initial","text-transform":"capitalize"},



"day3day":{"position":"absolute","z-index":"2","top":"116px","left":"113px","font-family":"anhduy7","font-size":"9px","color":"rgba(165, 165, 165, 1.00)","text-transform":"capitalize","width":"32px","text-align":"center","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.6)"},



"day3icon":{"position":"absolute","z-index":"2","top":"93px","left":"117px","font-family":"anhduy","font-size":"30px","color":"rgba(165, 165, 165, 1.00)","width":"22px","height":"22px"},



"highdeg":{"position":"absolute","z-index":"2","top":"58px","left":"86px","font-family":"anhduy7","font-size":"10px","color":"rgba(165, 165, 165, 1.00)","width":"20px","text-align":"center","text-shadow":"0px 1px 1px rgb(0, 0, 0)"},



"lowdeg":{"position":"absolute","z-index":"2","top":"76px","left":"86px","font-family":"anhduy7","font-size":"10px","color":"rgba(165, 165, 165, 1.00)","width":"20px","text-align":"center","text-shadow":"0px 1px 1px rgb(0, 0, 0)"},



"coloricon":{"position":"absolute","z-index":"2","top":"60px","left":"116px","font-family":"anhduy7","font-size":"20px","color":"rgba(165, 165, 165, 1.00)","width":"32px","text-align":"center","height":"28px","lineHeight":"27px","text-shadow":"0px 1px 1px rgb(0, 0, 0)"},



"day1day":{"position":"absolute","z-index":"2","top":"116px","left":"33px","font-family":"anhduy7","font-size":"9px","color":"rgba(165, 165, 165, 1.00)","width":"30px","text-align":"center","text-transform":"capitalize","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.6)"},



"day1icon":{"position":"absolute","z-index":"2","top":"93px","left":"36px","font-family":"anhduy","font-size":"30px","color":"rgba(165, 165, 165, 1.00)","width":"22px","height":"22px"}},"iconName":"mauri"}