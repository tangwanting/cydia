var savedElements = {"placedElements":{


"boxOne":{"width":"320px","height":"592px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"12px","left":"0px","font-family":"helvetica","font-size":"30px","color":"white","data-image":"images/wall.png","background-size":"cover","background-repeat":"no-repeat"},


"boxTwo":{"width":"290px","height":"515px","background-color":"rgba(255, 255, 255, 0)","z-index":0,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"57.5px","left":"15px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"30px","-webkit-backdrop-filter":"blur(5px)"},



"icon":{"position":"absolute","z-index":"2","top":"516.4px","left":"139px","font-family":"helvetica","font-size":"30px","color":"white","width":"42px","height":"42px"},



"zclock":{"position":"absolute","z-index":"2","top":"43px","left":"120px","font-family":"anhduy7","font-size":"28px","color":"rgba(166, 127, 77, 1.00)","width":"82px","text-align":"center","text-shadow":"1px 2px 1px rgb(0,0,0)","height":"17px","letter-spacing":"6px"},




"dayabdatemonth":{"position":"absolute","z-index":"2","top":"70px","left":"60px","font-family":"anhduy6","font-size":"13px","color":"rgba(157, 11, 12, 1.00)","width":"200px","text-align":"center","height":"28px","text-shadow":"1px 2px 2px rgb(0,0,0)","letter-spacing":"2px","lineHeight":"25px","background":"inherit","-webkit-background-clip":"inherit","-webkit-text-fill-color":"initial","text-transform":"uppercase"},


"condition":{"position":"absolute","z-index":"2","top":"572px","left":"60px","font-family":"anhduy8", "letter-spacing":"4px", "font-size":"10px","color":"rgba(166, 127, 77, 1.00)","width":"200px","height":"16px","lineHeight":"14px","text-align":"center","text-shadow":"1px 2px 2px rgb(0,0,0)"},




"tempdegplus":{"position":"absolute","z-index":"2","top":"543px","left":"60px","font-family":"anhduy6","font-size":"14px","color":"rgba(157, 11, 12, 1.00)","width":"64px","height":"24px","text-align":"center","lineHeight":"22px","text-shadow":"1px 1px 1px rgb(0,0,0)","letter-spacing":"2px", "text-transform":"uppercase"},




"highdashlowdeg":{"position":"absolute","z-index":"2","top":"547px","left":"191px","font-family":"anhduy6","font-size":"14px","color":"rgba(157, 11, 12, 1.00)","width":"66px","text-align":"center","text-shadow":"1px 1px 1px rgb(0,0,0)","height":"18px"}},"iconName":"custover","text-transform":"uppercase" }