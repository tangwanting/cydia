#import "MWPSEditTextCell.h"

@interface MWPSSecureEditTextCell : MWPSEditTextCell
@end
