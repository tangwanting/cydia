//Translation for major components. Originally by Junesiphone, modified by Evelyn (@ev_ynw) and (@luis9_49)//

if (Lang == "en") {
    var dates = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"];
    var hoy = ["chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào", "chào"];
    var hoys = ["buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi sáng", "buổi chiều", "buổi chiều", "buổi chiều", "buổi chiều", "buổi chiều", "buổi chiều", "buổi chiều", "buổi tối", "buổi tối", "buổi tối", "buổi tối", "buổi tối", "buổi tối"];
    var days = ["CN", "thứ 2", "thứ 3", "thứ 4", "thứ 5", "thứ 6", "thứ 7"];
    var months = ["tháng 1", "tháng 2", "tháng 3", "tháng 4", "tháng 5", "tháng 6", "tháng 7", "tháng 8", "tháng 9", "tháng 10", "tháng 11", "tháng 12"];
    var son = ["Nó là"];
    var bater = ["pin"];
    var proto = ["đang sạc"];
}
if (Lang == "es") {
    var dates = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"];
    var days = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
    var months = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
    var hoy = ["Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenos", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas", "Buenas"];
    var hoys = ["Dias", "Dias", "Dias", "Dias", "Dias", "Dias", "Dias", "Dias", "Dias", "Dias", "Dias", "Dias", "Tardes", "Tardes", "Tardes", "Tardes", "Tardes", "Tardes", "Tardes", "Noches", "Noches", "Noches", "Noches", "Noches", "Noches"];
    var son = ["Son"];
    var bater = ["Batería"];
    var proto = ["Cargando..."];
}
if (Lang == "de") {
    var dates = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"];
    var hoy = ["Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten", "Guten"];
    var hoys = ["morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "morgen", "nachmittag", "nachmittag", "nachmittag", "nachmittag", "nachmittag", "nachmittag", "nachmittag", "nacht", "nacht", "nacht", "nacht", "nacht", "nacht"];
    var days = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
    var months = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];
    var son = ["es ist"];
    var bater = ["Batterie"];
    var proto = ["Charging..."];
}
if (Lang == "it") {
    var dates = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"];
    var hoy = ["buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buongiorno", "buon", "buon", "buon", "buon", "buon", "buon", "buon", "buona", "buona", "buona", "buona", "buona", "buona"];
    var hoys = ["", "", "", "", "", "", "", "", "", "", "", "", "pomeriggio", "pomeriggio", "pomeriggio", "pomeriggio", "pomeriggio", "pomeriggio", "pomeriggio", "notte", "notte", "notte", "notte", "notte", "notte"];
    var days = ["Domenica", "Lunedi", "Martedì", "Mercoledì", "Giovedi", "Venerdì", "Sabato"];
    var months = ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"];
    var son = ["Sono"];
    var bater = ["Batteria"];
    var proto = ["Charging..."];
}
if (Lang == "pt") {
    var dates = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"];
    var hoy = ["bom", "bom", "bom", "bom", "bom", "bom", "bom", "bom", "bom", "bom", "bom", "bom", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa", "boa"];
    var hoys = ["Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "Dia", "tarde", "tarde", "tarde", "tarde", "tarde", "tarde", "tarde", "noite", "noite", "noite", "noite", "noite", "noite"];
    var days = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sabado"];
    var months = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
    var son = ["são"];
    var bater = ["Pilha"];
    var proto = ["Charging..."];
}