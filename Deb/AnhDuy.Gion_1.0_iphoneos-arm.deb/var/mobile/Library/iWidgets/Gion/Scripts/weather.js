 /*
         ___ ._______.______  _____._.___.__  ._______.______
.___    |   |: .____/:      \ \__ _:|:   |  \ : .____/: __   \
:   | /\|   || : _/\ |   .   |  |  :||   :   || : _/\ |  \____|
|   |/  :   ||   /  \|   :   |  |   ||   .   ||   /  \|   :  \
|   /       ||_.: __/|___|   |  |   ||___|   ||_.: __/|   |___\
|______/|___|   :/       |___|  |___|    |___|   :/   |___|
        :
        :
Weather Library for Cydget
weather.cy must be defined before this.
var celsius = false; must be defined in html.
Website: http://JunesiPhone.com
Creator: JunesiPhone
*/
(function wlib() {
    'use strict';
    var w = getWeather(),
        weather = {
            cvtF: function (temp) {
                return (temp == "--") ? "--" : Math.round(temp * 1.8 + 32);
            },
            cvtK: function (wind) {
                return Math.round(((wind * 1.609344) * 100) / 100);
            },
            cvtM: function (distance) {
                return Math.round(distance * 1.60934);
            },
            cvtS: function (time) {
                var timecut, timeE, cvtt;
                if (String(time).length > 3) {
                    timecut = String(time).slice(0, 2);
                    timeE = String(time).slice(2, 4);
                } else {
                    timeE = String(time).slice(1, 3);
                    timecut = String(time).slice(0, 1);
                }
                if (timecut === "00") {
                    return 12;
                }
                cvtt = (timecut > 12) ? timecut - 12 : timecut;
                return cvtt + ":" + timeE;
            },
            temp: function (deg) {
                return (celsius ? w.temperature : this.cvtF(w.temperature)) + deg;
            },
            high: function (deg) {
                return (celsius ? w.dayForecasts[0].high + deg : this.cvtF(w.dayForecasts[0].high) + deg);
            },
            low: function (deg) {
                return (celsius ? w.dayForecasts[0].low + deg : this.cvtF(w.dayForecasts[0].low) + deg);
            },
            condition: function () {
                return w.conditionCode;
            },
            city: function () {
                return w.name;
            },
            humidity: function () {
                return Math.round(w.humidity);
            },
            windchill: function (deg) {
                return Math.round(w.windChill) + deg;
            },
            wind: function (spd) {
                return (celsius ? this.cvtK(Math.round(w.windSpeed)) + spd : Math.round(w.windSpeed) + spd);
            },
            direction: function () {
                return windDirection();
            },
            visibility: function (dis) {
                return (celsius ? this.cvtM(Math.round(w.visibility)) + dis : Math.round(w.visibility) + dis);
            },
            rain: function (perc) {
                return Math.round(w.precipitationForecast) + perc;
            },
            dewpoint: function (deg) {
                return Math.round(w.dewPoint) + deg;
            },
            feelslike: function (deg) {
                return (celsius ? w.feelsLike + deg : this.cvtF(w.feelsLike) + deg);
            },
            sunset: function () {
                return (celsius ? w.sunsetTime : this.cvtS(w.sunsetTime));
            },
            sunrise: function () {
                return (celsius ? w.sunriseTime : this.cvtS(w.sunriseTime));
            },
            updated: function () {
                return w.updateTimeString;
            },
            start : function (weatherInterval) {
                var currentTime = new Date().getTime();
                if (currentTime > Number(localStorage.getItem('lastUpdate'))) {
                    weatherdivs();
                    updateWeather();
                    localStorage.setItem('lastUpdate', currentTime + weatherInterval);
                    setTimeout(function () {
                        wlib();
                        weatherdivs();
                    }, 2500);
                } else {
                    weatherdivs();
                }
                setTimeout(function () {
                    weather.start(weatherInterval);
                }, weatherInterval);
            }
        };
    window.weather = weather;
}());