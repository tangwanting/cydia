

switch (lang) {
	
	case "vi": 
		var days = ["chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"];
		var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
		var hightext = "H: ";  
		var lowtext = "L: ";
		var batterytxt = "Battery: ";
		var sunrisetext ="Sunrise";
		var sunsettext = "Sunset";
		var feelsliketext = "Feels like: ";
		var lastupdatetext = "Updated: ";
		var humiditytext = "Humidity: ";
		var visibilitytext = "Visibility: ";
		var pressuretext = "Pres: ";
		var windtext = "Wind: ";
		var nowindtext = "No wind";
		var moontext = "Moon: ";
		var WeatherDesc = ["Có bão", "Bão nhiệt đới", "Có bão", "Có dông", "Có dông", "Có tuyết", "Mưa đá", "Mưa đá", "Mưa phùn lạnh", "Mưa phùn", "Mưa lạnh", "Mưa rào", "Có mưa", "Có bão", "Mưa tuyết", "Có tuyết", "Có tuyết", "Mưa đá", "Mưa tuyết", "Gió bụi", "Sương mù dày", "Sương mù nhẹ", "Sương mù", "Gió mạnh", "Có gió", "Trời lạnh", "Có mây vài nơi", "Trời nhiều mây", "Trời nhiều mây", "Có mây vài nơi", "Có mây vài nơi", "Quang mây", "Có nắng", "Trời quang mây", "Trời nắng", "Mưa đá", "Trời nóng", "Có sấm sét", "Có sấm sét", "Có sấm sét", "Mưa lớn", "Có tuyết", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Ít mây", "Có dông", "Có tuyết", "Có dông", "blank"];
		var cardinal = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
	break;



case "no": 
		var days = ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"];
		var months = ["Januar", "Februar", "Mars", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember"];
		var batterytxt = "Batteri : ";
		var hightext = "Høy: ";
		var lowtext = "Lav: ";
		var sunrisetext ="Soloppgang";
		var sunsettext = "Solnedgang";
		var feelsliketext = "Føles som: ";
		var lastupdatetext = "Oppdatert: ";
		var humiditytext = "Luftfuktighet: ";
		var visibilitytext = "Sikt: ";
		var pressuretext = "Lufttrykk: ";
		var windtext = "Vind: ";
		var nowindtext = "Vindstille";
		var moontext = "Måne: ";
		var WeatherDesc = [
			"Tornado",
			"Tropisk Storm",
			"Orkan",
			"Kraftige Tordenbyger",
			"Tordenbyger",
			"Blandet Regn og Snø",
			"Blandet Regn og Sludd",
			"Blandet Snø og Sludd",
			"Underkjølt Duskregn",
			"Duskregn",
			"Underkjølt regn",
			"Regnbyger",
			"Regnbyger",
			"Snøbyger",
			"Lette Snøbyger",
			"Snøfokk",
			"Snø",
			"Hagl",
			"Sludd",
			"Støv",
			"Tåke",
			"Dis",
			"Røykfylt",
			"Mye Vind",
			"Vindkuler",
			"Frost",
			"Skyet ",
			"Muligheter For Regn",
			"Muligheter For Regn",
			"Delvis Skyet",
			"Delvis Skyet",
			"Klart",
			"Solskinn",
			"Lettskyet",
			"Lettskyet",
			"Blandet Regn og Hagl",
			"Varmt",
			"Isolerte Tordenbyger",
			"Spredte Tordenbyger",
			"Spredte Tordenbyger",
			"Spredte Regnbyger",
			"Kraftig Snøfall",
			"Spredte Snøbyger",
			"Kraftig Snøfall",
			"Delvis Skyet",
			"Regn og Torden",
			"Snøbyger",
			"Isolerte Regn og Torden",
			"ikke mottak"];
		var cardinal = ["N", "NNØ", "NØ", "ØNØ", "Ø", "ØSØ", "SØ", "SSØ", "S", "SSV", "SV", "VSV", "V", "VNV", "NV", "NNV"];
	break;
	
	case "tr": 
		var days = ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma​​", "Cumartesi"]; 
		var months = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül","Ekim", "Kasım", "Aralık"]; 
		var hightext = "Yüksek "; 
		var lowtext = "Düşük "; 
		var batterytxt = "Pil : ";
		var sunrisetext = "Gündoğumu"; 
		var sunsettext = "Gün Batımı"; 
		var feelsliketext = "Hissedilen : "; 
		var pressuretext = "Basınç : "; 
		var lastupdatetext = "Güncellendi : "; 
		var visibilitytext = "Görüş mesafesi"; 
		var humiditytext = "Nem "; 
		var windtext = "Rüzgar: ";
		var moontext = "Ay: ";
		var nowindtext = "Rüzgar yok";
		var WeatherDesc = [
			"Kasırga", 
			"Tropik fırtına", 
			"Fırtına", 
			"Şiddetli fırtına", 
			"Gök gürültülü fırtına",
			"Karışık yağmur ve kar", 
			"Karışık yağmur ve sulusepken", 
			"Karışık kar ve sulusepken", 
			"Çisenti Donma", 
			"Çiseleyen yağmur", 
			"Dondurucu çiseleyen yağmur",
			"Sağanak", 
			"Yağmur", 
			"Hafif kar",
			"Hafif kar sağnağı", 
			"Esen kar", 
			"Kar", 
			"Dolu", 
			"Sulu kar", 
			"Toz", 
			"Sisli",
			"Sis", 
			"Dumanlı", 
			"Yaygaracı", 
			"Rüzgarlı", 
			"Soğuk", 
			"Bulutlu", 
			"Çoğunlukla bulutlu", 
			"Çoğunlukla bulutlu", 
			"Parçalı bulutlu", 
			"Parçalı bulutlu", 
			"Açık", 
			"Güneşli", 
			"Çoğunlukla açık", 
			"Hafif bulutlu", 
			"Karışık yağmur ve dolu", 
			"Sıcak", 
			"İzole gökgürültülü sağanak", 
			"Dağınık gökgürültülü sağanak",
			"Dağınık gökgürültülü sağanak",
			"Dağınık sağanak", 
			"Şiddetli kar", 
			"Dağınık sağanak kar", 
			"Şiddetli kar", 
			"Parçalı bulutlu", 
			"Gökgürültülü yağmur", 
			"Sağanak kar", 
			"Izole gökgürültülü yağmur", 
			"Müsait değil"];
		var cardinal = ["K", "KKD", "KD", "DKD", "D", "DGD", "GD", "GGD", "G", "GGB", "GB", "BGB", "B", "BKB", "KB", "KKB"];

	break;

	case "gr":
		var days = ["Κυριακή", "Δευτέρα", "Τρίτη", "Τετάρτη", "Πέμπτη", "Παρασκευή", "Σάββατο"];
		var months = ["Ιανουάριος", "Φεβρουάριος", "Μάρτιος", "Απρίλιος", "Μάιος", "Ιούνιος", "Ιούλιος", "Αύγουστος", "Σεπτέμβριος", "Οκτώβριος", "Νοέμβριος", "Δεκέμβριος"];
		var hightext = "Υψηλή ";
		var lowtext = "Χαμηλή ";
		var sunrisetext = "Ανατολή";
		var sunsettext = "Δύση";
		var batterytxt = "Μπαταρία : ";
		var feelsliketext = "Αίσθηση : ";
		var lastupdatetext = "ελέγχεται : ";
		var humiditytext = "Υγρασία "; 
		var visibilitytext = "Ορατότητα";      
		var pressuretext = "Πίεση ";
		var windtext = "Άνεμος: ";
		var moontext = "Ay: ";
		var nowindtext = "Χωρίς αέρα";
		var WeatherDesc = [
			"Ανεμοστρόβιλος",
			"Τροπική Καταιγίδα",
			"Τυφώνας",
			"Ισχυρές Καταιγίδες",
			"Καταιγίδες",
			"Βροχή και Χιόνι",
			"Βροχή και Χιονόνερο",
			"Χιόνι και Χιονόνερο",
			"Παγωμένο Ψιλόβροχο",
			"Ψιλόβροχο",
			"Παγωμένη Βροχή",
			"Καταιγίδες",
			"βροχή",
			"Διαστήματα Χιονιού",
			"Ελαφρές Χιονοπτώσεις",
			"Χιονοθύελλα",
			"Χιονόπτωση",
			"Χαλαζόπτωση",
			"Χιονόνερο",
			"Σκόνη",
			"Ομιχλώδης",
			"Καταχνιά",
			"Ομιχλώδης",
			"Θυελλώδης",
			"Ανεμώδης",
			"Κρύος",
			"Νεφελώδης ",
			"Κυρίως Νεφελώδης",
			"Κυρίως Νεφελώδης",
			"Μερικώς Νεφελώδης",
			"Μερικώς Νεφελώδης",
			"Αίθριος",
			"Ηλιόλουστος",
			"Κυρίως αίθριος",
			"Κυρίως λιακάδα",
			"Βροχή και Χαλάζι",
			"Ζεστός Καιρός",
			"Μεμονωμένες Καταιγίδες",
			"Ασθενείς Καταιγίδες",
			"Ασθενείς Καταιγίδες",
			"Πιθανές Βροχές",
			"Ισχυρή Χιονόπτωση",
			"Πιθανή Χιονόπτωση",
			"Ισχυρή Χιονόπτωση",
			"Μερικώς Νεφελώδης",
			"Καταιγίδες",
			"Χιονόπτωση",
			"Μεμονωμένες Καταιγίδες",
			"Μη Διαθέσιμος"];
		var cardinal = ["B", "BBA", "BA", "ABA", "A", "ANA", "NA", "NNA", "N", "ΝΝΔ", "ΝΔ", "ΔΝΔ", "Δ", "ΔΒΔ", "ΒΔ", "ΒΒΔ"];

	break;	

	case "ge":
		var days = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
		var months = ["Januar", "Februar", "Maerz", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];
		var hightext = "Hoch : ";
		var lowtext = "Tief : ";
		var sunrisetext = "Morgen";
		var sunsettext = "Abend";
		var feelsliketext = "fühlt sich an wie : ";
		var lastupdatetext = "Letztes Update : ";
		var visibilitytext = "Sichtweite : ";
		var batterytxt = "Batterie : ";
		var humiditytext = "Luftfeuchte : ";
		var pressuretext = "Luftdruck : ";
		var windtext = "Luft : ";    
		var nowindtext = "Kein wind";
		var moontext = "Mond: ";
		var WeatherDesc = [
			"Tornado",
			"Tropischer sturm",
			"Wirbelsturm",
			"Schwere gewitter",
			"Gewitter",
			"Regen und schnee",
			"Graupelschauer",
			"Schneeregen",
			"Gefrierender nieselregen",
			"Nieselregen",
			"Gefrierender regen",
			"Schauer",
			"Regen",
			"Schneegestuöber",
			"Leichte schneeschauer",
			"Schneetreiben",
			"Schnee",
			"Hagel",
			"Schneeregen",
			"Staubig",
			"Nebelig",
			"Dunstschleier",
			"Dunstig",
			"Stürmisch",
			"Windig",
			"Kalt",
			"Bewölkt ",
			"Meist bewölkt",
			"Meist bewölkt",
			"Teilweise bewölkt",
			"Teilweise bewölkt",
			"Klar",
			"Sonnig",
			"Heiter",
			"Meist sonnig",
			"Regen und hagel",
			"Heiss",
			"Örtliche gewitter",
			"Vereinzelte gewitte",
			"Vereinzelte gewitte",
			"Vereinzelte schauer",
			"Starker schneefall",
			"Vereinzelte schneeschauer",
			"Starker schneefall",
			"Teilweise bewölkt",
			"Gewitter",
			"Scheeschauer",
			"Örtliche gewitterschauer",
			"Nicht verfuegbar"];
		var cardinal = ["N", "NNO", "NO", "ONO", "O", "OSO", "SO", "SSO", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
	break;

	case "nl":
		var days = ["Zondag", "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag"];
		var months = ["Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December"];
		var hightext = "Hoog : ";
		var lowtext = "Laag : ";
		var sunrisetext ="Ochtend";
		var sunsettext = "Nacht";
		var feelsliketext = "Voelt als : ";
		var lastupdatetext = "Laatste Update : ";
		var humiditytext = "Vochtigheid : ";
		var batterytxt = "Accu : ";
		var visibilitytext = "Zichtbaarheid : ";	
		var pressuretext = "Druk : ";
		var windtext = "Winden : ";
		var nowindtext = "Geen wind";
		var moontext = "Maan: ";
		var WeatherDesc = [
			"Tornado",
			"Tropische Storm",
			"Wervelwind",
			"Zware Onweersbuien",
			"Onweersbuien",
			"Regen en Sneeuw",
			"Regen en Ijzel",
			"Sneeuw en Ijzel",
			"Bevriezende Motregen",
			"Motregen",
			"Ijzel",
			"Buien",
			"Buien",
			"Sneeuwvlagen",
			"Lichte Sneeuwbuien",
			"Sneeuw Drift",
			"Sneeuw",
			"Hagel",
			"Ijzel",
			"Stoffig",
			"Mistig",
			"Wazig",
			"Wazig",
			"Stormachtig",
			"Winderig",
			"Koud",
			"Bewolkt ",
			"Algemeen Bewolkt",
			"Algemeen Bewolkt",
			"Gedeeltelijk Bewolkt",
			"Gedeeltelijk Bewolkt",
			"Helder",
			"Zonnig",
			"Bewolkt Weer",
			"Bewolkt Weer",
			"Regen en Hagel",
			"Heet",
			"Geisoleerde Onweersbuien",
			"Verspreide Onweersbuien",
			"Verspreide Onweersbuien",
			"Verspreide Buien",
			"Zware Sneeuw",
			"Verspreide Sneeuwbuien",
			"Zware Sneeuw",
			"Gedeeltelijk Bewolkt",
			"Onweersbuien",
			"Sneeuwbuien",
			"Geisoleerde Onweersbuien",
			"Niet Beschikbaar"];
		var cardinal = ["N", "NNO", "NO", "ONO", "O", "OZO", "ZO", "ZZO", "Z", "ZZW", "ZW", "WZW", "W", "WNW", "NW", "NNW"];

	break;

	case "fi":
		var days = ["Sunnuntai", "Maanantai", "Tiistai", "Keskiviikko", "Torstai", "Perjantai", "Lauantai"];
		var months = ["Tammikuu", "Helmikuu", "Maaliskuu", "Huhtikuu", "Toukokuu", "Kesäkuu", "Heinäkuu", "Elokuu", "Syyskuu", "Lokakuu", "Marraskuu", "Joulukuu"];
		var hightext = "Korkein : ";
		var lowtext = "Alin : ";
		var batterytxt = "Akku : ";
		var sunrisetext = "Aamu";
		var sunsettext = "Yö";
		var feelsliketext = "Tuntuu : ";
		var pressuretext = "Paine : ";	
		var lastupdatetext = "Päivitetään : ";
		var visibilitytext = "Näkyvyys : ";
		var humiditytext = "Ilmankosteus : ";
		var windtext = "Tuuli : ";
		var nowindtext = "Ei tuulta";
		var moontext = "Kuu: ";
		var WeatherDesc = [
			"Tornaado",
			"Trooppinen myrsky",
			"Wervelwind",
			"Rankkoja ukkoskuuroja",
			"Ukkosmyrskyjä",
			"Vesisadetta ja räntää",
			"Vesi ja räntäsadetta",
			"Lumi ja räntäsadetta",
			"Jäätävää tihkusadetta",
			"Tihkusadetta",
			"Jäätävää sadetta",
			"Sadekuuroja",
			"Sade",
			"Lumisadetta",
			"Heikkoja lumikuuroja",
			"Lumituisku",
			"Lumisadetta",
			"Rakeita",
			"Räntää",
			"Pölyistä",
			"Sumuista",
			"Utuista",
			"Utuista",
			"Ei tietoja",
			"Tuulista",
			"kylmää",
			"Pilvistä",
			"Enimmäkseen pilvistä",
			"Enimmäkseen pilvistä",
			"Puolipilvistä",
			"Puolipilvistä",
			"Selkeää",
			"Aurinkoista",
			"Selkeää",
			"Selkeää",
			"Vesisadetta ja raekuuroja",
			"Hellettä",
			"Paikallisia ukkoskuuroja",
			"Hajanaisia ukkoskuuroja",
			"Hajanaisia ukkoskuuroja",
			"Hajanaisia sadekuuroja",
			"Rankkaa lumisadetta",
			"Hajanaisia lumikuuroja",
			"Rankkaa lumisadetta",
			"Puolipilvistä",
			"Ukkoskuuroja",
			"Lumikuuroja",
			"Paikallisia ukkoskuuroja",
			"Ei tietoja"];
		var cardinal = ["Pohjoinen", "Pohjoinen", "Luode", "Länsi", "Länsi", "Länsi", "Lounas", "Etelä", "Etelä", "Etelä", "Kaakko", "Itä", "Itä", "Itä", "Koillinen", "Pohjoinen"];

    break; 

	case "it":
		var days = ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
		var months = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];
		var hightext = "Alto : ";
		var lowtext = "Basso : ";
		var sunrisetext ="Alba";
		var sunsettext = "Tramonto";
		var feelsliketext = "Si sente come : ";
		var lastupdatetext = "Attuale : ";
		var humiditytext = "Umidita : ";
		var batterytxt = "Batteria : "; 
		var visibilitytext = "Visibilita : ";
		var pressuretext = "Pressione : ";
		var windtext = "Vento : ";   
		var nowindtext = "Senza Vento";
		var moontext = "Luna: ";
		var WeatherDesc = [
			"Tornado",
			"Tempesta tropicale",
			"Uragano",
			"Tuoni e fulmini",
			"Fulmini",
			"Misto pioggia e neve",
			"Misto pioggia e nevischio",
			"Misto neve e nevischio",
			"Grandine",
			"Pioggerella",
			"Grandine",
			"Diluvio",
			"Diluvio",
			"Raffiche di neve",
			"Poca neve",
			"Vento e neve",
			"Neve",
			"Grandine",
			"Nevischio",
			"Polvere",
			"Nebbiolina",
			"Nebbia",
			"Humeado",
			"Tempesa",
			"Ventoso",
			"Froddo",
			"Nuvoloso",
			"Molto nuvoloso",
			"Molto nuvoloso",
			"Parzialmente nuvoloso",
			"Parzialmente nuvoloso",
			"Sereno",
			"Soleggiato",
			"Sereno",
			"Sereno",
			"Misto neve e grandine",
			"Caldo",
			"Fulmini isolati",
			"Tempesta di fulmini",
			"Tempesta di fulmini",
			"Tempesta di pioggia",
			"Forti nevicate",
			"Neve sparsa",
			"Forti nevicate",
			"Parzialmente nuvoloso",
			"Rovesci temporaleschi",
			"Precipitazioni nevose",
			"Rovesci temporaleschi isolati",
			"Non disponibile"];   
		var cardinal = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSO", "SO", "OSO", "O", "ONO", "NO", "NNO"];

    break;

	case "ru":
		var days = ["Воскресенье","Понедельник","Вторник","Среда","Четверг","Пятница","Суббота"];
		var months = ['Января','Февраля','Марта','Апреля','Мая','Июня','Июля','Августа','Сентября','Октября','Ноября','Декабря'];
		var hightext = "привет : ";
		var lowtext = "вот : ";
		var sunrisetext ="утро";
		var sunsettext = "закат";
		var batterytxt = "аккумулятор : ";
		var feelsliketext = "чувствует как : ";
		var lastupdatetext = "обновлены в : ";
		var humiditytext = "Влажность : ";
		var visibilitytext = "видимость : ";
		var pressuretext = "давление : ";
		var windtext = "ветер : ";
		var nowindtext = "Нет ветра";
		var moontext = "Луна: ";
		var WeatherDesc = [
			"Торнадо",
			"Горячая буря",
			"Ураган",
			"Гроза",
			"Бури",
			"Дождь со снегом",
			"Дождь и мокрый снег",
			"Снег и мокрый снег",
			"Изморозь",
			"Изморось",
			"Ледяной дождь",
			"Дождь",
			"Дождь",
			"Снег с порывами",
			"Небольшой снег с дождем",
			"Снежные заряды",
			"Снег",
			"Град",
			"Дождь со снегом",
			"Пыль",
			"Туман",
			"Туман",
			"Туман",
			"Бурный",
			"Ветер",
			"Холодный",
			"Облачно ",
			"Небольшая облачность",
			"Небольшая облачность",
			"Переменная облачность",
			"Переменная облачность",
			"Ясно",
			"Солнечно",
			"Ясно",
			"Ясно",
			"Дождь и град",
			"Горячий",
			"Изолированные грозы",
			"Рассеянные грозы",
			"Рассеянные грозы",
			"Рассеянный дождь",
			"Сильный снег",
			"Рассеянный снег с дождем",
			"Сильный снег",
			"Переменная облачность",
			"Изолированные грозы с дождем",
			"Дождь со снегом",
			"Изолированные грозы с дождем",
			"Недоступно"];
		var cardinal = ["C", "CCB", "CB", "BCB", "B", "ВЮВ", "ЮВ", "ЮЮВ", "Ю", "ЗЗЮ", "ЗЮ", "ЗЮЗ", "3", "3C3", "C3", "CC3"];

	break;

	case "sp":
		var days = ["Dom", "Lun", "Mar", "Mie", "Jue", "Vie", "Sab"];
		var months = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
		var hightext = "Alto : ";
		var lowtext = "Bajo : ";
		var batterytxt = "Batería: ";
		var sunrisetext ="Mañana";
		var sunsettext = "Noche";
		var feelsliketext = "Se siente como : ";
		var lastupdatetext = "Actualizado : ";
		var humiditytext = "Humedad : ";
		var visibilitytext = "Visibilidad : ";
		var pressuretext = "Presion : ";
		var windtext = "Viento : ";
		var nowindtext = "No hay viento";
		var moontext = "Luna: ";
		var WeatherDesc = [
			"Tornado",
			"Tormenta Tropical",
			"Huracan",
			"Tormentas Electricas Severas",
			"Tormentas Electricas",
			"Mezcla de Lluvia y Nieve",
			"Mezcla de lluvia y aguanieve",
			"Mezcla de nieve y aguaniev",
			"Llovizna helada",
			"Llovizna",
			"Lluvia bajo cero",
			"Chubascos",
			"Chubascos",
			"Rafagas de nieve",
			"Ligeras precipitaciones de nieve",
			"Viento y nieve",
			"Nieve",
			"Granizo",
			"Aguanieve",
			"Polvareda",
			"Neblina",
			"Bruma",
			"Humeado",
			"Tempestuoso",
			"Vientoso",
			"Frio",
			"Nublado ",
			"Mayormente nublado",
			"Mayormente nublado",
			"Parcialmente despejado",
			"Parcialmente despejado",
			"Despejado",
			"Soleado",
			"Lindo",
			"Lindo",
			"Mezcla de lluvia y granizo",
			"Caluroso",
			"Tormentas electricas aisladas",
			"Tormentas electricas dispersas",
			"Tormentas electricas dispersas",
			"Chubascos dispersos",
			"Nieve fuerte",
			"Precipitaciones de nieve dispersas",
			"Nieve fuerte",
			"Parcialmente despejado",
			"Lluvia con truenos y relampagos",
			"Precipitaciones de nieve",
			"Tormentas aisladas",
			"No disponible"];
		var cardinal = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSO", "SO", "OSO", "O", "ONO", "NO", "NNO"];

    break;

	case "cn":
		var days = ["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
		var months = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
		var hightext = "最高 : ";
		var lowtext = "最低 : ";
		var batterytxt = "电池 : ";
		var sunrisetext = "日出";
		var sunsettext = "日落";
		var feelsliketext = "感覺像 : ";
		var pressuretext = "最高 : "; 
		var lastupdatetext = "上次更新 : ";
		var visibilitytext = "能见度 : ";
		var humiditytext = "湿度 : ";
		var windtext = "风向 : ";
		var nowindtext = "无风";
		var moontext = "月亮 : ";
		var WeatherDesc = [
			"风卷残云",
			"热带风暴",
			"狂风暴雨",
			"电闪雷鸣",
			"电闪雷鸣",
			"雨雪霏霏",
			"雨雪霏霏",
			"雨雪纷纷",
			"寒风冷雨",
			"蒙蒙细雨",
			"凄风冷雨",
			"疾风骤雨",
			"疾风骤雨",
			"俄而雪骤",
			"流风回雪",
			"狂风暴雪",
			"大雪纷飞",
			"天降冰雹",
			"雨雪霏霏",
			"飞沙走石",
			"云迷雾锁",
			"十面霾伏",
			"烟雾弥漫",
			"风起云涌",
			"风和日丽",
			"天寒地冻",
			"乌云蔽日",
			"浮云蔽日",
			"浮云蔽日",
			"云淡风轻",
			"云淡风轻",
			"晴空万里",
			"阳光明媚",
			"天朗气清",
			"天朗气清",
			"冰雹带雨",
			"骄阳似火",
			"霹雳列缺",
			"电闪雷鸣",
			"电闪雷鸣",
			"急风骤雨",
			"大雪纷飞",
			"骤雪初歇",
			"大雪纷飞",
			"云淡风轻",
			"雷阵雨",
			"雨雪霏霏",
			"霹雳列缺",
			"自行判断"];
		var cardinal = ["北", "北", "东北", "东", "东", "东", "东南", "南", "南", "南", "南", "西", "西", "西", "西北", "北"];

	break;	   

	case "fr":
		var days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
		var months = ["Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Aout", "Septembre", "Octobre", "Novembre", "Decembre"];
		var hightext = "Max: ";
		var lowtext = "Min: ";
		var sunrisetext = "Lever";
		var sunsettext = "Coucher";
		var feelsliketext = "Ressentie: ";
		var lastupdatetext = "Mise à jour: ";
		var humiditytext = "Humidité: ";	
		var visibilitytext = "Visibilité: ";	
		var pressuretext = "Pression: ";
		var windtext = "Vent: ";
		var nowindtext = "Pas de vent";
		var batterytxt = "Batterie: ";
		var moontext = "Lune: ";
		var WeatherDesc = [
			"Tornade",
			"Orage tropical",
			"Ouragan",
			"Orages violents",
			"Orages",
			"Pluie et neige mélées",
			"Pluie et grêle mélées",
			"Neige et grêle mélées",
			"Bruine verglaçante",
			"Bruine",
			"Pluie verglaçante",
			"Averses",
			"Pluie",
			"Quelques flocons",
			"Faibles chutes de neige",
			"Rafales de neige",
			"Neige",
			"Grêle",
			"Neige fondue",
			"Poussiéreux",
			"Brouillard",
			"Brume",
			"Brumeux",
			"Tempête",
			"Vent",
			"Temps froid",
			"Temps nuageux ",
			"Très nuageux",
			"Très nuageux",
			"Partiellement nuageux",
			"Partiellement nuageux",
			"Ciel dégagé",
			"Ensoleillé",
			"Beau temps",
			"Beau temps",
			"Pluie et grêles mélées",
			"Temps chaud",
			"Orages isolés",
			"Orages éparses",
			"Orages éparses",
			"Averses éparses",
			"Fortes chutes de neige",
			"Chutes de neige éparses",
			"Fortes chutes de neige",
			"Partiellement nuageux",
			"Orages",
			"Chute de neige",
			"Orages isolés",
			"Non disponible"];
		var cardinal = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSO", "SO", "OSO", "O", "ONO", "NO", "NNO"];
    break;
	
	case "cr": 
        var days = ["Nedjelja", "Ponedjeljak", "Utorak", "Srijeda", "Četvrtak", "Petak", "Subota"];
        var months = ["Siječanj", "Veljača", "Ožujak", "Travanj", "Svibanj", "Lipanj", "Srpanj", "Kolovoz", "Rujan", "Listopad", "Studeni", "Prosinac"];
        var hightext = "V: ";
		var batterytxt = "Baterija: ";
        var lowtext = "N: ";
        var sunrisetext ="Svitanje";
        var sunsettext = "Sumrak";
        var feelsliketext = "Čini se kao: ";
        var lastupdatetext = "Ažurirano: ";
        var humiditytext = "Vlažnost: ";
        var visibilitytext = "Vidljivost: ";
        var pressuretext = "Tlak: ";
        var windtext = "Vjetar: ";
        var nowindtext = "Bez vjetra";
		var moontext = "Mjesec: ";
		var preciptext = "Mog.Oborine: ";
		var WeatherDesc = [
            "Tornado",
            "Tropska Oluja",
            "Uragan",
            "Teške oluje s grmljavinom",
            "Grmljavinska Oluja",
            "Kiša i Snijeg",
            "Kiša i Susnježica",
            "Snijeg i Susnježica",
            "Smrznuta Rominjanje",
            "Rominjanje",
            "Smrznuta Kiša",
            "Kiša",
            "Kiša",
            "Snježni naleti",
            "Lagani Naleti Snijega",
            "Snježna mećava",
            "Snijeg",
            "Tuća",
            "Susnježica",
            "Prašina",
            "Magla",
            "Sumaglica",
            "Dimljivo",
            "Jak Vjetar",
            "Vjetrovito",
            "Hladno",
            "Oblačno",
            "Većinom oblačno",
            "Većinom oblačno",
            "Djelomična naoblaka",
            "Djelomična naoblaka",
            "Vedro",
            "Sunčano",
            "Vedro",
            "Vedro",
            "Mješovita kiša i grad",
            "Vruće",
            "Izolirana Grmljavinska Oluja",
            "Slaba oluja s grmljavinom",
            "Slaba oluja s grmljavinom",
            "Mjestimični pljuskovi",
            "Jaki Snijeg",
            "Slaba kiša snijega",
            "Jaki Snijeg",
            "Djelomična naoblaka",
            "Grmljavinska Oluja",
            "Kiša Snijega",
            "Izolirana Grmljavinska Oluja",
            "Nije Dostupno"];
		var cardinal = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
    break; 
	
	default: 
		var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
		var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
		var hightext = "H: ";  
		var lowtext = "L: ";
		var batterytxt = "Battery: ";
		var sunrisetext ="Sunrise";
		var sunsettext = "Sunset";
		var feelsliketext = "Feels like: ";
		var lastupdatetext = "Updated: ";
		var humiditytext = "Humidity: ";
		var visibilitytext = "Visibility: ";
		var pressuretext = "Pres: ";
		var windtext = "Wind: ";
		var nowindtext = "No wind";
		var moontext = "Moon: ";
		var WeatherDesc = [
			"Tornado",
			"Tropical Storm",
			"Hurricane",
			"Severe Thunderstorms",
			"Thunderstorms",
			"Mixed Rain and Snow",
			"Mixed Rain and Sleet",
			"Mixed Snow and Sleet",
			"Freezing Drizzle",
			"Drizzle",
			"Freezing Rain",
			"Showers",
			"Showers",
			"Snow Flurries",
			"Light Snow Showers",
			"Blowing Snow",
			"Snow",
			"Hail",
			"Sleet",
			"Dust",
			"Foggy",
			"Haze",
			"Smoky",
			"Blustery",
			"Windy",
			"Cold",
			"Cloudy ",
			"Mostly Cloudy",
			"Mostly Cloudy",
			"Partly Cloudy",
			"Partly Cloudy",
			"Clear",
			"Sunny",
			"Fair",
			"Fair",
			"Mixed Rain and Hail",
			"Hot",
			"Isolated Thunderstorms",
			"Scattered Thunderstorms",
			"Scattered Thunderstorms",
			"Scattered Showers",
			"Heavy Snow",
			"Scattered Snow Showers",
			"Heavy Snow",
			"Partly Cloudy",
			"Thundershowers",
			"Snow Showers",
			"Isolated Thundershowers",
			"Not Available"];
		var cardinal = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
	break;
     
}

// Moon phase description not translated

var MoonDesc = [
	"No Moon",
	"New Moon",
	"Wax.Cresc.",
	"Wax.Cresc.",
	"Wax.Cresc.",
	"Wax.Cresc.",
	"Wax.Cresc.",
	"First Qtr.",
	"Wax.Gibb.",
	"Wax.Gibb.",
	"Wax.Gibb.",
	"Wax.Gibb.",
	"Wax.Gibb.",
	"Wax.Gibb.",
	"Full Moon",	
	"Wan.Gibb.",
	"Wan.Gibb.",
	"Wan.Gibb.",
	"Wan.Gibb.",
	"Wan.Gibb.",
	"Wan.Gibb.",
	"Last Qtr.",
	"Wan.Cresc.",
	"Wan.Cresc.",
	"Wan.Cresc.",
	"Wan.Cresc.",
	"Wan.Cresc.",
	"Wan.Cresc."
];

var Lunacy = ["New","Wax.Cresc."," First Qtr.","Wax.Gibb.","Full","Wan.Gibb.","Third Qtr.","Wan.Cresc."];

function ForecastDayNames(day) {
switch (day) {
    case "Sun": { return days[0]; }
    case "Mon": { return days[1]; }
    case "Tue": { return days[2]; }
    case "Wed": { return days[3]; }
    case "Thu": { return days[4]; }
    case "Fri": { return days[5]; }
    case "Sat": { return days[6]; }
    case "Today": { return "Today"; }
    case "Tonight": { return "Tonight"; }
	}
}
function timeToDayName(time) {
     
      var today = new Date();
      var tomorrow = new Date(today.getTime() + (24 * 60 * 60 * 1000));
      if (time == today.getDay()) {
            return "Today";
      } else if (time == tomorrow.getDay()) {
            return "Tomorrow";
      }
      switch(time) {
          case 0:
            return "Sunday";
          case 1:
            return "Monday";
          case 2:
            return "Tuesday";
          case 3:
            return "Wednesday";
          case 4:
            return "Thursday";
          case 5:
            return "Friday";
          case 6:
            return "Saturday";
          default:
            return "";
        } 
  }

function translateCardinal() {
	switch (lang) {
		case "no":
			switch (obj.cardinal) { 					
				case 'N': { return "N"; } //NORD
				case 'NNW': { return "NNV"; }		
				case 'NW': { return "NV"; } //NORDVEST	
				case 'WNW': { return "VNV"; }
				case 'W': { return "V"; } //VEST	
				case 'WSW': { return "VSV"; }		
				case 'SW': { return "SV"; } //SØRVEST
				case 'SSW': { return "SSV";	}	
				case 'S': { return "S"; } //SØR	
				case 'SSE': { return "SSØ"; }
				case 'SE': { return "SØ"; } //SØRØST		
				case 'ESE': { return "ØSØ"; }		
				case 'E': { return "Ø"; } //ØST	
				case 'ENE': { return "ØNØ"; }		
				case 'NE': { return "NØ"; } //NORDØST
				case 'NNE': { return "NNØ"; }		
				break;
			}
		break;
		
		case "ge": 					
			switch (obj.cardinal) { 					
				case 'N': { return "N"; } //NORDEN
				case 'NNW': { return "NNW"; }		
				case 'NW': { return "NW"; } //NORDENWEST	
				case 'WNW': { return "WNW"; }
				case 'W': { return "W"; } //WEST	
				case 'WSW': { return "WSW"; }		
				case 'SW': { return "SW"; } //SÜDWEST
				case 'SSW': { return "SSW";	}	
				case 'S': { return "S"; } //SÜD	
				case 'SSE': { return "SSO"; }
				case 'SE': { return "SO"; } //SÜDOSTEN		
				case 'ESE': { return "OSO"; }		
				case 'E': { return "O"; } //OSTEN	
				case 'ENE': { return "ONO"; }		
				case 'NE': { return "NO"; } //NORDENOSTEN
				case 'NNE': { return "NNO"; }		
				break;
			}
		break;
				
		case "it":
			switch (obj.cardinal) { 					
				case 'N': { return "N"; } //NORD
				case 'NNW': { return "NNO"; }		
				case 'NW': { return "NO"; } //NORDOVEST	
				case 'WNW': { return "ONO"; }
				case 'W': { return "O"; } //OVEST	
				case 'WSW': { return "OSO"; }		
				case 'SW': { return "SO"; } //SUDOVEST
				case 'SSW': { return "SSO";	}	
				case 'S': { return "S"; } //SUD	
				case 'SSE': { return "SSE"; }
				case 'SE': { return "SE"; } //SUDEST		
				case 'ESE': { return "ESE"; }		
				case 'E': { return "E"; } //EST	
				case 'ENE': { return "ENE"; }		
				case 'NE': { return "NE"; } //NORDEST
				case 'NNE': { return "NNE"; }		
				break;
			}
		break;
		
		case "fi":
			switch (obj.cardinal) { 					
				case 'N': { return "Pohjoinen"; } //POHJOINEN
				case 'NNW': { return "Pohjoinen"; }		
				case 'NW': { return "Koillinen"; } //KOILLINEN
				case 'WNW': { return "Itä"; }
				case 'W': { return "Itä"; } //ITÄ	
				case 'WSW': { return "Itä"; } 	
				case 'SW': { return "Kaakko"; } //KAAKKO
				case 'SSW': { return "Etelä"; }	
				case 'S': { return "Etelä"; } //ETELÄ	
				case 'SSE': { return "Etelä"; }
				case 'SE': { return "Lounas"; } //LOUNAS		
				case 'ESE': { return "Länsi"; }		
				case 'E': { return "Länsi"; } //LÄNSI	
				case 'ENE': { return "Länsi"; }		
				case 'NE': { return "Luode"; } //LUODE
				case 'NNE': { return "Pohjoinen"; }			
				break;
			}
		break;
		
		case "nl":	
			switch (obj.cardinal) { 					
				case 'N': { return "N"; } //NOORDEN
				case 'NNW': { return "NNW"; }		
				case 'NW': { return "NW"; } //NOORDENWEST	
				case 'WNW': { return "WNW"; }
				case 'W': { return "W"; } //WEST	
				case 'WSW': { return "WZW"; }		
				case 'SW': { return "ZW"; } //ZUIDENWEST
				case 'SSW': { return "ZZW";	}	
				case 'S': { return "Z"; } //ZUIDEN	
				case 'SSE': { return "ZZO"; }
				case 'SE': { return "ZO"; } //ZUIDENOOSTEN		
				case 'ESE': { return "OZO"; }		
				case 'E': { return "O"; } //OOSTEN	
				case 'ENE': { return "ONO"; }		
				case 'NE': { return "NO"; } //NOORDENOOSTEN
				case 'NNE': { return "NNO"; }		
				break;
			}	
		break;
		
		case "fr":
			switch (obj.cardinal) { 					
				case 'N': { return "N"; } //NORD
				case 'NNW': { return "NNO"; }		
				case 'NW': { return "NO"; } //NORDOUEST	
				case 'WNW': { return "ONO"; }
				case 'W': { return "O"; } //OUEST	
				case 'WSW': { return "OSO"; }		
				case 'SW': { return "SO"; } //SUDOUEST
				case 'SSW': { return "SSO";	}	
				case 'S': { return "S"; } //SUD	
				case 'SSE': { return "SSE"; }
				case 'SE': { return "SE"; } //SUDEST		
				case 'ESE': { return "ESE"; }		
				case 'E': { return "E"; } //EST	
				case 'ENE': { return "ENE"; }		
				case 'NE': { return "NE"; } //NORDEST
				case 'NNE': { return "NNE"; }		
				break;
			}
		break;
		
		case "sp":	
			switch (obj.cardinal) { 					
				case 'N': { return "N"; } //NORTE
				case 'NNW': { return "NNO"; }		
				case 'NW': { return "NO"; } //NORTEOESTE
				case 'WNW': { return "ONO"; }
				case 'W': { return "O"; } //OESTE	
				case 'WSW': { return "OSO"; }		
				case 'SW': { return "SO"; } //SUROESTE
				case 'SSW': { return "SSO";	}	
				case 'S': { return "S"; } //SUR	
				case 'SSE': { return "SSE"; }
				case 'SE': { return "SE"; } //SURESTE		
				case 'ESE': { return "ESE"; }		
				case 'E': { return "E"; } //ESTE	
				case 'ENE': { return "ENE"; }		
				case 'NE': { return "NE"; } //NORTESTE
				case 'NNE': { return "NNE"; }		
				break;
			}
		break;
		
		case "ru": 
		    switch (obj.cardinal) {					
				case 'N': { return "С"; }
				case 'NNW': { return "ССЗ"; }		
				case 'NW': { return "СЗ"; }		
				case 'WNW': { return "ЗСЗ"; }
				case 'W': { return "З"; }		
				case 'WSW': { return "ЗЮЗ"; }		
				case 'SW': { return "ЗЮ"; }
				case 'SSW': { return "ЗЗЮ"; }		
				case 'S': { return "Ю"; }		
				case 'SSE': { return "ЮЮВ"; }
				case 'SE': { return "ЮВ"; }		
				case 'ESE': { return "ВЮВ"; }		
				case 'E': { return "В"; }		
				case 'ENE': { return "ВСВ"; }		
				case 'NE': { return "СВ"; }
				case 'NNE': { return "ССВ"; }		
				break;
			}
		break;
		
		case "gr": 					
			switch (obj.cardinal) {					
				case 'N': { return "Β"; }
				case 'NNW': { return "ΒΒΔ"; }		
				case 'NW': { return "ΒΔ"; }		
				case 'WNW': { return "ΔΒΔ"; }
				case 'W': { return "Δ"; }		
				case 'WSW': { return "ΔΝΔ"; }		
				case 'SW': { return "ΝΔ"; }
				case 'SSW': { return "ΝΝΔ"; }		
				case 'S': { return "Ν"; }		
				case 'SSE': { return "ΝΝΑ"; }
				case 'SE': { return "ΝΑ"; }		
				case 'ESE': { return "ΑΝΑ"; }		
				case 'E': { return "Α"; }		
				case 'ENE': { return "ΑΒΑ"; }		
				case 'NE': { return "ΒΑ"; }
				case 'NNE': { return "ΒΒΑ"; }		
				break;
			}
		break;
		case "tr":
			switch (obj.cardinal) { 					
				case 'N': { return "K"; } //NORTH
				case 'NNW': { return "KKB"; }		
				case 'NW': { return "KB"; } //NORTHWEST	
				case 'WNW': { return "BKB"; }
				case 'W': { return "B"; } //WEST	
				case 'WSW': { return "BGB"; }		
				case 'SW': { return "GB"; } //SOUTHWEST
				case 'SSW': { return "GGB";	}	
				case 'S': { return "G"; } //SOUTH	
				case 'SSE': { return "GGD"; }
				case 'SE': { return "GD"; } //SOUTHEAST		
				case 'ESE': { return "DGD"; }		
				case 'E': { return "D"; } //EAST	
				case 'ENE': { return "DKD"; }		
				case 'NE': { return "KD"; } //NORTHEAST
				case 'NNE': { return "KKD"; }		
				break;
			}
		break;
		
		case "cn":
			switch (obj.cardinal) { 					
				case 'N': { return "北"; }
				case 'NNW': { return "北"; }		
				case 'NW': { return "西北"; }	
				case 'WNW': { return "西"; }
				case 'W': { return "西"; }	
				case 'WSW': { return "西"; }		
				case 'SW': { return "西南"; }
				case 'SSW': { return "南";	}	
				case 'S': { return "南"; }	
				case 'SSE': { return "南"; }
				case 'SE': { return "东南"; }		
				case 'ESE': { return "东"; }		
				case 'E': { return "东"; }	
				case 'ENE': { return "东"; }		
				case 'NE': { return "东北"; }
				case 'NNE': { return "北"; }		
				break;
			}
		break;

		default:
			switch (obj.cardinal) { 					
				case 'N': { return "N"; } //NORTH
				case 'NNW': { return "NNW"; }		
				case 'NW': { return "NW"; } //NORTHWEST	
				case 'WNW': { return "WNW"; }
				case 'W': { return "W"; } //WEST	
				case 'WSW': { return "WSW"; }		
				case 'SW': { return "SW"; } //SOUTHWEST
				case 'SSW': { return "SSW";	}	
				case 'S': { return "S"; } //SOUTH	
				case 'SSE': { return "SSE"; }
				case 'SE': { return "SE"; } //SOUTHEAST		
				case 'ESE': { return "ESE"; }		
				case 'E': { return "E"; } //EAST	
				case 'ENE': { return "ENE"; }		
				case 'NE': { return "NE"; } //NORTHEAST
				case 'NNE': { return "NNE"; }		
				break;
			}
		break;
	}
}

function Suffix(tmpDate) {
	switch (tmpDate) {
		case 1:
		case 21:
		case 31:
			return tmpDate + "st";
		break;
		case 2: 
		case 22:
			return tmpDate + "nd";
		break;
		case 3:
		case 23:
			return tmpDate + "rd";
		break;
		default:
			return tmpDate + "th";
		break;
	}
}