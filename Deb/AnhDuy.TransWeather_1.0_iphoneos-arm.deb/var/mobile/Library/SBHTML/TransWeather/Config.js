var lang = "vi"; // Chọn ngôn ngữ: vi  việt nam, no  Norweigan, it  Italian, fi  Finnish, nl  Dutch, fr  French, ge  German, sp  Spanish, cn  Chinese, ru  Russian, en  English, tr  Turkish, gr  Greek, cr  Croatian
var twentyfourh = false; // Đồng hồ đã ẩn
var pad = false; // Đồng hồ đã ẩn
var textcolor = "#929394"; // Màu chữ : #cb4040 red ; #40cacb Cyan ; #ffbb00 Berry  ; #8adc92 Green ;  #3071bb Blue ; #239EE1   Bluray
var IconSet = "8"; // Chọn gói biểu tượng từ 1 đến 8, Ví dụ chọn gói số 5 thì nhập vào bên trên số là ok.
