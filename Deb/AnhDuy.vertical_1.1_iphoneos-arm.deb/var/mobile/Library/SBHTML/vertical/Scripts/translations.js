// Translation file based on uniaw 6.3, with credit to Dacal, NewD & wrussell1989 


// TRANSLATION FOR MAIN ELEMENTS

switch (lang) {
	
	case "vi": 
		var days = ["chủ nhật","Thứ hai","Thứ ba","Thứ tư","Thứ năm","Thứ sáu","Thứ bảy"];
		var months =["tháng 01","tháng 02","tháng 03","tháng 04","tháng 05","tháng 06","tháng 07","tháng 08","tháng 09","tháng 10","tháng 11","tháng 12"];
		var hightext = "H: ";  
		var lowtext = "L: ";
		var batterytxt = "pin: ";
		var sunrisetext ="bình Minh";
		var sunsettext = "Hoàng hôn";
		var feelsliketext = "Cảm thấy như: ";
		var lastupdatetext = "Đã cập nhật: ";
		var humiditytext = "Độ ẩm: ";
		var visibilitytext = "Hiển thị: ";
		var pressuretext = "Pres: ";
		var windtext = "Gió: ";
		var nowindtext = "Không có gió";
		var moontext = "Mặt trăng: ";
		var WeatherDesc = ["Có bão", "Bão nhiệt đới", "Có bão", "Có dông", "Có dông", "Có tuyết", "Mưa đá", "Mưa đá", "Mưa phùn lạnh", "Mưa phùn", "Mưa lạnh", "Mưa rào", "Có mưa", "Có bão", "Mưa tuyết", "Có tuyết", "Có tuyết", "Mưa đá", "Mưa tuyết", "Gió bụi", "Sương mù dày", "Sương mù nhẹ", "Sương mù", "Gió mạnh", "Có gió", "Trời lạnh", "Có mây vài nơi", "Trời nhiều mây", "Trời nhiều mây", "Có mây vài nơi", "Có mây vài nơi", "Quang mây", "Có nắng", "Trời quang mây", "Trời nắng", "Mưa đá", "Trời nóng", "Có sấm sét", "giông bão rải rác", "Có sấm sét", "Mưa lớn", "Có tuyết", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Ít mây", "Có dông", "Có tuyết", "Có dông", "blank"];
		var cardinal = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
	break;

	case "en": 
		var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
		var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
		var hightext = "H: ";  
		var lowtext = "L: ";
		var batterytxt = "Battery: ";
		var sunrisetext ="Sunrise";
		var sunsettext = "Sunset";
		var feelsliketext = "Feels like: ";
		var lastupdatetext = "Updated: ";
		var humiditytext = "Humidity: ";
		var visibilitytext = "Visibility: ";
		var pressuretext = "Pres: ";
		var windtext = "Wind: ";
		var nowindtext = "No wind";
		var moontext = "Moon: ";
		var WeatherDesc = [
			"Tornado",
			"Tropical Storm",
			"Hurricane",
			"Severe Thunderstorms",
			"Thunderstorms",
			"Mixed Rain and Snow",
			"Mixed Rain and Sleet",
			"Mixed Snow and Sleet",
			"Freezing Drizzle",
			"Drizzle",
			"Freezing Rain",
			"Showers",
			"Showers",
			"Snow Flurries",
			"Light Snow Showers",
			"Blowing Snow",
			"Snow",
			"Hail",
			"Sleet",
			"Dust",
			"Foggy",
			"Haze",
			"Smoky",
			"Blustery",
			"Windy",
			"Cold",
			"Cloudy ",
			"Mostly Cloudy",
			"Mostly Cloudy",
			"Partly Cloudy",
			"Partly Cloudy",
			"Clear",
			"Sunny",
			"Fair",
			"Fair",
			"Mixed Rain and Hail",
			"Hot",
			"Isolated Thunderstorms",
			"Scattered Thunderstorms",
			"Scattered Thunderstorms",
			"Scattered Showers",
			"Heavy Snow",
			"Scattered Snow Showers",
			"Heavy Snow",
			"Partly Cloudy",
			"Thundershowers",
			"Snow Showers",
			"Isolated Thundershowers",
			"Not Available"];
		var cardinal = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
	break;
     
}

// Moon phase description not translated

var MoonDesc = [
	"No Moon",
	"New Moon",
	"Wax.Cresc.",
	"Wax.Cresc.",
	"Wax.Cresc.",
	"Wax.Cresc.",
	"Wax.Cresc.",
	"First Qtr.",
	"Wax.Gibb.",
	"Wax.Gibb.",
	"Wax.Gibb.",
	"Wax.Gibb.",
	"Wax.Gibb.",
	"Wax.Gibb.",
	"Full Moon",	
	"Wan.Gibb.",
	"Wan.Gibb.",
	"Wan.Gibb.",
	"Wan.Gibb.",
	"Wan.Gibb.",
	"Wan.Gibb.",
	"Last Qtr.",
	"Wan.Cresc.",
	"Wan.Cresc.",
	"Wan.Cresc.",
	"Wan.Cresc.",
	"Wan.Cresc.",
	"Wan.Cresc."
];

var Lunacy = ["New","Wax.Cresc."," First Qtr.","Wax.Gibb.","Full","Wan.Gibb.","Third Qtr.","Wan.Cresc."];

function ForecastDayNames(day) {
switch (day) {
    case "Sun": { return days[0]; }
    case "Mon": { return days[1]; }
    case "Tue": { return days[2]; }
    case "Wed": { return days[3]; }
    case "Thu": { return days[4]; }
    case "Fri": { return days[5]; }
    case "Sat": { return days[6]; }
    case "Today": { return "Today"; }
    case "Tonight": { return "Tonight"; }
	}
}
function timeToDayName(time) {
     
      var today = new Date();
      var tomorrow = new Date(today.getTime() + (24 * 60 * 60 * 1000));
      if (time == today.getDay()) {
            return "Today";
      } else if (time == tomorrow.getDay()) {
            return "Tomorrow";
      }
      switch(time) {
          case 0:
            return "Sunday";
          case 1:
            return "Monday";
          case 2:
            return "Tuesday";
          case 3:
            return "Wednesday";
          case 4:
            return "Thursday";
          case 5:
            return "Friday";
          case 6:
            return "Saturday";
          default:
            return "";
        } 
  }

function translateCardinal() {
	switch (lang) {
		
		
		  case "vi":
			switch (obj.cardinal) { 					
				case 'N': { return "N"; } //NORTH
				case 'NNW': { return "NNW"; }		
				case 'NW': { return "NW"; } //NORTHWEST	
				case 'WNW': { return "WNW"; }
				case 'W': { return "W"; } //WEST	
				case 'WSW': { return "WSW"; }		
				case 'SW': { return "SW"; } //SOUTHWEST
				case 'SSW': { return "SSW";	}	
				case 'S': { return "S"; } //SOUTH	
				case 'SSE': { return "SSE"; }
				case 'SE': { return "SE"; } //SOUTHEAST		
				case 'ESE': { return "ESE"; }		
				case 'E': { return "E"; } //EAST	
				case 'ENE': { return "ENE"; }		
				case 'NE': { return "NE"; } //NORTHEAST
				case 'NNE': { return "NNE"; }		
				break;
			}
		break;


        case "en":
			switch (obj.cardinal) { 					
				case 'N': { return "N"; } //NORTH
				case 'NNW': { return "NNW"; }		
				case 'NW': { return "NW"; } //NORTHWEST	
				case 'WNW': { return "WNW"; }
				case 'W': { return "W"; } //WEST	
				case 'WSW': { return "WSW"; }		
				case 'SW': { return "SW"; } //SOUTHWEST
				case 'SSW': { return "SSW";	}	
				case 'S': { return "S"; } //SOUTH	
				case 'SSE': { return "SSE"; }
				case 'SE': { return "SE"; } //SOUTHEAST		
				case 'ESE': { return "ESE"; }		
				case 'E': { return "E"; } //EAST	
				case 'ENE': { return "ENE"; }		
				case 'NE': { return "NE"; } //NORTHEAST
				case 'NNE': { return "NNE"; }		
				break;
			}
		break;
	}
}

function Suffix(tmpDate) {
	switch (tmpDate) {
		case 1:
		case 21:
		case 31:
			return tmpDate + "st";
		break;
		case 2: 
		case 22:
			return tmpDate + "nd";
		break;
		case 3:
		case 23:
			return tmpDate + "rd";
		break;
		default:
			return tmpDate + "th";
		break;
	}
}