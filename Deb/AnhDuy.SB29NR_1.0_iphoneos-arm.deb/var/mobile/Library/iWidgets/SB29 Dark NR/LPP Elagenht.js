/* Created by LockPlus Pro by JunesiPhone http://twitter.com/junesiphone This is for personal use only. You cannot sell this widget. If you want to sell a widget code your own. */ var savedElements = {"placedElements":{"boxOne":{"width":"75px","height":"35px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"49px","left":"20px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"18px","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 4px rgb(0, 0, 0, 0.5), inset -2px -2px 4px rgb(255, 255, 255, 0.05)"},


"boxTwo":{"width":"122px","height":"90px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"120px","left":"22px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"20px","box-shadow":"10px 10px 20px rgb(0, 0, 0, 0.4), -20px -20px 60px rgb(64, 66, 76, 0.3), inset 5px 5px 8px #333333, inset -4px -4px 8px rgb(32, 33, 36)","background":"linear-gradient(to bottom left, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxThree":{"width":"122px","height":"90px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":120,"left":175,"font-family":"helvetica","font-size":"30px","color":"white","border-radius":"20px","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"10px 10px 20px rgb(0, 0, 0, 0.4), -20px -20px 60px rgb(64, 66, 76, 0.3), inset 6px 6px 8px rgb(64, 66, 76, 0.3), inset -4px -4px 8px rgb(32, 33, 36)"},


"boxFour":{"width":"38px","height":"38px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"460px","left":"212px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"12px","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"2px 2px 4px rgb(0, 0, 0, 0.4), -2px -2px 4px rgb(44, 45, 48)"},


"boxFive":{"width":"38px","height":"38px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"460px","left":"259px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"12px","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"2px 2px 4px rgb(0, 0, 0, 0.4), -2px -2px 4px rgb(44, 45, 48)"},


"boxEight":{"width":"87px","height":"40px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":278,"left":210,"font-family":"helvetica","font-size":"30px","color":"white","border-radius":"17px","box-shadow":"10px 10px 20px rgb(0, 0, 0, 0.4), -10px -10px 16px rgb(44, 45, 48)","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxNine":{"width":"87px","height":"40px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"358px","left":"210px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"17px","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"10px 10px 20px rgb(0, 0, 0, 0.4), -10px -10px 16px rgb(44, 45, 48)"},


"boxTen":{"width":"132px","height":"38px","background-color":"transparent","z-index":"2","border-color":"rgb(38, 39, 42)","border-style":"solid","border-width":"2px","position":"absolute","top":"541px","left":"167px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"16px","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 4px rgb(0, 0, 0, 0.4), inset -2px -2px 4px rgb(255, 255, 255, 0.05)"},



"boxSix":{"width":"320px","height":"690px","background-color":"transparent","z-index":1,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":0,"left":0,"font-family":"helvetica","font-size":"30px","color":"rgba(255, 255, 255, 0)","background":"linear-gradient(to bottom, rgb(38, 39, 42) 0%, rgb(38, 39, 42) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxCircleOne":{"width":"37px","height":"37px","background-color":"transparent","z-index":2,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"545px","left":"20px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"5px 5px 9px rgb(0, 0, 0, 0.4), -5px -5px 4px rgb(44, 45, 48)","background":"linear-gradient(to bottom, #333333 0%, #333333 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxCircleTwo":{"width":"27px","height":"27px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"550px","left":"25px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 2px 2px 4px rgb(0, 0, 0, 0.4), inset -2px -2px 4px rgb(255, 255, 255, 0.08)","background":"linear-gradient(to bottom, rgb(38, 39, 42) 0%, rgb(38, 39, 42) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"textOne":{"position":"absolute","z-index":"2","top":"56px","left":"142px","font-family":"HelveticaNeue","font-weight":"bold", "font-size":"17px","color":"#AA0F0F","text-align":"center","innerHTML":"Hello Anh Duy","text-transform":"uppercase","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},


"boxCircleThree":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"562px","left":"86px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #C69E6B 0%, #C69E6B 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxCircleFour":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"560px","left":"99px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #AA0F0F 0%, #AA0F0F 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxCircleFive":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"564px","left":"112px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #C69E6B 0%, #C69E6B 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxCircleSix":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"562px","left":"126px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #AA0F0F 0%, #AA0F0F 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"textTwo":{"position":"absolute","z-index":"2","top":"554px","left":"30px","font-family":"BIGJOHN","font-size":"19px","color":"#AA0F0F","innerHTML":"G","height":"24px","width":"25px","text-shadow":"1px 1px 1px rgba(0, 0, 0, 0.9)"},


"boxSeven":{"width":"28px","height":"28px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"364px","left":"260px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"30px","background":"linear-gradient(to left, rgb(38, 39, 42) 0%, rgb(38, 39, 42) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 3px rgb(14, 14, 14, 0.5), inset -2px -2px 3px rgb(255, 255, 255, 0.07)","is-battery":"false"},


"boxEleven":{"width":"2px","height":"32px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"283px","left":"253px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 1px 1px 2px rgb(14, 14, 14, 0.8), inset -1px -1px 1px 2px rgb(44, 45, 48)","background":"linear-gradient(to bottom, rgb(38, 39, 42) 0%, rgb(38, 39, 42) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"tempdeg":{"position":"absolute","z-index":"2","top":"288px","left":"222px","font-family":"HelveticaNeue","font-size":"16px","color":"#C69E6B","font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},


"boxCircleSeven":{"width":"22px","height":"22px","background-color":"transparent","z-index":"2","border-color":"rgb(38, 39, 42)","border-style":"solid","border-width":"2px","position":"absolute","top":"133px","left":"190px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 2px 2px 4px rgb(0, 0, 0, 0.35), inset -2px -2px 4px rgb(255, 255, 255, 0.08), 2px 2px 4px rgb(0, 0, 0, 0.35), -3px -3px 7px rgb(44, 45, 48)","background":"linear-gradient(to bottom, rgb(38, 39, 42) 0%, rgb(38, 39, 42) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxCircleEight":{"width":"22px","height":"22px","background-color":"transparent","z-index":"2","border-color":"rgb(38, 39, 42)","border-style":"solid","border-width":"2px","position":"absolute","top":"172px","left":"256px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, rgb(38, 39, 42) 0%, rgb(38, 39, 42) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 4px rgb(0, 0, 0, 0.36), inset -2px -2px 4px rgb(255, 255, 255, 0.08), 3px 3px 7px rgb(0, 0, 0, 0.4), -3px -3px 7px rgb(44, 45, 48)"},


"textThree":{"position":"absolute","z-index":"2","top":"178px","left":209,"font-family":"HelveticaNeue","font-size":"12px","color":"#AA0F0F","width":"47px","innerHTML":"WiFi","height":"19px","font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},


"textFour":{"position":"absolute","z-index":"2","top":"139px","left":"233px","font-family":"HelveticaNeue","font-size":"12px","color":"#C69E6B","innerHTML":"di động ","height":"20px","width":"39px","letter-spacing": "0px", "font-weight":"bold","text-transform":"capitalize", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)" },


"boxCircleNine":{"width":"20px","height":"20px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"129px","left":"31px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 2px 2px 4px rgb(0, 0, 0, 0.35), inset -2px -2px 4px rgb(255, 255, 255, 0.08)","background":"linear-gradient(to bottom, rgb(38, 39, 42) 0%, rgb(38, 39, 42) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"ft24_mat5F":{"font-family":"HelveticaNeue","position":"absolute","z-index":"2","top":"133px","left":"37px","font-size":"11px","color":"#C69E6B","background-color":"rgba(0, 0, 0, 0)"},

"zclock":{"position":"absolute","z-index":"2","top":"56px","left":"35px","font-family":"HelveticaNeue", "font-weight":"bold","font-size":"17px","color":"#C69E6B", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 3)"},


"datepad":{"position":"absolute","z-index":"2","top":"137px","left":"83px","font-family":"HelveticaNeue", "font-weight":"bold", "font-size":"35px","color":"#AA0F0F","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},


"sday":{"position":"absolute","z-index":"2","top":"180px","left":"37px","font-family":"HelveticaNeue",  "font-weight":"bold", "font-size":"14px","color":"#AA0F0F","letter-spacing": "0px","font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},


"smonth":{"position":"absolute","z-index":"2","top":"180px","left":"75.5px","font-family":"HelveticaNeue","font-size":"14px","color":"#C69E6B","letter-spacing": "0px",  "font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)" },


"ft4_mashup":{"position":"absolute","font-family":"HelveticaNeue","z-index":"2","top":"470px","font-weight":"bold","left":"226px","font-size":"15px","color":"#C69E6B", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},


"ft4_mat2F":{"position":"absolute","font-family":"HelveticaNeue","z-index":"2","top":"470px","font-weight":"bold","left":"272px","font-size":"16px","color":"#AA0F0F","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)" },


"textFive":{"position":"absolute","z-index":"2","top":"369px","left":"217px","font-family":"HelveticaNeue","font-size":"12px","color":"#C69E6B","width":"59px","innerHTML":"Mức pin","height":"25px","letter-spacing": "-0.6px", "font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)" },


"bundle133":{"name":"‎Zing MP3","bundleID":"vng.com.vn.zingmp3-lite","position":"absolute","z-index":"2","top":"467px","left":"266px","font-family":"HelveticaNeue","font-size":"5px","color":"rgba(180, 4, 4, 0)","width":"25px","height":"25px"},


"bundle113":{"name":"‎google Maps","bundleID":"com.google.Maps","position":"absolute","z-index":"2","top":"467px","left":"219px","font-family":"HelveticaNeue","font-size":"5px","color":"rgba(180, 4, 4, 0)","height":"25px","width":"25px"},


"bundle123":{"name":"Chrome","bundleID":"com.google.chrome.ios","position":"absolute","z-index":"2","top":"549px","left":"22px","font-family":"HelveticaNeue","font-size":"7px","color":"rgba(255, 255, 255, 0)","width":"32px","height":"32px"},


"textSix":{"position":"absolute","z-index":"2","top":"555px","left":"190px","font-family":"HelveticaNeue","font-size":"12px","color":"#C69E6B","innerHTML":"các ứng dụng","width":"83px","height":"27px","letter-spacing":"0px","font-weight":"bold","text-transform":"uppercase","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},


"wifi":{"position":"absolute","z-index":"2","top":"179px","left":"270px","font-family":"HelveticaNeue","font-size":"10px","color":"#AA0F0F","font-weight":"bold"},


"signal":{"position":"absolute","z-index":"2","top":"139.7px","left":"203.5px","font-family":"HelveticaNeue","font-size":"10px","color":"#C69E6B","height":"20px","font-weight":"bold"},

"ft35_mat5F":{"font-family":"mat5","position":"absolute","z-index":"2","top":"138px","left":"197px","font-weight":"bold","font-size":"14px","color":"#AA0F0F","width":"25px","height":"21px"},


"ft45_mat5F":{"font-family":"mat5","position":"absolute","z-index":"2","top":"175.4px","left":"263px","font-size":"14px","font-weight":"bold","color":"#C69E6B","width":"22px","height":"20px"},

"batterypie":{"position":"absolute","z-index":"2","top":"368px","left":"264px","font-family":"helvetica","font-size":"30px","color":"white","circle-width":"20px","circle-stroke-dasharray":"4px","circle-stroke-value":"13px","inner-color":"rgba(122, 122, 122, 0.33)","outer-color":"#AA0F0F"},


"coloricon":{"position":"absolute","z-index":"2","top":"286px","left":"264px","font-family":"helvetica","font-size":"24px","color":"#AA0F0F"}},


"iconName":"reddock"}