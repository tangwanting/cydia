/* Created by LockPlus Pro by JunesiPhone http://twitter.com/junesiphone This is for personal use only. You cannot sell this widget. If you want to sell a widget code your own. */ var savedElements = {"placedElements":{"boxOne":{"width":"75px","height":"35px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"47px","left":"20px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"18px","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 4px rgb(163, 177, 198), inset -2px -2px 4px rgb(255, 255, 255)"},


"boxTwo":{"width":"122px","height":"90px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":124,"left":22,"font-family":"helvetica","font-size":"30px","color":"white","border-radius":"20px","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"10px 10px 20px rgb(163, 177, 198), -10px -10px 20px rgb(255, 255, 255), inset 3px 3px 6px rgb(255, 255, 255), inset -3px -3px 6px rgb(163, 177, 198)"},



"boxThree":{"width":"122px","height":"90px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":124,"left":175,"font-family":"helvetica","font-size":"30px","color":"white","border-radius":"20px","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"10px 10px 20px rgb(163, 177, 198), -10px -10px 20px rgb(255, 255, 255), inset 3px 3px 6px rgb(255, 255, 255), inset -3px -3px 6px rgb(163, 177, 198)"},


"boxFour":{"width":"38px","height":"38px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"460px","left":"212px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"12px","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"2px 2px 4px rgb(163, 177, 198), -2px -2px 4px rgb(255, 255, 255)"},


"boxFive":{"width":"38px","height":"38px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"460px","left":"259px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"12px","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"2px 2px 4px rgb(163, 177, 198), -2px -2px 4px rgb(255, 255, 255)"},


"boxEight":{"width":"87px","height":"40px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":282,"left":210,"font-family":"helvetica","font-size":"30px","color":"white","border-radius":"17px","box-shadow":"10px 10px 20px rgb(163, 177, 198), -10px -10px 20px rgb(255, 255, 255)","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},



"boxNine":{"width":"87px","height":"40px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"354px","left":"210px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"17px","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"10px 10px 20px rgb(163, 177, 198), -10px -10px 20px rgb(255, 255, 255)"},


"boxTen":{"width":"132px","height":"38px","background-color":"transparent","z-index":"2","border-color":"rgb(224, 230, 236)","border-style":"solid","border-width":"2px","position":"absolute","top":"531px","left":"167px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"16px","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 4px rgb(163, 177, 198), inset -2px -2px 4px rgb(255, 255, 255)"},



"boxSix":{"width":"340px","height":"690px","background-color":"transparent","z-index":1,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"0px","left":"0px","font-family":"helvetica","font-size":"40px","color":"rgba(0, 0, 0, 0.58)","background":"linear-gradient(to bottom, rgb(224, 230, 236) 0%, rgb(224, 230, 236) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxCircleOne":{"width":"37px","height":"37px","background-color":"transparent","z-index":2,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"535px","left":"20px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"5px 5px 9px rgb(163, 177, 198), -5px -5px 4px rgb(255, 255, 255)","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxCircleTwo":{"width":"27px","height":"27px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"540px","left":"25px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 2px 2px 4px rgb(163, 177, 198), inset -2px -2px 4px rgb(255, 255, 255)","background":"linear-gradient(to bottom, rgb(224, 230, 236) 0%, rgb(224, 230, 236) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"textOne":{"position":"absolute","z-index":"2","top":"44px","left":"142px","font-family":"HelveticaNeue","font-size":"27px","color":"#FF0000","innerHTML":"Trịnh Apple", "letter-spacing": "-1px", "font-weight":"bold"},


"boxCircleThree":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"552px","left":"86px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #008888 0%, #008888 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxCircleFour":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"550px","left":"99px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #008888 0%, #008888 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxCircleFive":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"554px","left":"112px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #ff0000 0%, #ff0000 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxCircleSix":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"552px","left":"126px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #ff0000 0%, #ff0000 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"textTwo":{"position":"absolute","z-index":"2","top":"542px","left":"31.5px","font-family":"HelveticaNeue","font-size":"19px","color":"#FF0000","innerHTML":"G","height":"24px","width":"25px"},


"boxSeven":{"width":"28px","height":"28px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"360px","left":"260px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"30px","background":"linear-gradient(to left, rgb(224, 230, 236) 0%, rgb(224, 230, 236) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 4px rgb(163, 177, 198), inset -2px -2px 4px rgb(255, 255, 255)","is-battery":"false"},


"boxEleven":{"width":"2px","height":"32px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"287px","left":"253px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 1px 1px 2px rgb(163, 177, 198), inset -1px -1px 2px rgb(255, 255, 255)","background":"linear-gradient(to bottom, rgb(224, 230, 236) 0%, rgb(224, 230, 236) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"coloricon":{"position":"absolute","z-index":"2","top":"286px","left":"260px","font-family":"helvetica","font-size":"30px","color":"#ff0009","width":"23px","height":"23px"},


"tempdeg":{"position":"absolute","z-index":"2","top":"293px","left":"222px","font-family":"HelveticaNeue","font-size":"16px","color":"#008888","font-weight":"bold"},


"boxCircleSeven":{"width":"22px","height":"22px","background-color":"transparent","z-index":"2","border-color":"rgb(224, 230, 236)","border-style":"solid","border-width":"2px","position":"absolute","top":"137px","left":"190px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 2px 2px 4px rgb(163, 177, 198), inset -2px -2px 4px rgb(255, 255, 255), 6px 6px 10px rgb(163, 177, 198), -6px -6px 10px rgb(255, 255, 255)","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxCircleEight":{"width":"22px","height":"22px","background-color":"transparent","z-index":"2","border-color":"rgb(224, 230, 236)","border-style":"solid","border-width":"2px","position":"absolute","top":"176px","left":"256px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"6px 6px 10px rgb(163, 177, 198), -6px -6px 10px rgb(255, 255, 255), inset 2px 2px 4px rgb(163, 177, 198), inset -2px -2px 4px rgb(255, 255, 255)"},


"textThree":{"position":"absolute","z-index":"2","top":"181px","left":209,"font-family":"HelveticaNeue","font-size":"10px","color":"#FF0000","width":"47px","innerHTML":"WiFi","height":"19px","font-weight":"bold"},


"textFour":{"position":"absolute","z-index":"2","top":"145px","left":"233px","font-family":"HelveticaNeue","font-size":"10px","color":"#008888","innerHTML":"di động ","height":"20px","width":"39px","letter-spacing": "-0.5px", "font-weight":"bold","text-transform":"uppercase"},


"boxCircleNine":{"width":"20px","height":"20px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"133px","left":"32px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 2px 3px 4px rgb(163, 177, 198), inset -2px -2px 4px rgb(255, 255, 255)","background":"linear-gradient(to bottom, #ECECEC 0%, #ECECEC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"ft24_mat5F":{"font-family":"mat5","position":"absolute","z-index":"2","top":"137px","left":"38px","font-size":"11px","color":"#008888","background-color":"rgba(0, 0, 0, 0)"},


"zclock":{"position":"absolute","z-index":"2","top":"54px","left":"38px","font-family":"HelveticaNeue","font-weight":"bold", "font-size":"16px","color":"#008888"},


"sday":{"position":"absolute","z-index":"2","top":"183px","left":"35px","font-family":"HelveticaNeue","font-size":"15px","color":"#FF0000","letter-spacing": "-0.5px","font-weight":"bold"},


"datepad":{"position":"absolute","z-index":"2","top":"144px","left":"90px","font-family":"HelveticaNeue","font-size":"30px","color":"#ff0000","font-weight":"bold"},


"smonth":{"position":"absolute","z-index":"2","top":"183px","left":"74px","font-family":"HelveticaNeue","font-size":"15px","color":"#008888", "letter-spacing": "-0.5px",  "font-weight":"bold"},


"ft4_mashup":{"font-family":"HelveticaNeue","position":"absolute","z-index":"2","top":"470px","left":"226px","font-size":"15px","color":"#008888"},


"ft4_mat2F":{"font-family":"HelveticaNeue","position":"absolute","z-index":"2","top":"470px","left":"273px","font-size":"15px","color":"#FF0000"},


"textFive":{"position":"absolute","z-index":"2","top":"367px","left":"219px","font-family":"HelveticaNeue","font-size":"10px","color":"#008888","width":"59px","innerHTML":"Mức Pin","height":"25px","letter-spacing": "0px", "font-weight":"bold"},


"textSix":{"position":"absolute","z-index":"2","top":"546px","left":"196px","font-family":"HelveticaNeue","font-size":"10px","color":"#008888","innerHTML":"Các ứng dụng","width":"83px","height":"27px","letter-spacing":"0px", "font-weight":"bold","text-transform":"uppercase"},


"wifi":{"position":"absolute","z-index":"2","top":"183.2px","left":"270px","font-family":"HelveticaNeue","font-size":"10px","color":"#FF0000","font-weight":"bold"},


"signal":{"position":"absolute","z-index":"2","top":"144.5px","left":"204px","font-family":"HelveticaNeue","font-size":"10px","color":"#008888","height":"20px","font-weight":"bold"},


"ft35_mat5F":{"font-family":"HelveticaNeue","position":"absolute","z-index":"2","top":"142px","left":"198px","font-size":"14px","color":"#ff0000","width":"25px","height":"21px"},


"ft45_mat5F":{"font-family":"HelveticaNeue","position":"absolute","z-index":"2","top":"179.7px","left":"263px","font-size":"14px","color":"#008888","width":"22px","height":"20px"},


"bundle123":{"name":"Chrome","bundleID":"com.google.chrome.ios","position":"absolute","z-index":"2","top":"539px","left":"22px","font-family":"helvetica","font-size":"7px","color":"rgba(255, 255, 255, 0)","width":"32px","height":"32px"},


"bundle113":{"name":"‎google Maps","bundleID":"com.google.Maps","position":"absolute","z-index":"2","top":"467px","left":"219px","font-family":"sanfranbold","font-size":"5px","color":"rgba(180, 4, 4, 0)","height":"25px","width":"35px"},



"bundle133":{"name":"‎Zing MP3","bundleID":"vng.com.vn.zingmp3-lite","position":"absolute","z-index":"2","top":"467px","left":"266px","font-family":"anhduy","font-size":"5px","color":"rgba(255, 255, 255, 0)","width":"25px","height":"25px"},



"batterypie":{"position":"absolute","z-index":"2","top":"364px","left":"264px","font-family":"helvetica","font-size":"30px","color":"white","circle-width":"20px","circle-stroke-dasharray":"4px","circle-stroke-value":"13px","inner-color":"#E1E5ED","outer-color":"#ff0000"}},


"iconName":"reddock"}