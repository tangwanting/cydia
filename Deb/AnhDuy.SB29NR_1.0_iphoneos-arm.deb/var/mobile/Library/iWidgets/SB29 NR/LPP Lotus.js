/* Created by LockPlus Pro by JunesiPhone http://twitter.com/junesiphone This is for personal use only. You cannot sell this widget. If you want to sell a widget code your own. */ var savedElements = {"placedElements":{"boxOne":{"width":"75px","height":"35px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"47px","left":"20px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"15px","background":"linear-gradient(to bottom, #CCCCCC 0%, #CCCCCC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 4px rgb(0, 0, 0 ,0.2), inset -2px -2px 4px rgb(255, 255, 255,0.6)"},

"boxTwo":{"width":"122px","height":"90px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":124,"left":22,"font-family":"helvetica","font-size":"30px","color":"white","border-radius":"20px","background":"linear-gradient(to bottom, #CCCCCC 0%, #CCCCCC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"0px 15px 36px rgb(0, 0, 0,0.3), -10px -10px 100px rgb(184, 184, 184), inset 3px 3px 6px rgb(255, 255, 255,0.6), inset -3px -3px 6px rgb(163, 163, 163)"},



"boxThree":{"width":"122px","height":"90px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":124,"left":175,"font-family":"helvetica","font-size":"30px","color":"white","border-radius":"20px","background":"linear-gradient(to bottom, #CCCCCC 0%, #CCCCCC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"0px 15px 36px rgb(0, 0, 0,0.3), -10px -10px 100px rgb(184, 184, 184), inset 3px 3px 6px rgb(255, 255, 255,0.6), inset -3px -3px 6px rgb(163, 163, 163)"},


"boxFour":{"width":"38px","height":"38px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"460px","left":"212px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"12px","background":"linear-gradient(to bottom, #CCCCCC 0%, #CCCCCC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"2px 2px 4px rgb(163, 163, 163), -2px -2px 4px rgb(184, 184, 184)"},


"boxFive":{"width":"38px","height":"38px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"460px","left":"259px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"12px","background":"linear-gradient(to bottom, #CCCCCC 0%, #CCCCCC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"2px 2px 4px rgb(163, 163, 163), -2px -2px 4px rgb(184, 184, 184)"},


"boxEight":{"width":"87px","height":"40px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":282,"left":210,"font-family":"helvetica","font-size":"30px","color":"white","border-radius":"17px","box-shadow":"10px 10px 20px rgb(163, 163, 163), -10px -10px 20px rgb(184, 184, 184)","background":"linear-gradient(to bottom, #CCCCCC 0%, #CCCCCC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},



"boxNine":{"width":"87px","height":"40px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"354px","left":"210px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"17px","background":"linear-gradient(to bottom, #CCCCCC 0%, #CCCCCC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"10px 10px 20px rgb(163, 163, 163), -10px -10px 20px rgb(184, 184, 184)"},


"boxTen":{"width":"132px","height":"38px","background-color":"transparent","z-index":"2","border-color":"rgb(163, 163, 163 ,0.1)","border-style":"solid","border-width":"2px","position":"absolute","top":"531px","left":"167px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"16px","background":"linear-gradient(to bottom, #CCCCCC 0%, #CCCCCC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 4px rgb(0, 0, 0 ,0.2), inset -2px -2px 4px rgb(255, 255, 255 ,0.5)"},



"boxSix":{"width":"340px","height":"690px","background-color":"transparent","z-index":1,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"0px","left":"0px","font-family":"helvetica","font-size":"40px","color":"rgba(0, 0, 0, 0.58)","background":"linear-gradient(to bottom, #D6D6D6 0%, #D6D6D6 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxCircleOne":{"width":"37px","height":"37px","background-color":"transparent","z-index":2,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"535px","left":"20px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"5px 5px 9px rgb(163, 163, 163,0.5), -5px -5px 4px rgb(184, 184, 184,0.5)","background":"linear-gradient(to bottom, #CCCCCC 0%, #CCCCCC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxCircleTwo":{"width":"27px","height":"27px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"540px","left":"25px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 2px 2px 4px rgb(163, 163, 163), inset -2px -2px 4px rgb(255, 255, 255,0.5)","background":"linear-gradient(to bottom, CCCCCC 0%, CCCCCC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"textOne":{"position":"absolute","z-index":"2","top":"52px","left":"133px","font-family":"HelveticaNeue","font-size":"19px","color":"#D75DBC","innerHTML":"HELLO ANH DUY", "letter-spacing": "0px", "font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},


"boxCircleThree":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"552px","left":"86px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #3BADCB 0%, #3BADCB 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"boxCircleFour":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"550px","left":"99px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #3BADCB 0%, #3BADCB 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"boxCircleFive":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"554px","left":"112px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #D75DBC 0%, #D75DBC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)"},


"boxCircleSix":{"width":"8px","height":"8px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"552px","left":"126px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","background":"linear-gradient(to bottom, #D75DBC 0%, #D75DBC 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent" ,"box-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)"},


"textTwo":{"position":"absolute","z-index":"2","top":"544px","left":"31px","font-family":"BIGJOHN","font-size":"19px","color":"#D75DBC","innerHTML":"G","height":"24px","width":"25px","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.6)" },


"boxSeven":{"width":"27px","height":"27px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"360px","left":"260px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"30px","background":"linear-gradient(to left, #cccccc 0%, #cccccc 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent","box-shadow":"inset 2px 2px 4px rgb(163, 167, 198), inset -2px -2px 4px rgb(255, 255, 255,0.6)","is-battery":"false"},


"boxEleven":{"width":"2px","height":"32px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"287px","left":"253px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 1px 1px 2px rgb(163, 177, 198), inset -1px -1px 2px rgb(255, 255, 255)","background":"linear-gradient(to bottom, rgb(224, 230, 236) 0%, rgb(224, 230, 236) 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"coloricon":{"position":"absolute","z-index":"2","top":"286px","left":"260px","font-family":"helvetica","font-size":"30px","color":"#D75DBC","width":"23px","height":"23px", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"tempdeg":{"position":"absolute","z-index":"2","top":"293px","left":"222px","font-family":"HelveticaNeue","font-size":"16px","color":"#3BADCB","font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"boxCircleSeven":{"width":"23px","height":"23px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"139px","left":"191.3px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 2px 3px 4px rgb(163, 163, 163), inset -2px -2px 4px rgb(255, 255, 255,0.6)","background":"linear-gradient(to bottom, #cccccc 0%, #cccccc 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"boxCircleEight":{"width":"23px","height":"23px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"177.9px","left":"257.3px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 2px 3px 4px rgb(163, 163, 163), inset -2px -2px 4px rgb(255, 255, 255,0.6)","background":"linear-gradient(to bottom, #cccccc 0%, #cccccc 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"textThree":{"position":"absolute","z-index":"2","top":"181px","left":209,"font-family":"HelveticaNeue","font-size":"12px","color":"#D75DBC","width":"47px","innerHTML":"WiFi","height":"19px","font-weight":"bold", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)"  },


"textFour":{"position":"absolute","z-index":"2","top":"143px","left":"233px","font-family":"HelveticaNeue","font-size":"11px","color":"#3BADCB","innerHTML":"di động ","height":"20px","width":"39px","letter-spacing": "-0.5px", "font-weight":"bold","text-transform":"uppercase","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"boxCircleNine":{"width":"22px","height":"22px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"137.5px","left":"36.5px","border-radius":"999px","font-family":"helvetica","font-size":"30px","color":"white","box-shadow":"inset 2px 3px 4px rgb(163, 163, 163), inset -2px -2px 4px rgb(255, 255, 255,0.5)","background":"linear-gradient(to bottom, #cccccc 0%, #cccccc 90%)","-webkit-background-clip":"initial","-webkit-text-fill-color":"transparent"},


"ft24_mat5F":{"font-family":"mat5","position":"absolute","z-index":"2","top":"141.5px","left":"43.5px","font-size":"12px","color":"#3BADCB", "font-weight":"bold", "background-color":"rgba(0, 0, 0, 0)", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"zclock":{"position":"absolute","z-index":"2","top":"54px","left":"38px","font-family":"HelveticaNeue","font-weight":"bold", "font-size":"16px","color":"#3BADCB","font-weight":"bold", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)"},


"sday":{"position":"absolute","z-index":"2","top":"183px","left":"35px","font-family":"HelveticaNeue","font-size":"15px","color":"#D75DBC","letter-spacing": "-0.5px","font-weight":"bold", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"datepad":{"position":"absolute","z-index":"2","top":"144px","left":"90px","font-family":"HelveticaNeue","font-size":"30px","color":"#D75DBC","font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.9)"},


"smonth":{"position":"absolute","z-index":"2","top":"183px","left":"74px","font-family":"HelveticaNeue","font-size":"15px","color":"3BADCB", "letter-spacing": "-0.5px","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)", "font-weight":"bold"},


"ft4_mashup":{"font-family":"HelveticaNeue","position":"absolute","z-index":"2","top":"467px","left":"224.3px","font-size":"20px","color":"#3BADCB","font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"ft4_mat2F":{"font-family":"HelveticaNeue","position":"absolute","z-index":"2","top":"467px","left":"271.3px","font-size":"20px","color":"#D75DBC","font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"textFive":{"position":"absolute","z-index":"2","top":"365px","left":"218px","font-family":"HelveticaNeue","font-size":"12px","color":"#3BADCB","width":"59px","innerHTML":"Mức Pin","height":"25px","letter-spacing": "-0.5px", "font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)" },


"textSix":{"position":"absolute","z-index":"2","top":"545px","left":"189px","font-family":"HelveticaNeue","font-size":"12px","color":"#3BADCB","innerHTML":"Các ứng dụng","width":"83px","height":"27px","letter-spacing":"0px", "font-weight":"bold","text-transform":"uppercase", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.7)"},


"wifi":{"position":"absolute","z-index":"2","top":"183.2px","left":"270px","font-family":"HelveticaNeue","font-size":"10px","color":"D75DBC ","font-weight":"bold", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.5)"  },


"signal":{"position":"absolute","z-index":"2","top":"144.5px","left":"204px","font-family":"HelveticaNeue","font-size":"10px","color":"#3BADCB","height":"20px","font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.5)" },


"ft35_mat5F":{"font-family":"HelveticaNeue","position":"absolute","z-index":"2","top":"142px","left":"198px","font-size":"14px","color":"#D75DBC","width":"25px","height":"21px", "font-weight":"bold", "text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.5)" },


"ft45_mat5F":{"font-family":"HelveticaNeue","position":"absolute","z-index":"2","top":"179.7px","left":"263px","font-size":"14px","color":"#3BADCB","width":"22px","height":"20px","font-weight":"bold","text-shadow":"0px 1px 1px rgba(0, 0, 0, 0.3)" },


"bundle123":{"name":"Chrome","bundleID":"com.google.chrome.ios","position":"absolute","z-index":"2","top":"539px","left":"22px","font-family":"helvetica","font-size":"7px","color":"rgba(255, 255, 255, 0)","width":"32px","height":"32px"},


"bundle113":{"name":"‎google Maps","bundleID":"com.google.Maps","position":"absolute","z-index":"2","top":"467px","left":"219px","font-family":"sanfranbold","font-size":"5px","color":"rgba(180, 4, 4, 0)","height":"25px","width":"35px"},



"bundle133":{"name":"‎Zing MP3","bundleID":"vng.com.vn.zingmp3-lite","position":"absolute","z-index":"2","top":"467px","left":"266px","font-family":"anhduy","font-size":"5px","color":"rgba(255, 255, 255, 0)","width":"25px","height":"25px"},



"batterypie":{"position":"absolute","z-index":"2","top":"364px","left":"264px","font-family":"helvetica","font-size":"30px","color":"white","circle-width":"20px","circle-stroke-dasharray":"4px","circle-stroke-value":"13px","inner-color":"#3BADCB","outer-color":"#D75DBC"}},


"iconName":"reddock"}