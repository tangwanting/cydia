/* Created by LockPlus Pro by JunesiPhone http://twitter.com/junesiphone This is for personal use only. You cannot sell this widget. If you want to sell a widget code your own. */ var savedElements = {"overlay":"","placedElements":{"boxOne":{"left":16,"border-color":"red","border-width":"0px","position":"absolute","border-radius":"0px","width":"287px","-webkit-transform":"rotate(0deg)","height":"1px","background-color":"rgb(255, 255, 255)","z-index":"1","border-style":"solid","top":254},



"day":{"left":130,"text-align":"center","position":"absolute","font-family":"anhduy2","width":"320px","-webkit-transform":"rotate(0deg)","font-size":"13px","color":"white","innerHTML":"Today is&#44;","height":"36px","z-index":"2","top":-1},



"textThree":{"position":"absolute","font-family":"helvetica","color":"rgba(255, 255, 255, 0)","width":"130px","innerHTML":"m","z-index":"2","font-size":"3px","top":-1,"left":130},



"date":{"left":0,"text-align":"center","position":"absolute","-webkit-text-fill-color":"transparent","font-family":"disclaimerclassic","width":"320px","-webkit-transform":"rotate(0deg)","font-size":"180px","color":"rgba(219, 14, 14, 0.24)","background":"linear-gradient(to bottom, grey, white","-webkit-background-clip":"text","height":"217px","z-index":"2","background-color":"rgba(226, 0, 0, 0)","top":"-1px"},



"month":{"left":-1,"text-align":"center","position":"absolute","font-family":"anhduy7", "letter-spacing":"-2px", "font-size":"25px","width":"320px","-webkit-transform":"rotate(0deg)","color":"white","text-shadow":"rgba(0, 0, 0, 0.66) 0px 4px 7px","height":"36px","z-index":"2","top":162},



"lngwstring5":{"left":0,"text-align":"center","position":"absolute","font-family":"anhduy2", "letter-spacing":"-0.5px","width":"320px","-webkit-transform":"rotate(0deg)","font-size":"13px","color":"white","innerHTML":"TODAY IS","height":"72px","z-index":"2","top":218},



"ttext":{"left":"1px","lineHeight":"32px","position":"absolute","text-align":"center","-webkit-text-fill-color":"transparent","text-transform":"capitalize", "letter-spacing":"3px", "font-family":"anhduy4","font-size":"22px","width":"320px","-webkit-background-clip":"text","color":"rgba(222, 202, 157, 1.00)","opacity":"10","background":"linear-gradient(to right, white, white)","height":"37px","z-index":50,"background-color":"rgba(0, 0, 0, 0)","top":"70px"},



"textTwo":{"position":"absolute","font-family":"anhduy1","text-align":"center","color":"white","width":"320px","innerHTML":"!","z-index":"2","font-size":"13px","top":-61,"left":204},



"customDiv0":{"left":-20,"text-align":"center","position":"absolute","font-family":"helvetica","font-size":"30px",



"data-vars":["textOne","textThree","day","textTwo"],"width":"320px","color":"rgba(222, 202, 157, 1.00)","-webkit-transform":"rotate(0deg)","height":"36px","z-index":2,"top":185},



"textOne":{"position":"absolute","font-family":"anhduy2","text-align":"center","color":"white","width":"320px","innerHTML":"hôm nay là","z-index":"2","font-size":"13px","top":-63,"left":-56}},"iconName":"simply"}