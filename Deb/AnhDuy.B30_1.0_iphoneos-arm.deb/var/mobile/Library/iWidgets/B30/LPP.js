/* Created by LockPlus Pro by JunesiPhone http://twitter.com/junesiphone This is for personal use only. You cannot sell this widget. If you want to sell a widget code your own. */ var savedElements = {"placedElements":{"zhour":{"position":"absolute","font-family":"bebasbold","color":"rgb(13, 108, 144)","z-index":"9999","top":"117px","left":"99.9px","font-size":"37px"},



"sday":{"position":"absolute","font-family":"anhduy","color":"white", "text-align":"center", "text-transform": "uppercase","z-index":"9999","top":141,"left":"62px","font-size":"9px","display":"none", "-webkit-text-stroke-width":"0.4px","-webkit-text-stroke-color":"rgba(255, 255, 255, 1.00)"  },


"day":{"position":"absolute","z-index":"2","top":"136px","left":"40px","font-family":"anhduy","font-size":"9px","color":"white","width":"60px","text-align":"center","height":"19px","text-transform":"uppercase","lineHeight":"20px","-webkit-text-stroke-width":"0.4px","-webkit-text-stroke-color":"rgba(255, 255, 255, 1.00)"  },



"smonth":{"position":"absolute","font-family":"anhduy","color":"white","font-weight": "normal", "word-spacing":"-2.5px", "text-transform": "uppercase","z-index":"9999","top":165,"left":209.8,"font-size":"15px", "-webkit-text-stroke-width":"0.6px","-webkit-text-stroke-color":"rgba(255, 255, 255, 1.00)" },


"coloricon":{"position":"absolute","font-family":"helvetica","color":"white","z-index":"9999","top":104.5,"left":62,"font-size":"16px"},


"boxThree":{"left":147,"border-color":"rgb(255, 255, 255)","border-width":"1px","position":"absolute","border-radius":"5px","-webkit-text-fill-color":"transparent","width":"50px","font-family":"helvetica","font-size":"30px","-webkit-background-clip":"initial","color":"white","background":"linear-gradient(to bottom, rgb(255, 255, 255) 0%, rgb(255, 255, 255) 65%, rgba(96, 45, 45, 0) 0%)","height":"81px","background-color":"transparent","z-index":"-9834","border-style":"solid","top":104},


"boxCircleThree":{"left":56,"border-color":"rgb(15, 45, 69)","border-width":"1px","position":"absolute","border-radius":"999px","width":"25px","font-family":"helvetica","font-size":"30px","color":"white","height":"25px","background-color":"rgb(13, 108, 144)","z-index":"-9999","border-style":"solid","top":101},


"textTwo":{"position":"absolute","font-family":"anhduy","color":"white","text-transform": "uppercase","innerHTML":"phút","left":162.4,"top":165,"z-index":"9999","font-size":"15px",  "-webkit-text-stroke-width":"0.6px","-webkit-text-stroke-color":"rgba(255, 255, 255, 1.00)"  },


"boxOne":{"left":89,"border-color":"rgb(255, 255, 255)","border-width":"1px","position":"absolute","border-radius":"5px","-webkit-text-fill-color":"transparent","width":"50px","font-family":"helvetica","font-size":"30px","-webkit-background-clip":"initial","color":"white","background":"linear-gradient(to bottom, rgb(255, 255, 255) 0%, rgb(255, 255, 255) 65%, rgba(96, 45, 45, 0) 0%)","height":"81px","background-color":"transparent","z-index":"-9999","border-style":"solid","top":104},


"boxCircleOne":{"left":56,"border-color":"rgb(15, 45, 69)","border-width":"1px","position":"absolute","border-radius":"999px","width":"25px","font-family":"helvetica","font-size":"30px","color":"white","height":"25px","background-color":"rgb(13, 108, 144)","z-index":"-9999","border-style":"solid","top":163},


"boxTwo":{"left":205,"border-color":"rgb(255, 255, 255)","border-width":"1px","position":"absolute","border-radius":"5px","-webkit-text-fill-color":"transparent","width":"50px","font-family":"helvetica","font-size":"30px","-webkit-background-clip":"initial","color":"white","background":"linear-gradient(to bottom, rgb(255, 255, 255) 0%, rgb(255, 255, 255) 65%, rgba(96, 45, 45, 0) 0%)","height":"81px","background-color":"transparent","z-index":"-9999","border-style":"solid","top":104},


"datepad":{"position":"absolute","font-family":"bebasbold","color":"rgb(13, 108, 144)","z-index":"9999","top":"117px","left":"216px","font-size":"37px","background-color":"rgba(0, 0, 0, 0)"},


"tempdeg":{"position":"absolute","font-family":"bebasbold","color":"white","z-index":"9999","top":172,"left":65,"font-size":"10px"},


"textOne":{"position":"absolute","font-family":"anhduy","color":"white","text-transform": "uppercase", "innerHTML":"giờ","left":106.5,"top":165,"z-index":"9999","font-size":"15px","-webkit-text-stroke-width":"0.6px","-webkit-text-stroke-color":"rgba(255, 255, 255, 1.00)"},




"boxCircleTwo":{"left":56,"border-color":"rgb(174, 174, 174)","border-width":"1px","position":"absolute","border-radius":"999px","width":"25px","font-family":"helvetica","font-size":"30px","color":"white","height":"25px","background-color":"rgb(128, 128, 128)","z-index":"-9999","border-style":"solid","top":132},


"minute":{"position":"absolute","font-family":"bebasbold","color":"rgb(128, 128, 128)","z-index":"9999","top":"117px","left":"159px","font-size":"37px"}},"overlay":"","iconName":"simply"}