var twentyfourhour = true; // bật cho thời gian 24 giờ
var pad = true; // bật để thêm số 0 truoces giờ
