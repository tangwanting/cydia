var savedElements = {"placedElements":{"boxOne":{"width":"266px","height":"131.00px","background-color":"transparent","z-index":133,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"46.00px","left":"27.00px","data-image":"https://i.imgur.com/QW3jX0n.png","background-size":"cover","background-repeat":"no-repeat"},


"customPanel0":{"position":"absolute","z-index":134,"top":"60.00px","left":"0px","font-family":"helvetica","font-size":"30px","color":"white","data-vars":["boxOne","daydatesmonth","zclock","textTwo","textThree"],"data-name":"customPanel0","width":"320px","height":"220.00px"},


"zclock":{"position":"absolute","z-index":135,"top":"94.00px","left":104,"font-family":"manbow","font-size":"28.00px","color":"white","width":"118px","text-align":"center", "letter-spacing": "5px", "text-shadow":"0px 1px 1px rgb(0, 0, 0)"},


"daydatesmonth":{"position":"absolute","z-index":136,"top":"126.00px","left":42,"font-family":"HelveticaNeue","font-size":"9.00px","color":"white","text-transform":"capitalize","width":"236px","text-align":"center","height":"12.00px","lineHeight":"13.00px","text-shadow":"0px 1px 0px rgb(0,0,0)"},


"boxTwo":{"width":"266px","height":"131px","background-color":"transparent","z-index":"-1","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"46.00px","left":"27.00px","data-image":"https://i.imgur.com/QW3jX0n.png","background-size":"cover","background-repeat":"no-repeat"},


"customPanel1":{"data-vars":["boxTwo","tempdegplus","condition","textFour","textFive"],"data-name":"customPanel1","width":"320px","height":"220.00px","position":"absolute","z-index":"49","top":"60.00px","left":"-320.00px","font-family":"helvetica","font-size":"30px","color":"white"},


"tempdegplus":{"position":"absolute","z-index":"-82","top":"94.00px","left":100,"font-family":"manbow","font-size":"28.00px","color":"white","width":"120px","text-align":"center","letter-spacing": "5px",  "text-shadow":"0px 1px 1px rgb(0,0,0)"},


"condition":{"position":"absolute","z-index":141,"top":"126.00px","left":"42.00px","font-family":"HelveticaNeue","font-size":"9.00px","color":"white","text-transform":"capitalize","width":"238px","text-align":"center","text-shadow":"0px 1px 1px rgb(0,0,0)"},


"pressActions":{"textOne":{"affectedItems":["customPanel0","customPanel1"],"customPanel0":{"-webkit-transform":"translateX(+320px)"},


"customPanel1":{"-webkit-transform":"translateX(320px)"}}},


"textOne":{"position":"absolute","z-index":142,"top":"152px","left":"62px","font-family":"mat3","font-size":"30px","color":"white","width":"197px","height":"49.00px","text-align":"center","innerHTML":"X","lineHeight":"50px","musicplaying":null,"action":"textOne","opacity":"-1.2"},


"textTwo":{"position":"absolute","z-index":143,"top":"97.00px","left":"75.00px","font-family":"SoftOrnaments21-pnLv","font-size":"30px","color":"white","innerHTML":"n","width":"22px","text-align":"center","text-shadow":"0px 1px 1px rgb(0,0,0)"},


"textThree":{"position":"absolute","z-index":144,"top":"93.00px","left":"222.00px","font-family":"SoftOrnaments21-pnLv","font-size":"30px","color":"white","innerHTML":"n","opacity":"1","padding-bottom":"-3px","padding-top":"2px","width":"24px","text-align":"center","-webkit-transform":"rotate(180.00deg)","text-shadow":"0px 1px 1px rgb(0,0,0)"},


"textFour":{"position":"absolute","z-index":145,"top":"97.00px","left":"81px","font-family":"SoftOrnaments21-pnLv","font-size":"30px","color":"white","innerHTML":"n","width":"22px","text-align":"center","text-shadow":"0px 1px 1px rgb(0,0,0)"},


"textFive":{"position":"absolute","z-index":147,"top":"93.00px","left":"219.00px","font-family":"SoftOrnaments21-pnLv","font-size":"30px","color":"white","innerHTML":"n","-webkit-transform":"rotate(180.00deg)","text-shadow":"0px 1px 1px rgb(0,0,0)"}}}