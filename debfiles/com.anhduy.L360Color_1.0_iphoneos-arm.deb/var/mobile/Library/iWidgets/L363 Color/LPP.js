var savedElements = {"placedElements":{"boxOne":{"width":"320px","height":"688px","background-color":"transparent","z-index":"2","border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"5px","left":"-1px","font-family":"helvetica","font-size":"30px","color":"white","data-image":"images/wall.png","background-size":"cover","background-repeat":"no-repeat"},



"boxTwo":{"width":"298px","height":"522px","background-color":"rgba(255, 255, 255, 0.1)","z-index":1,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"46px","left":"10px","font-family":"helvetica","font-size":"30px","color":"white","border-radius":"34px","-webkit-backdrop-filter":"blur(5px)"},



"daydatesmonth":{"left":"51px","position":"absolute","z-index":"2","top":"537px","font-family":"anhduy3","font-size":"13px","color":"white","width":"215px","height":"20px","text-align":"center","text-transform":"   ","lineHeight":"22px","text-shadow":"0px 1px 1px rgb(0,0,0)"},



"tempcon1":{"position":"absolute","z-index":"2","top":"560px","left":"59px","font-family":"anhduy3","font-size":"13px","color":"white","width":"200px", "text-align":"center","height":"18px","text-transform":"", "lineHeight":"15px","text-shadow":"0px 1px 1px rgb(0,0,0)"},



"icon":{"position":"absolute","z-index":"2","top":"37px","left":"43px","font-family":"helvetica","font-size":"30px","color":"white","width":"42px","height":"42px"},



"zclock":{"position":"absolute","z-index":"2","top":"35px","left":"118px","font-family":"anhduy1","font-size":"24px","color":"white","width":"151px","text-align":"center","height":"30px","lineHeight":"29px",  "letter-spacing":"5px","text-shadow":"0px 1px 1px rgb(0,0,0)"},



"batteryperslashcharge":{"left":"122px","position":"absolute","z-index":"2","top":"64px","font-family":"anhduy3","font-size":"10px","color":"white","width":"148px","text-align":"center","height":"14px","lineHeight":"14px","text-shadow":"0px 1px 1px rgb(0,0,0)","letter-spacing":"2px","text-transform":"   "}},"iconName":"custover"}